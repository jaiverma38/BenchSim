const { Sim } = require('./sim.js'); const { EXAMPLES } = require('./examples.js'); const { COMPS } = require('./comps.js');
for (const ex of EXAMPLES) {
  const s = new Sim(); s.setBoard(ex.board);
  const comps = ex.comps.map(c => Object.assign({ label: c.type }, JSON.parse(JSON.stringify(COMPS[c.type].init || {})), c));
  s.setCircuit(comps, ex.wires); let out = '', w = [];
  s.onSerial = t => out += t; s.onWarn = (k, m) => w.push(k);
  try { s.start(s.compile(ex.code).factory); } catch (e) { console.log(ex.id, 'COMPILE ERR', e.line, e.message); continue; }
  let sn; for (let i = 0; i < 240; i++) { s.advance(1e6 / 60, 50); sn = s.snapshot(); }
  const brief = Object.entries(sn).map(([id, o]) => { const c = comps.find(x => x.id == id); const k = ['b', 'on', 'v', 'angle', 'br', 'sa', 'w', 'lines'].filter(q => o[q] !== undefined && o[q] !== null).map(q => q + '=' + (typeof o[q] === 'number' ? +o[q].toFixed(2) : JSON.stringify(o[q]))).join(' '); return c.type + ':' + k; }).join(' | ');
  console.log(ex.id.padEnd(8), 'warn[' + w.join(',') + ']', JSON.stringify(out.slice(0, 40)), '\n    ', brief);
}
