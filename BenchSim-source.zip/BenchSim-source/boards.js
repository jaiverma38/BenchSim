// ===== Development boards: pin tables + auto layout =====
const BOARDS = {};
const POWER = ['3V3', '5V', 'GND1', 'GND2'];
function P(i, name, o) { return Object.assign({ i, name, label: String(i), pwm: false, adc: false, irq: false, group: 'dig' }, o || {}); }
function range(a, b) { const r = []; for (let i = a; i <= b; i++) r.push(i); return r; }

(function () {
  const unoPwm = [3, 5, 6, 9, 10, 11];
  const dig = (n, pwm, irq) => range(0, n - 1).map(i => P(i, 'D' + i, { pwm: pwm.includes(i), irq: irq.includes(i), label: pwm.includes(i) ? '~' + i : String(i) }));
  const ana = (base, n, extra) => range(0, n - 1).map(k => P(base + k, 'A' + k, { adc: true, group: 'analog', label: 'A' + k, ioOnly: k >= 6 && extra }));
  const aconst = (base, n) => { const o = {}; range(0, n - 1).forEach(k => o['A' + k] = base + k); return o; };

  BOARDS.uno = { name: 'Arduino Uno R3', mcu: 'ATmega328P', color: '#0f7a7a', vcc: 5, adcMax: 1023, led: 13, analogBase: 14, analogCount: 6,
    pins: dig(14, unoPwm, [2, 3]).concat(ana(14, 6)), consts: Object.assign({ LED_BUILTIN: 13 }, aconst(14, 6)), i2c: [18, 19], note: '5V logic, 10-bit ADC, 6 PWM pin' };
  BOARDS.nano = { name: 'Arduino Nano', mcu: 'ATmega328P', color: '#1a5fa8', vcc: 5, adcMax: 1023, led: 13, analogBase: 14, analogCount: 8,
    pins: dig(14, unoPwm, [2, 3]).concat(ana(14, 8, true)), consts: Object.assign({ LED_BUILTIN: 13 }, aconst(14, 8)), i2c: [18, 19], note: '5V logic, A6/A7 sirf analog input' };
  const megaPwm = range(2, 13).concat([44, 45, 46]);
  BOARDS.mega = { name: 'Arduino Mega 2560', mcu: 'ATmega2560', color: '#0b6b6b', vcc: 5, adcMax: 1023, led: 13, analogBase: 54, analogCount: 16,
    pins: dig(54, megaPwm, [2, 3, 18, 19, 20, 21]).concat(ana(54, 16)), consts: Object.assign({ LED_BUILTIN: 13 }, aconst(54, 16)), i2c: [20, 21], note: '5V logic, 54 digital + 16 analog pin' };
  const g = (n, o) => P(n, 'GPIO' + n, Object.assign({ pwm: true, irq: true, label: String(n) }, o));
  const espAdc = [0, 2, 4, 12, 13, 14, 15, 25, 26, 27, 32, 33, 34, 35, 36, 39];
  BOARDS.esp32 = { name: 'ESP32 DevKit V1', mcu: 'ESP32', color: '#1b1f22', vcc: 3.3, adcMax: 4095, led: 2, analogBase: 0, analogCount: 0,
    pins: [0, 2, 4, 5, 12, 13, 14, 15, 16, 17, 18, 19, 21, 22, 23, 25, 26, 27, 32, 33, 34, 35, 36, 39].map(n => g(n, { adc: espAdc.includes(n), inOnly: n >= 34, pwm: n < 34 })),
    consts: { LED_BUILTIN: 2, A0: 36, A3: 39, A4: 32, A5: 33, A6: 34, A7: 35, A10: 4, A11: 0, A12: 2, A13: 15, A14: 13, A15: 12, A16: 14, A17: 27, A18: 25, A19: 26 },
    i2c: [21, 22], note: '3.3V logic (5V signal seedha mat jodo), 12-bit ADC' };
  BOARDS.pico = { name: 'Raspberry Pi Pico', mcu: 'RP2040', color: '#1c7a3e', vcc: 3.3, adcMax: 1023, led: 25, analogBase: 26, analogCount: 3, noHeaderLed: true,
    pins: range(0, 22).concat([26, 27, 28]).map(n => P(n, 'GP' + n, { pwm: true, irq: true, adc: n >= 26, label: 'GP' + n })),
    consts: { LED_BUILTIN: 25, A0: 26, A1: 27, A2: 28 }, i2c: [4, 5], note: '3.3V logic, 3 ADC pin (GP26-28)' };
  const nm = { D0: 16, D1: 5, D2: 4, D3: 0, D4: 2, D5: 14, D6: 12, D7: 13, D8: 15 };
  BOARDS.nodemcu = { name: 'NodeMCU ESP8266', mcu: 'ESP8266', color: '#20262a', vcc: 3.3, adcMax: 1023, led: 2, ledLow: true, analogBase: 17, analogCount: 1,
    pins: Object.keys(nm).map(k => P(nm[k], k, { pwm: true, irq: true, label: k })).concat([P(17, 'A0', { adc: true, group: 'analog', label: 'A0' })]),
    consts: Object.assign({ LED_BUILTIN: 2, A0: 17 }, nm), i2c: [4, 5], note: '3.3V logic, sirf 1 analog pin (A0)' };
  const s3n = (n) => P(n, 'GPIO' + n, { pwm: true, irq: true, adc: n >= 1 && n <= 20, label: String(n), note: n === 19 || n === 20 ? 'USB D-/D+ ke liye hai. Yahan GPIO19/20 use karoge to USB serial band ho jaayegi.' : (n >= 35 && n <= 37 ? 'GPIO35-37 octal PSRAM (N8R8/N16R8) ke liye reserved hain. Inhe use mat karo.' : '') });
  const s3pins = range(0, 21).concat(range(35, 48)).map(s3n);
  const s3consts = { LED_BUILTIN: 48, RGB_BUILTIN: 48, SDA: 8, SCL: 9, SS: 10, MOSI: 11, SCK: 12, MISO: 13 }; range(0, 19).forEach(k => s3consts['A' + k] = k + 1);
  BOARDS.esp32s3 = { name: 'ESP32-S3-DevKitC-1', short: 'ESP32-S3', mcu: 'ESP32-S3', color: '#1b1f22', vcc: 3.3, adcMax: 4095, led: 48, analogBase: 0, analogCount: 0, usb: true,
    pins: s3pins, consts: s3consts, i2c: [8, 9], spi: [12, 13, 11], note: '3.3V logic, 12-bit ADC, USB host (camera), I2C = GPIO8/9, SPI = 12/13/11' };
  BOARDS.esp32s3m = { name: 'ESP32-S3-WROOM-1 (bare module)', short: 'S3 WROOM-1', mcu: 'ESP32-S3', color: '#2a2f33', vcc: 3.3, adcMax: 4095, led: 48, analogBase: 0, analogCount: 0, usb: true, power: ['3V3', 'GND1', 'GND2'],
    pins: s3pins, consts: s3consts, i2c: [8, 9], spi: [12, 13, 11], note: 'Module hai: sirf 3V3 aur GND chahiye. Simulator isse USB se power deta hai. Onboard USB-UART/LED nahi.' };
  BOARDS.uno.spi = [13, 12, 11]; BOARDS.nano.spi = [13, 12, 11]; BOARDS.mega.spi = [52, 50, 51]; BOARDS.esp32.spi = [18, 19, 23]; BOARDS.pico.spi = [18, 16, 19]; BOARDS.nodemcu.spi = [14, 12, 13];
  ['esp32', 'esp32s3', 'esp32s3m', 'pico', 'nodemcu'].forEach(k => BOARDS[k].bits = 32);
  Object.keys(BOARDS).forEach(id => {
    const b = BOARDS[id]; b.id = id; b.byIdx = new Map(b.pins.map(p => [p.i, p]));
    b.pinTerm = new Map(b.pins.map(p => [p.i, 'P:' + p.name]));
    b.pwmSet = new Set(b.pins.filter(p => p.pwm).map(p => p.i));
    b.irqSet = new Set(b.pins.filter(p => p.irq).map(p => p.i));
  });
})();

// ---- auto layout (viewBox 400 wide; board top edge y=215) ----
let CUR = null;
function chunk(a, n) { const r = []; for (let i = 0; i < a.length; i += n) r.push(a.slice(i, i + n)); return r; }
function layoutBoard(id) {
  const b = BOARDS[id], pos = {}, SP = 25.4, X0 = 24, RH = 38, Y0 = 230;
  const topNames = (b.power || POWER).concat(b.pins.filter(p => p.group === 'analog').map(p => p.name));
  const botNames = b.pins.filter(p => p.group !== 'analog').map(p => p.name).concat(['GND3']);
  const topRows = chunk(topNames, 15), botRows = chunk(botNames, 15);
  const bandY = Y0 + (topRows.length - 1) * RH, botY0 = bandY + 120, bottom = botY0 + (botRows.length - 1) * RH + 15;
  const lab = (n) => /^GND/.test(n) ? 'GND' : n;
  let s = `<rect x="6" y="215" width="388" height="${bottom - 215}" rx="10" fill="${b.color}"/><rect x="6" y="215" width="388" height="${bottom - 215}" rx="10" class="pcbEdge"/>`;
  const cy = (bandY + botY0) / 2;
  s += `<rect x="14" y="${cy - 28}" width="50" height="50" rx="3" class="usb"/><text x="39" y="${cy}" class="bt" text-anchor="middle">USB</text>`;
  s += `<rect x="150" y="${cy - 16}" width="104" height="30" rx="3" class="chip"/><text x="202" y="${cy + 3}" class="bt chipt" text-anchor="middle">${b.mcu}</text>`;
  s += `<circle cx="92" cy="${cy - 22}" r="7" class="rst"/><text x="92" y="${cy - 6}" class="bt" text-anchor="middle" font-size="7">RESET</text>`;
  s += `<text x="278" y="${cy - 2}" class="bt big">${b.short || b.name.split(' ').slice(-2).join(' ')}</text><text x="278" y="${cy + 10}" class="bt" font-size="7">simulated</text>`;
  s += `<circle id="onboardL" cx="262" cy="${cy + 20}" r="4" class="obl"/><text x="262" y="${cy + 12}" class="bt" font-size="7" text-anchor="middle">L</text>`;
  const rows = [];
  topRows.forEach((r, ri) => rows.push({ names: r, y: Y0 + ri * RH, lab: 'below' }));
  botRows.forEach((r, ri) => rows.push({ names: r, y: botY0 + ri * RH, lab: 'above' }));
  rows.forEach(row => row.names.forEach((n, j) => {
    const x = X0 + SP * j, y = row.y, t = 'P:' + n, p = b.pins.find(q => q.name === n);
    pos[t] = [x, y];
    const L = p ? p.label : lab(n);
    s += `<text x="${x}" y="${row.lab === 'below' ? y + 17 : y - 12}" class="pl" text-anchor="middle">${L}</text>` + termMarkup(t, x, y, 'pin');
  }));
  return { id, b, pos, markup: s, bottom, led: [b.noHeaderLed ? 'none' : 'hdr'] };
}
function termMarkup(id, x, y, cls) {
  return `<g class="term ${cls || ''}" data-t="${id}" transform="translate(${x},${y})"><circle class="hit" r="12"/><circle class="dot" r="${cls === 'pin' ? 4.2 : 4.8}"/></g>`;
}
function boardTermPos(t) { return CUR && CUR.pos[t] ? CUR.pos[t] : [0, 0]; }
function setBoardLayout(id) { CUR = layoutBoard(id); return CUR; }
function fmtOhm(v) { return v >= 1e6 ? (+(v / 1e6).toFixed(2)) + 'MΩ' : v >= 1e3 ? (+(v / 1e3).toFixed(2)) + 'kΩ' : (+v.toFixed(2)) + 'Ω'; }

if (typeof module !== 'undefined') module.exports = { BOARDS, layoutBoard, POWER, fmtOhm };
