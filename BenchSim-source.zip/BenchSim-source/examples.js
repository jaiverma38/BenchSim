// ===== Example circuits + sketches =====
const EXAMPLES = [
 {
  "id": "blink",
  "name": "Blink: LED jhapkana",
  "code": "// Blink: D13 par laga LED har 1 second mein on/off\nconst int ledPin = 13;\n\nvoid setup() {\n  pinMode(ledPin, OUTPUT);\n  Serial.begin(9600);\n}\n\nvoid loop() {\n  digitalWrite(ledPin, HIGH);\n  Serial.println(\"LED ON\");\n  delay(1000);\n  digitalWrite(ledPin, LOW);\n  Serial.println(\"LED OFF\");\n  delay(1000);\n}\n",
  "comps": [
   {
    "id": 1,
    "type": "res",
    "x": 120,
    "y": 450,
    "val": 220
   },
   {
    "id": 2,
    "type": "led",
    "x": 270,
    "y": 470,
    "val": "red"
   }
  ],
  "wires": [
   [
    "P:D13",
    "c1:1"
   ],
   [
    "c1:2",
    "c2:A"
   ],
   [
    "c2:K",
    "P:GND3"
   ]
  ],
  "board": "uno"
 },
 {
  "id": "button",
  "name": "Button se LED (pull-down ke saath)",
  "code": "// Button dabao to LED jale.\n// Button ke saath 10k pull-down zaroori hai,\n// warna pin \"floating\" ho jaata hai aur reading random aati hai.\nconst int buttonPin = 2;\nconst int ledPin = 13;\n\nvoid setup() {\n  pinMode(buttonPin, INPUT);\n  pinMode(ledPin, OUTPUT);\n}\n\nvoid loop() {\n  digitalWrite(ledPin, digitalRead(buttonPin));\n  delay(10);\n}\n",
  "comps": [
   {
    "id": 1,
    "type": "btn",
    "x": 70,
    "y": 430,
    "pressed": false
   },
   {
    "id": 2,
    "type": "res",
    "x": 130,
    "y": 520,
    "val": 10000
   },
   {
    "id": 3,
    "type": "res",
    "x": 250,
    "y": 430,
    "val": 220
   },
   {
    "id": 4,
    "type": "led",
    "x": 330,
    "y": 500,
    "val": "green"
   }
  ],
  "wires": [
   [
    "P:5V",
    "c1:1"
   ],
   [
    "c1:2",
    "P:D2"
   ],
   [
    "P:D2",
    "c2:1"
   ],
   [
    "c2:2",
    "P:GND3"
   ],
   [
    "P:D13",
    "c3:1"
   ],
   [
    "c3:2",
    "c4:A"
   ],
   [
    "c4:K",
    "P:GND3"
   ]
  ],
  "board": "uno"
 },
 {
  "id": "pot",
  "name": "Potentiometer se LED dimming (PWM)",
  "code": "// Pot ghumao, LED ki brightness badlegi.\nconst int potPin = A0;\nconst int ledPin = 9;   // ~ wala PWM pin\n\nvoid setup() {\n  pinMode(ledPin, OUTPUT);\n  Serial.begin(9600);\n}\n\nvoid loop() {\n  int raw = analogRead(potPin);\n  int brightness = map(raw, 0, 1023, 0, 255);\n  analogWrite(ledPin, brightness);\n  Serial.print(\"ADC: \");\n  Serial.print(raw);\n  Serial.print(\"  Voltage: \");\n  Serial.print(raw * 5.0 / 1023.0, 2);\n  Serial.println(\" V\");\n  delay(200);\n}\n",
  "comps": [
   {
    "id": 1,
    "type": "pot",
    "x": 200,
    "y": 110,
    "val": 0.5
   },
   {
    "id": 2,
    "type": "res",
    "x": 120,
    "y": 450,
    "val": 220
   },
   {
    "id": 3,
    "type": "led",
    "x": 270,
    "y": 470,
    "val": "yellow"
   }
  ],
  "wires": [
   [
    "P:5V",
    "c1:1"
   ],
   [
    "c1:W",
    "P:A0"
   ],
   [
    "c1:2",
    "P:GND2"
   ],
   [
    "P:D9",
    "c2:1"
   ],
   [
    "c2:2",
    "c3:A"
   ],
   [
    "c3:K",
    "P:GND3"
   ]
  ],
  "board": "uno"
 },
 {
  "id": "servo",
  "name": "Servo ko pot se control karo",
  "code": "#include <Servo.h>\n\nServo myServo;\n\nvoid setup() {\n  myServo.attach(9);\n  Serial.begin(9600);\n}\n\nvoid loop() {\n  int raw = analogRead(A0);\n  int angle = map(raw, 0, 1023, 0, 180);\n  myServo.write(angle);\n  Serial.println(angle);\n  delay(30);\n}\n",
  "comps": [
   {
    "id": 1,
    "type": "pot",
    "x": 200,
    "y": 110,
    "val": 0.5
   },
   {
    "id": 2,
    "type": "servo",
    "x": 200,
    "y": 470
   }
  ],
  "wires": [
   [
    "P:5V",
    "c1:1"
   ],
   [
    "c1:W",
    "P:A0"
   ],
   [
    "c1:2",
    "P:GND2"
   ],
   [
    "P:D9",
    "c2:SIG"
   ],
   [
    "P:5V",
    "c2:V"
   ],
   [
    "P:GND3",
    "c2:G"
   ]
  ],
  "board": "uno"
 },
 {
  "id": "sonar",
  "name": "Ultrasonic doori + LED alarm",
  "code": "// HC-SR04: 30 cm se paas aaye to LED jale\nconst int trigPin = 9;\nconst int echoPin = 10;\nconst int ledPin = 8;\n\nvoid setup() {\n  pinMode(trigPin, OUTPUT);\n  pinMode(echoPin, INPUT);\n  pinMode(ledPin, OUTPUT);\n  Serial.begin(9600);\n}\n\nvoid loop() {\n  digitalWrite(trigPin, LOW);\n  delayMicroseconds(2);\n  digitalWrite(trigPin, HIGH);\n  delayMicroseconds(10);\n  digitalWrite(trigPin, LOW);\n\n  long duration = pulseIn(echoPin, HIGH);\n  float cm = duration / 58.0;\n  Serial.print(cm, 1);\n  Serial.println(\" cm\");\n  digitalWrite(ledPin, cm < 30);\n  delay(200);\n}\n",
  "comps": [
   {
    "id": 1,
    "type": "hcsr04",
    "x": 200,
    "y": 450,
    "dist": 80
   },
   {
    "id": 2,
    "type": "res",
    "x": 80,
    "y": 560,
    "val": 220
   },
   {
    "id": 3,
    "type": "led",
    "x": 330,
    "y": 560,
    "val": "red"
   }
  ],
  "wires": [
   [
    "P:5V",
    "c1:VCC"
   ],
   [
    "P:D9",
    "c1:TRIG"
   ],
   [
    "P:D10",
    "c1:ECHO"
   ],
   [
    "P:GND3",
    "c1:GND"
   ],
   [
    "P:D8",
    "c2:1"
   ],
   [
    "c2:2",
    "c3:A"
   ],
   [
    "c3:K",
    "P:GND2"
   ]
  ],
  "board": "uno"
 },
 {
  "id": "lcd",
  "name": "LCD 16x2 par temperature (DHT11)",
  "code": "#include <LiquidCrystal.h>\n#include <DHT.h>\n\nLiquidCrystal lcd(12, 11, 5, 4, 3, 2);   // rs, en, d4, d5, d6, d7\nDHT dht(7, DHT11);\n\nvoid setup() {\n  lcd.begin(16, 2);\n  dht.begin();\n  lcd.print(\"Weather Station\");\n}\n\nvoid loop() {\n  float t = dht.readTemperature();\n  float h = dht.readHumidity();\n  lcd.setCursor(0, 1);\n  if (isnan(t)) {\n    lcd.print(\"Sensor error    \");\n  } else {\n    lcd.print(t, 1);\n    lcd.print(\"C  \");\n    lcd.print(h, 0);\n    lcd.print(\"%   \");\n  }\n  delay(1000);\n}\n",
  "comps": [
   {
    "id": 1,
    "type": "lcd",
    "x": 130,
    "y": 470
   },
   {
    "id": 2,
    "type": "dht",
    "x": 330,
    "y": 470,
    "temp": 27,
    "hum": 58
   }
  ],
  "wires": [
   [
    "P:5V",
    "c1:VDD"
   ],
   [
    "P:GND3",
    "c1:GND"
   ],
   [
    "P:D12",
    "c1:RS"
   ],
   [
    "P:D11",
    "c1:E"
   ],
   [
    "P:D5",
    "c1:D4"
   ],
   [
    "P:D4",
    "c1:D5"
   ],
   [
    "P:D3",
    "c1:D6"
   ],
   [
    "P:D2",
    "c1:D7"
   ],
   [
    "P:5V",
    "c2:VCC"
   ],
   [
    "P:GND2",
    "c2:GND"
   ],
   [
    "P:D7",
    "c2:DATA"
   ]
  ],
  "board": "uno"
 },
 {
  "id": "rgb",
  "name": "RGB LED colour mixing",
  "code": "const int rPin = 9, gPin = 10, bPin = 11;\n\nvoid setColor(int r, int g, int b) {\n  analogWrite(rPin, r);\n  analogWrite(gPin, g);\n  analogWrite(bPin, b);\n}\n\nvoid setup() {\n  pinMode(rPin, OUTPUT);\n  pinMode(gPin, OUTPUT);\n  pinMode(bPin, OUTPUT);\n}\n\nvoid loop() {\n  setColor(255, 0, 0);   delay(600);   // laal\n  setColor(0, 255, 0);   delay(600);   // hara\n  setColor(0, 0, 255);   delay(600);   // neela\n  setColor(255, 255, 0); delay(600);   // peela\n  setColor(255, 0, 255); delay(600);   // magenta\n  setColor(0, 255, 255); delay(600);   // cyan\n  setColor(255, 120, 20); delay(600);  // orange\n}\n",
  "comps": [
   {
    "id": 1,
    "type": "rgb",
    "x": 200,
    "y": 620
   },
   {
    "id": 2,
    "type": "res",
    "x": 70,
    "y": 500,
    "val": 220
   },
   {
    "id": 3,
    "type": "res",
    "x": 200,
    "y": 500,
    "val": 220
   },
   {
    "id": 4,
    "type": "res",
    "x": 330,
    "y": 500,
    "val": 220
   }
  ],
  "wires": [
   [
    "P:D9",
    "c2:1"
   ],
   [
    "c2:2",
    "c1:R"
   ],
   [
    "P:D10",
    "c3:1"
   ],
   [
    "c3:2",
    "c1:G"
   ],
   [
    "P:D11",
    "c4:1"
   ],
   [
    "c4:2",
    "c1:B"
   ],
   [
    "c1:K",
    "P:GND3"
   ]
  ],
  "board": "uno"
 },
 {
  "id": "seg7",
  "name": "7-segment par 0 se 9 ginti",
  "code": "// Common-cathode 7-segment. COM ke saath ek 100 ohm resistor GND tak.\nconst int segPins[7] = {2, 3, 4, 5, 6, 7, 8};   // a b c d e f g\nconst byte digits[10] = {\n  B1111110, B0110000, B1101101, B1111001, B0110011,\n  B1011011, B1011111, B1110000, B1111111, B1111011\n};\n\nvoid show(int n) {\n  for (int i = 0; i < 7; i++) {\n    digitalWrite(segPins[i], bitRead(digits[n], 6 - i));\n  }\n}\n\nvoid setup() {\n  for (int i = 0; i < 7; i++) pinMode(segPins[i], OUTPUT);\n}\n\nvoid loop() {\n  for (int n = 0; n < 10; n++) {\n    show(n);\n    delay(700);\n  }\n}\n",
  "comps": [
   {
    "id": 1,
    "type": "seg7",
    "x": 200,
    "y": 490
   },
   {
    "id": 2,
    "type": "res",
    "x": 330,
    "y": 590,
    "val": 100
   }
  ],
  "wires": [
   [
    "P:D2",
    "c1:a"
   ],
   [
    "P:D3",
    "c1:b"
   ],
   [
    "P:D4",
    "c1:c"
   ],
   [
    "P:D5",
    "c1:d"
   ],
   [
    "P:D6",
    "c1:e"
   ],
   [
    "P:D7",
    "c1:f"
   ],
   [
    "P:D8",
    "c1:g"
   ],
   [
    "c1:COM",
    "c2:1"
   ],
   [
    "c2:2",
    "P:GND3"
   ]
  ],
  "board": "uno"
 },
 {
  "id": "chaser",
  "name": "74HC595 se LED chaser (shiftOut)",
  "code": "// 74HC595: 3 pin se 8 output. Yahan Q0-Q3 par 4 LED.\nconst int dataPin = 2, clockPin = 3, latchPin = 4;\n\nvoid sendByte(byte v) {\n  digitalWrite(latchPin, LOW);\n  shiftOut(dataPin, clockPin, MSBFIRST, v);\n  digitalWrite(latchPin, HIGH);\n}\n\nvoid setup() {\n  pinMode(dataPin, OUTPUT);\n  pinMode(clockPin, OUTPUT);\n  pinMode(latchPin, OUTPUT);\n}\n\nvoid loop() {\n  for (int i = 0; i < 4; i++) {\n    sendByte(1 << i);\n    delay(250);\n  }\n  for (int i = 2; i > 0; i--) {\n    sendByte(1 << i);\n    delay(250);\n  }\n}\n",
  "comps": [
   {
    "id": 1,
    "type": "ic595",
    "x": 200,
    "y": 450
   },
   {
    "id": 2,
    "type": "res",
    "x": 55,
    "y": 540,
    "val": 220
   },
   {
    "id": 3,
    "type": "res",
    "x": 145,
    "y": 540,
    "val": 220
   },
   {
    "id": 4,
    "type": "res",
    "x": 235,
    "y": 540,
    "val": 220
   },
   {
    "id": 5,
    "type": "res",
    "x": 325,
    "y": 540,
    "val": 220
   },
   {
    "id": 6,
    "type": "led",
    "x": 90,
    "y": 600,
    "val": "red"
   },
   {
    "id": 7,
    "type": "led",
    "x": 180,
    "y": 600,
    "val": "yellow"
   },
   {
    "id": 8,
    "type": "led",
    "x": 270,
    "y": 600,
    "val": "green"
   },
   {
    "id": 9,
    "type": "led",
    "x": 360,
    "y": 600,
    "val": "blue"
   }
  ],
  "wires": [
   [
    "P:5V",
    "c1:VCC"
   ],
   [
    "P:5V",
    "c1:SRCLR"
   ],
   [
    "P:GND1",
    "c1:GND"
   ],
   [
    "P:GND2",
    "c1:OE"
   ],
   [
    "P:D2",
    "c1:SER"
   ],
   [
    "P:D3",
    "c1:SRCLK"
   ],
   [
    "P:D4",
    "c1:RCLK"
   ],
   [
    "c1:Q0",
    "c2:1"
   ],
   [
    "c2:2",
    "c6:A"
   ],
   [
    "c6:K",
    "P:GND3"
   ],
   [
    "c1:Q1",
    "c3:1"
   ],
   [
    "c3:2",
    "c7:A"
   ],
   [
    "c7:K",
    "P:GND3"
   ],
   [
    "c1:Q2",
    "c4:1"
   ],
   [
    "c4:2",
    "c8:A"
   ],
   [
    "c8:K",
    "P:GND3"
   ],
   [
    "c1:Q3",
    "c5:1"
   ],
   [
    "c5:2",
    "c9:A"
   ],
   [
    "c9:K",
    "P:GND3"
   ]
  ],
  "board": "uno"
 },
 {
  "id": "motor",
  "name": "Motor ko transistor se chalao (PWM)",
  "code": "// Motor kabhi seedha pin se nahi chalate. NPN transistor switch ka kaam karta hai.\n// Diode (flyback) motor ko transistor ke khilaf voltage spike se bachata hai.\nconst int motorPin = 9;   // PWM\n\nvoid setup() {\n  pinMode(motorPin, OUTPUT);\n  Serial.begin(9600);\n}\n\nvoid loop() {\n  for (int s = 0; s <= 255; s += 5) {\n    analogWrite(motorPin, s);\n    delay(40);\n  }\n  Serial.println(\"Full speed\");\n  delay(800);\n  for (int s = 255; s >= 0; s -= 5) {\n    analogWrite(motorPin, s);\n    delay(40);\n  }\n  delay(800);\n}\n",
  "comps": [
   {
    "id": 1,
    "type": "res",
    "x": 90,
    "y": 450,
    "val": 1000
   },
   {
    "id": 2,
    "type": "npn",
    "x": 190,
    "y": 520,
    "val": "2N2222"
   },
   {
    "id": 3,
    "type": "motor",
    "x": 290,
    "y": 470
   },
   {
    "id": 4,
    "type": "batt",
    "x": 60,
    "y": 590,
    "val": 9
   },
   {
    "id": 5,
    "type": "diode",
    "x": 340,
    "y": 600
   }
  ],
  "wires": [
   [
    "P:D9",
    "c1:1"
   ],
   [
    "c1:2",
    "c2:B"
   ],
   [
    "c2:E",
    "P:GND3"
   ],
   [
    "c4:+",
    "c3:M1"
   ],
   [
    "c3:M2",
    "c2:C"
   ],
   [
    "c4:-",
    "P:GND2"
   ],
   [
    "c5:A",
    "c2:C"
   ],
   [
    "c5:K",
    "c4:+"
   ]
  ],
  "board": "uno"
 },
 {
  "id": "relay",
  "name": "Relay module se 9V bulb (LED) switch karo",
  "code": "// Relay module active-LOW hota hai: LOW dene par relay on.\nconst int relayPin = 8;\n\nvoid setup() {\n  pinMode(relayPin, OUTPUT);\n  digitalWrite(relayPin, HIGH);   // shuru mein off\n}\n\nvoid loop() {\n  digitalWrite(relayPin, LOW);    // on\n  delay(1500);\n  digitalWrite(relayPin, HIGH);   // off\n  delay(1500);\n}\n",
  "comps": [
   {
    "id": 1,
    "type": "relaymod",
    "x": 110,
    "y": 470
   },
   {
    "id": 2,
    "type": "batt",
    "x": 330,
    "y": 470,
    "val": 9
   },
   {
    "id": 3,
    "type": "res",
    "x": 200,
    "y": 590,
    "val": 470
   },
   {
    "id": 4,
    "type": "led",
    "x": 330,
    "y": 600,
    "val": "blue"
   }
  ],
  "wires": [
   [
    "P:5V",
    "c1:VCC"
   ],
   [
    "P:GND3",
    "c1:GND"
   ],
   [
    "P:D8",
    "c1:IN"
   ],
   [
    "c2:+",
    "c1:COM"
   ],
   [
    "c1:NO",
    "c3:1"
   ],
   [
    "c3:2",
    "c4:A"
   ],
   [
    "c4:K",
    "c2:-"
   ]
  ],
  "board": "uno"
 },
 {
  "id": "traffic",
  "name": "Traffic light: enum + struct + millis()",
  "code": "// Bina delay() ke state machine. enum, struct aur array ka use.\nenum State { GREEN_S, YELLOW_S, RED_S };\n\nstruct Phase {\n  int pin;\n  unsigned long ms;\n};\n\nPhase phases[3] = { {10, 4000}, {9, 1500}, {8, 3000} };   // green, yellow, red pins\nState state = GREEN_S;\nunsigned long last = 0;\n\nvoid setLights(State s) {\n  for (int i = 0; i < 3; i++) digitalWrite(phases[i].pin, i == s);\n}\n\nvoid setup() {\n  for (int i = 0; i < 3; i++) pinMode(phases[i].pin, OUTPUT);\n  Serial.begin(9600);\n  setLights(state);\n}\n\nvoid loop() {\n  if (millis() - last >= phases[state].ms) {\n    last = millis();\n    state = (State)((state + 1) % 3);\n    setLights(state);\n    Serial.println(state);\n  }\n}\n",
  "comps": [
   {
    "id": 1,
    "type": "res",
    "x": 70,
    "y": 450,
    "val": 220
   },
   {
    "id": 2,
    "type": "res",
    "x": 200,
    "y": 450,
    "val": 220
   },
   {
    "id": 3,
    "type": "res",
    "x": 330,
    "y": 450,
    "val": 220
   },
   {
    "id": 4,
    "type": "led",
    "x": 100,
    "y": 540,
    "val": "green"
   },
   {
    "id": 5,
    "type": "led",
    "x": 230,
    "y": 540,
    "val": "yellow"
   },
   {
    "id": 6,
    "type": "led",
    "x": 360,
    "y": 540,
    "val": "red"
   }
  ],
  "wires": [
   [
    "P:D10",
    "c1:1"
   ],
   [
    "c1:2",
    "c4:A"
   ],
   [
    "c4:K",
    "P:GND3"
   ],
   [
    "P:D9",
    "c2:1"
   ],
   [
    "c2:2",
    "c5:A"
   ],
   [
    "c5:K",
    "P:GND3"
   ],
   [
    "P:D8",
    "c3:1"
   ],
   [
    "c3:2",
    "c6:A"
   ],
   [
    "c6:K",
    "P:GND3"
   ]
  ],
  "board": "uno"
 },
 {
  "id": "irq",
  "name": "Interrupt: button press count",
  "code": "// attachInterrupt: button dabte hi ISR chalta hai, loop() mein delay ho tab bhi.\nvolatile int presses = 0;\nconst int buttonPin = 2;   // interrupt pin (Uno: 2 ya 3)\n\nvoid onPress() {\n  presses++;\n}\n\nvoid setup() {\n  Serial.begin(9600);\n  pinMode(buttonPin, INPUT_PULLUP);\n  attachInterrupt(digitalPinToInterrupt(buttonPin), onPress, FALLING);\n}\n\nvoid loop() {\n  Serial.print(\"Presses: \");\n  Serial.println(presses);\n  delay(1000);\n}\n",
  "comps": [
   {
    "id": 1,
    "type": "btn",
    "x": 200,
    "y": 470,
    "pressed": false
   }
  ],
  "wires": [
   [
    "P:D2",
    "c1:1"
   ],
   [
    "c1:2",
    "P:GND3"
   ]
  ],
  "board": "uno"
 },
 {
  "id": "esp32",
  "name": "ESP32: 3.3V, 12-bit ADC, PWM",
  "code": "// ESP32: ADC 0-4095, logic 3.3V\nconst int potPin = 34;\nconst int ledPin = 4;\n\nvoid setup() {\n  Serial.begin(115200);\n  pinMode(ledPin, OUTPUT);\n  pinMode(LED_BUILTIN, OUTPUT);\n}\n\nvoid loop() {\n  int raw = analogRead(potPin);\n  analogWrite(ledPin, map(raw, 0, 4095, 0, 255));\n  digitalWrite(LED_BUILTIN, !digitalRead(LED_BUILTIN));\n  Serial.print(\"ADC: \");\n  Serial.print(raw);\n  Serial.print(\"  V: \");\n  Serial.println(raw * 3.3 / 4095.0, 2);\n  delay(300);\n}\n",
  "comps": [
   {
    "id": 1,
    "type": "pot",
    "x": 330,
    "y": 110,
    "val": 0.6
   },
   {
    "id": 2,
    "type": "res",
    "x": 120,
    "y": 450,
    "val": 220
   },
   {
    "id": 3,
    "type": "led",
    "x": 270,
    "y": 470,
    "val": "white"
   }
  ],
  "wires": [
   [
    "P:3V3",
    "c1:1"
   ],
   [
    "c1:W",
    "P:GPIO34"
   ],
   [
    "c1:2",
    "P:GND2"
   ],
   [
    "P:GPIO4",
    "c2:1"
   ],
   [
    "c2:2",
    "c3:A"
   ],
   [
    "c3:K",
    "P:GND3"
   ]
  ],
  "board": "esp32"
 },
 {
  "id": "ldr",
  "name": "LDR se automatic night lamp",
  "code": "// Andhera ho to LED apne aap jale.\n// 5V - LDR - A0 - 10k - GND (voltage divider)\nconst int ldrPin = A0;\nconst int ledPin = 6;\nconst int threshold = 400;\n\nvoid setup() {\n  pinMode(ledPin, OUTPUT);\n  Serial.begin(9600);\n}\n\nvoid loop() {\n  int light = analogRead(ldrPin);\n  if (light < threshold) {\n    digitalWrite(ledPin, HIGH);\n  } else {\n    digitalWrite(ledPin, LOW);\n  }\n  Serial.println(light);\n  delay(300);\n}\n",
  "comps": [
   {
    "id": 1,
    "type": "ldr",
    "x": 90,
    "y": 110,
    "val": 0.8
   },
   {
    "id": 2,
    "type": "res",
    "x": 250,
    "y": 110,
    "val": 10000
   },
   {
    "id": 3,
    "type": "res",
    "x": 110,
    "y": 450,
    "val": 220
   },
   {
    "id": 4,
    "type": "led",
    "x": 260,
    "y": 470,
    "val": "blue"
   }
  ],
  "wires": [
   [
    "P:5V",
    "c1:1"
   ],
   [
    "c1:2",
    "P:A0"
   ],
   [
    "P:A0",
    "c2:1"
   ],
   [
    "c2:2",
    "P:GND2"
   ],
   [
    "P:D6",
    "c3:1"
   ],
   [
    "c3:2",
    "c4:A"
   ],
   [
    "c4:K",
    "P:GND3"
   ]
  ],
  "board": "uno"
 },
 {
  "id": "buzzer",
  "name": "Buzzer par dhun (tone)",
  "code": "// Passive buzzer par saat swar bajao\nconst int buzzerPin = 8;\nint melody[] = {262, 294, 330, 349, 392, 440, 494, 523};\n\nvoid setup() {\n  pinMode(buzzerPin, OUTPUT);\n}\n\nvoid loop() {\n  for (int i = 0; i < 8; i++) {\n    tone(buzzerPin, melody[i], 200);\n    delay(250);\n  }\n  noTone(buzzerPin);\n  delay(1000);\n}\n",
  "comps": [
   {
    "id": 1,
    "type": "buzzp",
    "x": 200,
    "y": 460
   }
  ],
  "wires": [
   [
    "P:D8",
    "c1:+"
   ],
   [
    "c1:-",
    "P:GND3"
   ]
  ],
  "board": "uno"
 },
 {
  "id": "s3_tilt",
  "name": "S3: MPU6050 tilt + OLED",
  "code": "// ESP32-S3: MPU6050 ka tilt angle OLED par dikhao\n#include <Wire.h>\n#include <MPU6050_light.h>\n#include <Adafruit_GFX.h>\n#include <Adafruit_SSD1306.h>\n\nMPU6050 mpu(Wire);\nAdafruit_SSD1306 display(128, 64, &Wire, -1);\n\nvoid setup() {\n  Serial.begin(115200);\n  Wire.begin(8, 9);               // SDA = GPIO8, SCL = GPIO9\n  byte status = mpu.begin();\n  Serial.printf(\"MPU6050 status: %d\\n\", status);\n  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {\n    Serial.println(\"OLED nahi mila!\");\n    while (true) delay(100);\n  }\n  mpu.calcOffsets();\n}\n\nvoid loop() {\n  mpu.update();\n  float pitch = mpu.getAngleX();\n  float roll = mpu.getAngleY();\n  display.clearDisplay();\n  display.setTextSize(1);\n  display.setTextColor(WHITE);\n  display.setCursor(0, 0);\n  display.println(\"MPU6050 tilt\");\n  display.setTextSize(2);\n  display.setCursor(0, 16);\n  display.print(\"P:\");\n  display.println(pitch, 1);\n  display.print(\"R:\");\n  display.println(roll, 1);\n  // bubble level\n  display.drawRect(88, 12, 40, 40, WHITE);\n  int bx = 108 + (int)(roll / 90.0 * 18);\n  int by = 32 - (int)(pitch / 90.0 * 18);\n  display.fillCircle(bx, by, 3, WHITE);\n  display.display();\n  delay(50);\n}\n",
  "comps": [
   {
    "id": 1,
    "type": "mpu6050",
    "x": 95,
    "y": 140,
    "addr": 104,
    "pitch": 20,
    "roll": -15,
    "spin": 0,
    "temp": 25
   },
   {
    "id": 2,
    "type": "oled",
    "x": 290,
    "y": 135,
    "addr": 60
   }
  ],
  "wires": [
   [
    "P:GPIO8",
    "c1:SDA"
   ],
   [
    "P:GPIO9",
    "c1:SCL"
   ],
   [
    "P:3V3",
    "c1:VCC"
   ],
   [
    "P:GND1",
    "c1:GND"
   ],
   [
    "P:GPIO8",
    "c2:SDA"
   ],
   [
    "P:GPIO9",
    "c2:SCL"
   ],
   [
    "P:3V3",
    "c2:VCC"
   ],
   [
    "P:GND1",
    "c2:GND"
   ]
  ],
  "board": "esp32s3"
 },
 {
  "id": "s3_tof",
  "name": "S3: VL53L0X doori + OLED bar",
  "code": "// VL53L0X ToF sensor se doori naapo, OLED par bar dikhao\n#include <Wire.h>\n#include <VL53L0X.h>\n#include <Adafruit_SSD1306.h>\n\nVL53L0X tof;\nAdafruit_SSD1306 display(128, 64, &Wire, -1);\n\nvoid setup() {\n  Serial.begin(115200);\n  Wire.begin(8, 9);\n  tof.setTimeout(500);\n  if (!tof.init()) {\n    Serial.println(\"VL53L0X init fail! Wiring check karo.\");\n    while (true) delay(100);\n  }\n  tof.startContinuous();\n  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);\n}\n\nvoid loop() {\n  int mm = tof.readRangeContinuousMillimeters();\n  if (tof.timeoutOccurred()) Serial.println(\"timeout\");\n  Serial.printf(\"Doori: %d mm\\n\", mm);\n  display.clearDisplay();\n  display.setTextSize(2);\n  display.setTextColor(WHITE);\n  display.setCursor(0, 0);\n  display.print(mm);\n  display.println(\" mm\");\n  int w = map(constrain(mm, 0, 1000), 0, 1000, 0, 120);\n  display.drawRect(0, 40, 124, 16, WHITE);\n  display.fillRect(2, 42, w, 12, WHITE);\n  display.display();\n}\n",
  "comps": [
   {
    "id": 1,
    "type": "vl53",
    "x": 95,
    "y": 140,
    "dist": 350
   },
   {
    "id": 2,
    "type": "oled",
    "x": 290,
    "y": 135,
    "addr": 60
   }
  ],
  "wires": [
   [
    "P:GPIO8",
    "c1:SDA"
   ],
   [
    "P:GPIO9",
    "c1:SCL"
   ],
   [
    "P:3V3",
    "c1:VIN"
   ],
   [
    "P:GND1",
    "c1:GND"
   ],
   [
    "P:GPIO8",
    "c2:SDA"
   ],
   [
    "P:GPIO9",
    "c2:SCL"
   ],
   [
    "P:3V3",
    "c2:VCC"
   ],
   [
    "P:GND1",
    "c2:GND"
   ]
  ],
  "board": "esp32s3"
 },
 {
  "id": "s3_mic",
  "name": "S3: INMP441 sound meter",
  "code": "// INMP441 I2S microphone: awaaz ki loudness naapo\n#include <ESP_I2S.h>\n\nI2SClass I2S;\nconst int BCLK = 5, WS = 6, DIN = 7;\n\nvoid setup() {\n  Serial.begin(115200);\n  I2S.setPins(BCLK, WS, -1, DIN);\n  if (!I2S.begin(I2S_MODE_STD, 16000, I2S_DATA_BIT_WIDTH_16BIT, I2S_SLOT_MODE_MONO)) {\n    Serial.println(\"I2S start nahi hua\");\n    while (true) delay(100);\n  }\n  pinMode(LED_BUILTIN, OUTPUT);\n}\n\nvoid loop() {\n  int peak = 0;\n  for (int i = 0; i < 400; i++) {\n    int s = abs(I2S.read());\n    if (s > peak) peak = s;\n  }\n  int bars = map(constrain(peak, 0, 16000), 0, 16000, 0, 30);\n  for (int i = 0; i < bars; i++) Serial.print(\"#\");\n  Serial.printf(\" %d\\n\", peak);\n  digitalWrite(LED_BUILTIN, peak > 8000);\n  delay(100);\n}\n",
  "comps": [
   {
    "id": 1,
    "type": "inmp441",
    "x": 120,
    "y": 145,
    "level": 0.3,
    "freq": 440
   }
  ],
  "wires": [
   [
    "P:GPIO5",
    "c1:SCK"
   ],
   [
    "P:GPIO6",
    "c1:WS"
   ],
   [
    "P:GPIO7",
    "c1:SD"
   ],
   [
    "P:3V3",
    "c1:VDD"
   ],
   [
    "P:GND1",
    "c1:GND"
   ],
   [
    "P:GND2",
    "c1:LR"
   ]
  ],
  "board": "esp32s3"
 },
 {
  "id": "s3_amp",
  "name": "S3: MAX98357A + speaker",
  "code": "// MAX98357A I2S amplifier se speaker par tone bajao (440 Hz, phir 880 Hz)\n#include <ESP_I2S.h>\n\nI2SClass I2S;\nconst int BCLK = 5, LRC = 6, DOUT = 7;\nconst int RATE = 16000;\n\nvoid playTone(int freq, int ms) {\n  int period = RATE / freq;\n  long total = (long)RATE * ms / 1000;\n  for (long i = 0; i < total; i++) {\n    int16_t s = ((i % period) < period / 2) ? 6000 : -6000;\n    I2S.write(s);\n  }\n}\n\nvoid setup() {\n  Serial.begin(115200);\n  I2S.setPins(BCLK, LRC, DOUT);\n  if (!I2S.begin(I2S_MODE_STD, RATE, I2S_DATA_BIT_WIDTH_16BIT, I2S_SLOT_MODE_MONO)) {\n    Serial.println(\"I2S fail\");\n    while (true) delay(100);\n  }\n}\n\nvoid loop() {\n  Serial.println(\"440 Hz\");\n  playTone(440, 800);\n  delay(300);\n  Serial.println(\"880 Hz\");\n  playTone(880, 800);\n  delay(300);\n}\n",
  "comps": [
   {
    "id": 1,
    "type": "max98357",
    "x": 200,
    "y": 130
   },
   {
    "id": 2,
    "type": "speaker",
    "x": 330,
    "y": 210
   }
  ],
  "wires": [
   [
    "P:GPIO7",
    "c1:DIN"
   ],
   [
    "P:GPIO5",
    "c1:BCLK"
   ],
   [
    "P:GPIO6",
    "c1:LRC"
   ],
   [
    "P:5V",
    "c1:VIN"
   ],
   [
    "P:GND1",
    "c1:GND"
   ],
   [
    "c1:SPK+",
    "c2:+"
   ],
   [
    "c1:SPK-",
    "c2:-"
   ]
  ],
  "board": "esp32s3"
 },
 {
  "id": "s3_sd",
  "name": "S3: SD card data logger",
  "code": "// Potentiometer ki reading micro SD card par log karo, phir wapas padho\n#include <SD.h>\n#include <SPI.h>\n\nconst int CS_PIN = 10;\nconst int POT = 1;\n\nvoid setup() {\n  Serial.begin(115200);\n  if (!SD.begin(CS_PIN)) {\n    Serial.println(\"SD card init fail! Wiring aur 5V check karo.\");\n    return;\n  }\n  Serial.println(\"SD ready\");\n  File f = SD.open(\"/log.csv\", FILE_WRITE);\n  f.println(\"n,adc,volt\");\n  for (int n = 1; n <= 5; n++) {\n    int adc = analogRead(POT);\n    f.print(n); f.print(\",\"); f.print(adc); f.print(\",\"); f.println(adc * 3.3 / 4095.0, 2);\n    delay(200);\n  }\n  f.close();\n  File r = SD.open(\"/log.csv\");\n  while (r.available()) Serial.write(r.read());\n  r.close();\n}\n\nvoid loop() { delay(1000); }\n",
  "comps": [
   {
    "id": 1,
    "type": "sdcard",
    "x": 115,
    "y": 140
   },
   {
    "id": 2,
    "type": "pot",
    "x": 330,
    "y": 150,
    "val": 0.4
   }
  ],
  "wires": [
   [
    "P:GPIO12",
    "c1:SCK"
   ],
   [
    "P:GPIO13",
    "c1:MISO"
   ],
   [
    "P:GPIO11",
    "c1:MOSI"
   ],
   [
    "P:GPIO10",
    "c1:CS"
   ],
   [
    "P:5V",
    "c1:VCC"
   ],
   [
    "P:GND1",
    "c1:GND"
   ],
   [
    "P:3V3",
    "c2:1"
   ],
   [
    "c2:W",
    "P:GPIO1"
   ],
   [
    "c2:2",
    "P:GND2"
   ]
  ],
  "board": "esp32s3"
 },
 {
  "id": "s3_drive",
  "name": "S3: TB6612 + MT3608 motors",
  "code": "// 3.7V battery -> MT3608 boost (6V) -> TB6612FNG -> 2 DC motors\nconst int STBY = 4, AIN1 = 6, AIN2 = 7, BIN1 = 15, BIN2 = 16;\nconst int PWMA = 5, PWMB = 17;\n\nvoid motor(int speedA, int speedB) {\n  digitalWrite(AIN1, speedA > 0); digitalWrite(AIN2, speedA < 0);\n  digitalWrite(BIN1, speedB > 0); digitalWrite(BIN2, speedB < 0);\n  ledcWrite(PWMA, abs(speedA));\n  ledcWrite(PWMB, abs(speedB));\n}\n\nvoid setup() {\n  Serial.begin(115200);\n  int pins[] = {STBY, AIN1, AIN2, BIN1, BIN2};\n  for (int i = 0; i < 5; i++) pinMode(pins[i], OUTPUT);\n  ledcAttach(PWMA, 20000, 8);\n  ledcAttach(PWMB, 20000, 8);\n  digitalWrite(STBY, HIGH);\n}\n\nvoid loop() {\n  Serial.println(\"Aage, full speed\");\n  motor(255, 255);  delay(2000);\n  Serial.println(\"Aage, aadhi speed\");\n  motor(128, 128);  delay(2000);\n  Serial.println(\"Mudo (ek motor ulta)\");\n  motor(180, -180); delay(2000);\n  Serial.println(\"Ruko\");\n  motor(0, 0);      delay(1500);\n}\n",
  "comps": [
   {
    "id": 1,
    "type": "tb6612",
    "x": 200,
    "y": 140
   },
   {
    "id": 2,
    "type": "motor",
    "x": 60,
    "y": 200
   },
   {
    "id": 3,
    "type": "motor",
    "x": 340,
    "y": 200
   },
   {
    "id": 4,
    "type": "batt",
    "x": 30,
    "y": 100,
    "val": 3.7
   },
   {
    "id": 5,
    "type": "mt3608",
    "x": 110,
    "y": 75,
    "vout": 6
   }
  ],
  "wires": [
   [
    "P:GPIO4",
    "c1:STBY"
   ],
   [
    "P:GPIO5",
    "c1:PWMA"
   ],
   [
    "P:GPIO6",
    "c1:AIN1"
   ],
   [
    "P:GPIO7",
    "c1:AIN2"
   ],
   [
    "P:GPIO17",
    "c1:PWMB"
   ],
   [
    "P:GPIO15",
    "c1:BIN1"
   ],
   [
    "P:GPIO16",
    "c1:BIN2"
   ],
   [
    "P:3V3",
    "c1:VCC"
   ],
   [
    "P:GND1",
    "c1:GND"
   ],
   [
    "c4:+",
    "c5:IN+"
   ],
   [
    "c4:-",
    "c5:IN-"
   ],
   [
    "c5:IN-",
    "P:GND2"
   ],
   [
    "c5:OUT+",
    "c1:VM"
   ],
   [
    "c5:OUT-",
    "P:GND1"
   ],
   [
    "c1:AO1",
    "c2:M1"
   ],
   [
    "c1:AO2",
    "c2:M2"
   ],
   [
    "c1:BO1",
    "c3:M1"
   ],
   [
    "c1:BO2",
    "c3:M2"
   ]
  ],
  "board": "esp32s3"
 },
 {
  "id": "s3_radar",
  "name": "S3: Radar motion + servo 180°",
  "code": "// RCWL-0516 radar harkat pakde to servo 180° ghoome\n#include <Servo.h>\n\nServo gate;\nconst int RADAR = 4, SERVO_PIN = 18;\n\nvoid setup() {\n  Serial.begin(115200);\n  pinMode(RADAR, INPUT);\n  gate.attach(SERVO_PIN);\n  gate.write(0);\n}\n\nvoid loop() {\n  if (digitalRead(RADAR)) {\n    Serial.println(\"Harkat mili! Gate khul raha hai\");\n    for (int a = 0; a <= 180; a += 5) { gate.write(a); delay(15); }\n    delay(1500);\n    for (int a = 180; a >= 0; a -= 5) { gate.write(a); delay(15); }\n  }\n  delay(50);\n}\n",
  "comps": [
   {
    "id": 1,
    "type": "radar",
    "x": 110,
    "y": 150,
    "motion": true
   },
   {
    "id": 2,
    "type": "servo",
    "x": 290,
    "y": 140
   }
  ],
  "wires": [
   [
    "P:5V",
    "c1:VIN"
   ],
   [
    "P:GND1",
    "c1:GND"
   ],
   [
    "P:GPIO4",
    "c1:OUT"
   ],
   [
    "P:GPIO18",
    "c2:SIG"
   ],
   [
    "P:5V",
    "c2:V"
   ],
   [
    "P:GND2",
    "c2:G"
   ]
  ],
  "board": "esp32s3"
 },
 {
  "id": "s3_cam",
  "name": "S3: USB camera tracking + servo",
  "code": "// USB camera (simplified API): object ka position dekh kar servo ko ghumao\n#include <USBCamera.h>\n#include <Servo.h>\n\nUSBCamera cam;\nServo pan;\n\nvoid setup() {\n  Serial.begin(115200);\n  if (!cam.begin()) {\n    Serial.println(\"Camera nahi mila\");\n    while (true) delay(100);\n  }\n  pan.attach(18);\n}\n\nvoid loop() {\n  if (cam.capture()) {\n    int x = cam.objectX();\n    int angle = map(x, 0, cam.width() - 1, 0, 180);\n    pan.write(angle);\n    Serial.printf(\"x=%d angle=%d roshni=%d\\n\", x, angle, cam.brightness());\n  }\n  delay(100);\n}\n",
  "comps": [
   {
    "id": 1,
    "type": "camera",
    "x": 110,
    "y": 145,
    "objX": 0.25,
    "light": 0.7,
    "motion": false
   },
   {
    "id": 2,
    "type": "servo",
    "x": 290,
    "y": 140
   }
  ],
  "wires": [
   [
    "P:5V",
    "c1:VBUS"
   ],
   [
    "P:GND1",
    "c1:GND"
   ],
   [
    "P:GPIO19",
    "c1:DM"
   ],
   [
    "P:GPIO20",
    "c1:DP"
   ],
   [
    "P:GPIO18",
    "c2:SIG"
   ],
   [
    "P:5V",
    "c2:V"
   ],
   [
    "P:GND2",
    "c2:G"
   ]
  ],
  "board": "esp32s3"
 },
 {
  "id": "s3_jarvis",
  "name": "S3: Jarvis hardware (mic+amp+OLED+radar)",
  "code": "// JARVIS hardware skeleton (ESP32-S3)\n// Radar harkat dekhe -> Jarvis jaagta hai -> mic se awaaz sunta hai ->\n// \"sochta\" hai -> speaker se jawab ki beep bajata hai -> SD par log likhta hai.\n// NOTE: Asli Jarvis mein \"THINKING\" step mein WiFi se AI API call hogi.\n// Simulator mein WiFi nahi hai, isliye wahan sirf delay rakha hai.\n#include <Wire.h>\n#include <ESP_I2S.h>\n#include <Adafruit_SSD1306.h>\n#include <MPU6050_light.h>\n#include <SD.h>\n#include <Servo.h>\n\nconst int MIC_BCLK = 5, MIC_WS = 6, MIC_DIN = 7;\nconst int SPK_BCLK = 15, SPK_LRC = 16, SPK_DOUT = 17;\nconst int RADAR = 4, SERVO_PIN = 18, SD_CS = 10;\nconst int RATE = 16000;\n\nI2SClass mic;\nI2SClass spk;\nAdafruit_SSD1306 display(128, 64, &Wire, -1);\nMPU6050 imu(Wire);\nServo head;\n\nenum State { IDLE, LISTENING, THINKING, SPEAKING };\nState state = IDLE;\nunsigned long stateStart = 0;\nint peak = 0;\nbool heard = false;\nint turns = 0;\nbool sdOk = false;\n\nString stateName() {\n  switch (state) {\n    case IDLE: return \"SO RAHA HOON\";\n    case LISTENING: return \"SUN RAHA HOON\";\n    case THINKING: return \"SOCH RAHA HOON\";\n    default: return \"BOL RAHA HOON\";\n  }\n}\n\nvoid setState(State s) {\n  state = s;\n  stateStart = millis();\n  Serial.println(\"State: \" + stateName());\n}\n\nint readPeak() {\n  int p = 0;\n  for (int i = 0; i < 200; i++) {\n    int v = abs(mic.read());\n    if (v > p) p = v;\n  }\n  return p;\n}\n\nvoid playTone(int freq, int ms) {\n  int period = RATE / freq;\n  long total = (long)RATE * ms / 1000;\n  for (long i = 0; i < total; i++) {\n    int16_t s = ((i % period) < period / 2) ? 5000 : -5000;\n    spk.write(s);\n  }\n}\n\nvoid logTurn() {\n  if (!sdOk) return;\n  File f = SD.open(\"/jarvis.log\", FILE_APPEND);\n  f.print(\"turn \");\n  f.print(turns);\n  f.print(\" peak \");\n  f.println(peak);\n  f.close();\n}\n\nvoid draw() {\n  display.clearDisplay();\n  display.setTextSize(1);\n  display.setTextColor(WHITE);\n  display.setCursor(0, 0);\n  display.println(\"J.A.R.V.I.S\");\n  display.setCursor(0, 14);\n  display.println(stateName());\n  display.setCursor(0, 26);\n  display.print(\"Baatein: \");\n  display.println(turns);\n  int w = map(constrain(peak, 0, 12000), 0, 12000, 0, 120);\n  display.drawRect(0, 40, 124, 10, WHITE);\n  display.fillRect(2, 42, w, 6, WHITE);\n  display.setCursor(0, 54);\n  display.print(\"Tilt: \");\n  display.print(imu.getAngleX(), 0);\n  display.display();\n}\n\nvoid setup() {\n  Serial.begin(115200);\n  Wire.begin(8, 9);\n  pinMode(RADAR, INPUT);\n  head.attach(SERVO_PIN);\n  head.write(0);\n  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) Serial.println(\"OLED nahi mila\");\n  if (imu.begin() != 0) Serial.println(\"MPU6050 nahi mila\");\n  mic.setPins(MIC_BCLK, MIC_WS, -1, MIC_DIN);\n  if (!mic.begin(I2S_MODE_STD, RATE, I2S_DATA_BIT_WIDTH_16BIT, I2S_SLOT_MODE_MONO)) Serial.println(\"Mic start fail\");\n  spk.setPins(SPK_BCLK, SPK_LRC, SPK_DOUT);\n  if (!spk.begin(I2S_MODE_STD, RATE, I2S_DATA_BIT_WIDTH_16BIT, I2S_SLOT_MODE_MONO)) Serial.println(\"Amp start fail\");\n  sdOk = SD.begin(SD_CS);\n  Serial.println(sdOk ? \"SD ready\" : \"SD nahi mila (log band)\");\n  setState(IDLE);\n}\n\nvoid loop() {\n  imu.update();\n  unsigned long t = millis() - stateStart;\n  switch (state) {\n    case IDLE:\n      peak = 0;\n      if (digitalRead(RADAR) && t > 2000) {\n        head.write(90);\n        playTone(880, 120);\n        heard = false;\n        setState(LISTENING);\n      }\n      break;\n    case LISTENING:\n      peak = readPeak();\n      if (peak > 3000) heard = true;\n      if (heard && t > 4000) setState(THINKING);\n      else if (!heard && t > 6000) { head.write(0); setState(IDLE); }\n      break;\n    case THINKING:\n      // yahan asli Jarvis WiFi se AI API ko sawal bhejta\n      if (t > 1200) { turns++; logTurn(); setState(SPEAKING); }\n      break;\n    case SPEAKING:\n      playTone(523, 150);\n      playTone(659, 150);\n      playTone(784, 250);\n      head.write(0);\n      setState(IDLE);\n      break;\n  }\n  draw();\n  delay(20);\n}\n",
  "comps": [
   {
    "id": 1,
    "type": "inmp441",
    "x": 70,
    "y": 110,
    "level": 0.3,
    "freq": 300
   },
   {
    "id": 2,
    "type": "max98357",
    "x": 230,
    "y": 110
   },
   {
    "id": 3,
    "type": "speaker",
    "x": 355,
    "y": 130
   },
   {
    "id": 4,
    "type": "mpu6050",
    "x": 65,
    "y": 470,
    "addr": 104,
    "pitch": 0,
    "roll": 0,
    "spin": 0,
    "temp": 25
   },
   {
    "id": 5,
    "type": "oled",
    "x": 215,
    "y": 465,
    "addr": 60
   },
   {
    "id": 6,
    "type": "radar",
    "x": 345,
    "y": 470,
    "motion": true
   },
   {
    "id": 7,
    "type": "sdcard",
    "x": 90,
    "y": 590
   },
   {
    "id": 8,
    "type": "servo",
    "x": 300,
    "y": 580
   }
  ],
  "wires": [
   [
    "P:GPIO5",
    "c1:SCK"
   ],
   [
    "P:GPIO6",
    "c1:WS"
   ],
   [
    "P:GPIO7",
    "c1:SD"
   ],
   [
    "P:3V3",
    "c1:VDD"
   ],
   [
    "P:GND1",
    "c1:GND"
   ],
   [
    "P:GND2",
    "c1:LR"
   ],
   [
    "P:GPIO15",
    "c2:BCLK"
   ],
   [
    "P:GPIO16",
    "c2:LRC"
   ],
   [
    "P:GPIO17",
    "c2:DIN"
   ],
   [
    "P:5V",
    "c2:VIN"
   ],
   [
    "P:GND1",
    "c2:GND"
   ],
   [
    "c2:SPK+",
    "c3:+"
   ],
   [
    "c2:SPK-",
    "c3:-"
   ],
   [
    "P:GPIO8",
    "c4:SDA"
   ],
   [
    "P:GPIO9",
    "c4:SCL"
   ],
   [
    "P:3V3",
    "c4:VCC"
   ],
   [
    "P:GND1",
    "c4:GND"
   ],
   [
    "P:GPIO8",
    "c5:SDA"
   ],
   [
    "P:GPIO9",
    "c5:SCL"
   ],
   [
    "P:3V3",
    "c5:VCC"
   ],
   [
    "P:GND1",
    "c5:GND"
   ],
   [
    "P:5V",
    "c6:VIN"
   ],
   [
    "P:GND1",
    "c6:GND"
   ],
   [
    "P:GPIO4",
    "c6:OUT"
   ],
   [
    "P:GPIO12",
    "c7:SCK"
   ],
   [
    "P:GPIO13",
    "c7:MISO"
   ],
   [
    "P:GPIO11",
    "c7:MOSI"
   ],
   [
    "P:GPIO10",
    "c7:CS"
   ],
   [
    "P:5V",
    "c7:VCC"
   ],
   [
    "P:GND1",
    "c7:GND"
   ],
   [
    "P:GPIO18",
    "c8:SIG"
   ],
   [
    "P:5V",
    "c8:V"
   ],
   [
    "P:GND2",
    "c8:G"
   ]
  ],
  "board": "esp32s3"
 }
];
if (typeof module !== 'undefined') module.exports = { EXAMPLES };
