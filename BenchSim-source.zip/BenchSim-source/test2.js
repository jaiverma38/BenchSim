const { Sim } = require('./sim.js');
let fails = 0;
const ok = (c, m) => { if (!c) { fails++; console.log('FAIL', m); } else console.log('ok  ', m); };
function mk(board, code, comps, wires) {
  const s = new Sim(); s.setBoard(board); comps.forEach(c => c.id = c.id); s.setCircuit(comps, wires);
  const out = { t: '', w: [] }; s.onSerial = (x) => out.t += x; s.onWarn = (k, m) => out.w.push(k);
  s.start(s.compile(code).factory); return { s, out };
}
const run = (r, sec) => { let sn; for (let i = 0; i < sec * 60; i++) { r.s.advance(1e6 / 60, 50); sn = r.s.snapshot(); } return sn; };

// NPN transistor switches a LED from 5V via base resistor driven by D7
{
  const code = `void setup(){ pinMode(7,OUTPUT); digitalWrite(7,HIGH);} void loop(){ delay(100);}`;
  const comps = [{ id: 1, type: 'res', val: 1000 }, { id: 2, type: 'npn', val: 'BC547' }, { id: 3, type: 'res', val: 330 }, { id: 4, type: 'led', val: 'red' }];
  const wires = [['P:D7', 'c1:1'], ['c1:2', 'c2:B'], ['c2:E', 'P:GND1'], ['P:5V', 'c3:1'], ['c3:2', 'c4:A'], ['c4:K', 'c2:C']];
  const r = mk('uno', code, comps, wires); const sn = run(r, 0.5);
  ok(sn[4].b > 0.6, 'NPN switches LED on: b=' + sn[4].b.toFixed(2) + ' ic=' + (sn[2].ic * 1000).toFixed(1) + 'mA');
}
// MOSFET + motor with flyback diode, gate from D5
{
  const code = `void setup(){ pinMode(5,OUTPUT); digitalWrite(5,HIGH);} void loop(){ delay(100);}`;
  const comps = [{ id: 1, type: 'nmos' }, { id: 2, type: 'motor' }, { id: 3, type: 'batt', val: 9 }];
  const wires = [['P:D5', 'c1:G'], ['c1:S', 'P:GND1'], ['c3:-', 'P:GND2'], ['c3:+', 'c2:M1'], ['c2:M2', 'c1:D']];
  const r = mk('uno', code, comps, wires); const sn = run(r, 0.3);
  ok(Math.abs(sn[2].v) > 8 && sn[2].w !== 0, 'MOSFET drives motor: v=' + sn[2].v.toFixed(2) + ' w=' + sn[2].w.toFixed(2));
}
// motor straight from pin -> overcurrent warning
{
  const code = `void setup(){ pinMode(5,OUTPUT); digitalWrite(5,HIGH);} void loop(){ delay(100);}`;
  const r = mk('uno', code, [{ id: 1, type: 'motor' }], [['P:D5', 'c1:M1'], ['c1:M2', 'P:GND1']]); run(r, 0.5);
  ok(r.out.w.includes('ov5'), 'motor on pin -> overcurrent warn: ' + r.out.w.join(','));
}
// RC charge: 10k + 100uF from 5V ~ tau 1s
{
  const code = `void setup(){} void loop(){ delay(100);}`;
  const comps = [{ id: 1, type: 'res', val: 10000 }, { id: 2, type: 'cap', val: 100e-6 }, { id: 3, type: 'vmeter' }];
  const wires = [['P:5V', 'c1:1'], ['c1:2', 'c2:1'], ['c2:2', 'P:GND1'], ['c3:+', 'c2:1'], ['c3:-', 'c2:2']];
  const r = mk('uno', code, comps, wires); let sn = run(r, 1);
  ok(Math.abs(sn[3].v - 3.16) < 0.35, 'RC at 1 tau ~3.16V: ' + sn[3].v.toFixed(2));
  sn = run(r, 4); ok(sn[3].v > 4.8, 'RC at 5 tau ~5V: ' + sn[3].v.toFixed(2));
}
// ESP32: 12-bit ADC and 3.3V
{
  const code = `void setup(){ Serial.begin(115200);} void loop(){ Serial.println(analogRead(34)); delay(100);}`;
  const comps = [{ id: 1, type: 'pot', val: 0.5 }];
  const r = mk('esp32', code, comps, [['P:3V3', 'c1:1'], ['c1:W', 'P:GPIO34'], ['c1:2', 'P:GND1']]); run(r, 0.3);
  const v = +r.out.t.split('\n')[0]; ok(Math.abs(v - 2048) < 6, 'ESP32 12-bit mid: ' + v);
}
// ESP32 5V into input -> hv warn
{
  const r = mk('esp32', `void setup(){ pinMode(4,INPUT);} void loop(){ delay(100);}`, [], [['P:5V', 'P:GPIO4']]); run(r, 0.2);
  ok(r.out.w.includes('hv4'), '5V on 3.3V pin warns');
}
// Servo + 595 + interrupt + struct + enum
{
  const code = `#include <Servo.h>
enum Mode { IDLE, RUN = 5, STOP };
struct Pt { int x; int y; };
Servo sv; Pt p = {3, 4}; Pt arr[2]; volatile int hits = 0; Mode m = RUN;
void isr(){ hits++; }
void setup(){ Serial.begin(9600); sv.attach(9); sv.write(135); attachInterrupt(digitalPinToInterrupt(2), isr, FALLING); arr[1].x = 7; arr[1].y += p.y; Serial.println(m); Serial.println(STOP); Serial.println(arr[1].x + arr[1].y); }
void loop(){ if (hits > 0) { Serial.println(hits); hits = 0; } delay(20); }`;
  const comps = [{ id: 1, type: 'servo' }, { id: 2, type: 'btn', pressed: false }];
  const wires = [['P:D9', 'c1:SIG'], ['P:5V', 'c1:V'], ['P:GND1', 'c1:G'], ['P:5V', 'c2:1'], ['c2:2', 'P:D2'], ['P:D2', 'P:5V']];
  const r = mk('uno', code, comps, wires); let sn = run(r, 0.3);
  ok(sn[1].angle === 135, 'servo angle 135: ' + sn[1].angle);
  ok(r.out.t.startsWith('5\n6\n11\n'), 'enum/struct output: ' + JSON.stringify(r.out.t));
}
// interrupt via button (D2 pull-up style): button to GND, INPUT_PULLUP, FALLING
{
  const code = `volatile int n=0; void isr(){ n++; } void setup(){ Serial.begin(9600); pinMode(2,INPUT_PULLUP); attachInterrupt(0,isr,FALLING);} void loop(){ if(n){ Serial.println(n); n=0;} delay(10);}`;
  const comps = [{ id: 1, type: 'btn', pressed: false }]; const wires = [['P:D2', 'c1:1'], ['c1:2', 'P:GND1']];
  const r = mk('uno', code.replace('attachInterrupt(0,', 'attachInterrupt(digitalPinToInterrupt(2),'), comps, wires); run(r, 0.2);
  comps[0].pressed = true; r.s.touch(); run(r, 0.2); comps[0].pressed = false; r.s.touch(); run(r, 0.1);
  ok(r.out.t === '1\n', 'ISR fired once on FALLING: ' + JSON.stringify(r.out.t));
}
// HC-SR04 + pulseIn
{
  const code = `void setup(){ Serial.begin(9600); pinMode(9,OUTPUT); pinMode(10,INPUT);} void loop(){ digitalWrite(9,LOW); delayMicroseconds(2); digitalWrite(9,HIGH); delayMicroseconds(10); digitalWrite(9,LOW); long d = pulseIn(10,HIGH); Serial.println(d/58); delay(100);}`;
  const comps = [{ id: 1, type: 'hcsr04', dist: 100 }];
  const wires = [['P:5V', 'c1:VCC'], ['P:GND1', 'c1:GND'], ['P:D9', 'c1:TRIG'], ['P:D10', 'c1:ECHO']];
  const r = mk('uno', code, comps, wires); run(r, 0.5); const d = +r.out.t.split('\n')[0];
  ok(Math.abs(d - 100) <= 3, 'ultrasonic ~100cm: ' + d);
}
// LCD parallel + DHT
{
  const code = `#include <LiquidCrystal.h>
#include <DHT.h>
LiquidCrystal lcd(12, 11, 5, 4, 3, 2); DHT dht(7, DHT11);
void setup(){ lcd.begin(16,2); dht.begin(); lcd.print("Hello"); lcd.setCursor(0,1); }
void loop(){ float t = dht.readTemperature(); lcd.setCursor(0,1); lcd.print(t,1); lcd.print("C"); delay(500);}`;
  const comps = [{ id: 1, type: 'lcd' }, { id: 2, type: 'dht', temp: 26, hum: 50 }];
  const wires = [['P:5V', 'c1:VDD'], ['P:GND1', 'c1:GND'], ['P:D12', 'c1:RS'], ['P:D11', 'c1:E'], ['P:D5', 'c1:D4'], ['P:D4', 'c1:D5'], ['P:D3', 'c1:D6'], ['P:D2', 'c1:D7'], ['P:5V', 'c2:VCC'], ['P:GND2', 'c2:GND'], ['P:D7', 'c2:DATA']];
  const r = mk('uno', code, comps, wires); const sn = run(r, 1.2);
  ok(sn[1].lines && sn[1].lines[0].startsWith('Hello') && sn[1].lines[1].startsWith('26.0C'), 'LCD shows text: ' + JSON.stringify(sn[1].lines));
}
// 74HC595 + shiftOut lights Q0 and Q7
{
  const code = `void setup(){ pinMode(2,OUTPUT); pinMode(3,OUTPUT); pinMode(4,OUTPUT); digitalWrite(4,LOW); shiftOut(2,3,MSBFIRST,129); digitalWrite(4,HIGH); } void loop(){ delay(100);}`;
  const comps = [{ id: 1, type: 'ic595' }, { id: 2, type: 'res', val: 220 }, { id: 3, type: 'led', val: 'green' }, { id: 4, type: 'res', val: 220 }, { id: 5, type: 'led', val: 'red' }];
  const wires = [['P:5V', 'c1:VCC'], ['P:5V', 'c1:SRCLR'], ['P:GND1', 'c1:GND'], ['P:GND2', 'c1:OE'], ['P:D2', 'c1:SER'], ['P:D3', 'c1:SRCLK'], ['P:D4', 'c1:RCLK'],
    ['c1:Q0', 'c2:1'], ['c2:2', 'c3:A'], ['c3:K', 'P:GND3'], ['c1:Q7', 'c4:1'], ['c4:2', 'c5:A'], ['c5:K', 'P:GND3'], ['c1:Q3', 'c1:Q3']];
  const r = mk('uno', code, comps, wires); const sn = run(r, 0.3);
  ok(sn[3].b > 0.5 && sn[5].b > 0.5, '595 Q0 & Q7 lit (129=10000001): ' + sn[3].b.toFixed(2) + ',' + sn[5].b.toFixed(2));
}
// relay module + L298N sanity + diode/zener
{
  const code = `void setup(){ pinMode(8,OUTPUT); digitalWrite(8,LOW);} void loop(){ delay(100);}`;
  const comps = [{ id: 1, type: 'relaymod' }, { id: 2, type: 'batt', val: 9 }, { id: 3, type: 'res', val: 470 }, { id: 4, type: 'led', val: 'blue' }];
  const wires = [['P:5V', 'c1:VCC'], ['P:GND1', 'c1:GND'], ['P:D8', 'c1:IN'], ['c2:+', 'c1:COM'], ['c1:NO', 'c3:1'], ['c3:2', 'c4:A'], ['c4:K', 'c2:-']];
  const r = mk('uno', code, comps, wires); const sn = run(r, 0.3);
  ok(sn[1].on && sn[4].b > 0.5, 'relay module closes, LED on 9V: ' + sn[4].b.toFixed(2));
}
console.log(fails ? fails + ' FAILED' : 'ALL PASSED');
