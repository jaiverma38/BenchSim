const { Sim } = require('./sim.js');
const { compileSketch: _cs } = require('./compile.js'); const { BOARDS } = require('./boards.js'); const compileSketch = (c) => _cs(c, BOARDS.uno);
let fails = 0;
const ok = (c, m) => { if (!c) { fails++; console.log('FAIL', m); } else console.log('ok  ', m); };

function run(code, comps, wires, secs, setup) {
  const s = new Sim(); s.setCircuit(comps, wires);
  let out = ''; s.onSerial = (t) => out += t;
  const { factory } = compileSketch(code);
  s.start(factory); if (setup) setup(s);
  const frames = secs * 60;
  for (let i = 0; i < frames; i++) { s.advance(1e6 / 60, 50); }
  return { s, out, snap: s.snapshot() };
}

// Blink with resistor
const blink = `
const int ledPin = 13;
void setup(){ pinMode(ledPin, OUTPUT); Serial.begin(9600); }
void loop(){ digitalWrite(ledPin,HIGH); Serial.println("ON"); delay(1000); digitalWrite(ledPin,LOW); Serial.println("OFF"); delay(1000); }`;
const cLed = [{ id: 1, type: 'res', val: 220 }, { id: 2, type: 'led', val: 'red' }];
const wLed = [['P:D13', 'c1:1'], ['c1:2', 'c2:A'], ['c2:K', 'P:GND1']];
let r = run(blink, cLed, wLed, 2.5);
ok(r.out === 'ON\nOFF\nON\n', 'blink serial: ' + JSON.stringify(r.out));

// check LED brightness at ON phase (0.5s)
{
  const s = new Sim(); s.setCircuit(cLed, wLed); const { factory } = compileSketch(blink);
  s.start(factory); for (let i = 0; i < 30; i++) s.advance(1e6 / 60, 50);
  const a = s.snapshot(); ok(a[2].b > 0.7, 'LED bright at 0.5s: ' + a[2].b.toFixed(2));
  for (let i = 0; i < 33; i++) s.advance(1e6 / 60, 50); s.snapshot();
  for (let i = 0; i < 30; i++) s.advance(1e6 / 60, 50);
  const b = s.snapshot(); ok(b[2].b < 0.05, 'LED dark at 1.5s: ' + b[2].b.toFixed(2));
}

// No resistor => burn
{
  const comps = [{ id: 2, type: 'led', val: 'red' }]; const wires = [['P:D13', 'c2:A'], ['c2:K', 'P:GND1']];
  const s = new Sim(); s.setCircuit(comps, wires); let w = [];
  s.onWarn = (k, m) => w.push(k);
  s.start(compileSketch(blink).factory); for (let i = 0; i < 90; i++) s.advance(1e6 / 60, 50);
  ok(w.some(k => k.startsWith('burn')), 'LED burns without resistor: ' + w.join(','));
}

// short circuit
{
  const s = new Sim(); s.setCircuit([], [['P:5V', 'P:GND1']]); let w = [];
  s.onWarn = (k) => w.push(k); s.start(compileSketch(blink).factory); s.advance(1000, 50);
  ok(w.includes('short'), 'short detected');
}

// pot + analogRead + float math + map
const pot = `
const int potPin = A0; const int ledPin = 9;
void setup(){ pinMode(ledPin, OUTPUT); Serial.begin(9600);}
void loop(){
  int raw = analogRead(potPin);
  int b = map(raw,0,1023,0,255);
  analogWrite(ledPin,b);
  Serial.print(raw); Serial.print(" "); Serial.print(raw*5.0/1023.0,2); Serial.print(" "); Serial.println(b);
  delay(200);
}`;
const cPot = [{ id: 1, type: 'pot', val: 0.5 }, { id: 2, type: 'res', val: 220 }, { id: 3, type: 'led', val: 'green' }];
const wPot = [['P:5V', 'c1:1'], ['c1:W', 'P:A0'], ['c1:2', 'P:GND2'], ['P:D9', 'c2:1'], ['c2:2', 'c3:A'], ['c3:K', 'P:GND3']];
r = run(pot, cPot, wPot, 1);
const first = r.out.split('\n')[0].split(' ');
ok(Math.abs(+first[0] - 512) <= 3, 'pot mid analogRead ~512: ' + first[0]);
ok(first[1] === '2.50', 'voltage 2.50: ' + first[1]);
ok(Math.abs(+first[2] - 128) <= 2, 'map ~128: ' + first[2]);
ok(r.snap[3].b > 0.2 && r.snap[3].b < 0.9, 'PWM LED mid brightness: ' + r.snap[3].b.toFixed(2));

// button with pulldown
const btn = `
const int bp = 2; const int lp = 13;
void setup(){ pinMode(bp, INPUT); pinMode(lp, OUTPUT); }
void loop(){ digitalWrite(lp, digitalRead(bp)); delay(10); }`;
const cB = [{ id: 1, type: 'btn', pressed: false }, { id: 2, type: 'res', val: 10000 }, { id: 3, type: 'res', val: 220 }, { id: 4, type: 'led', val: 'red' }];
const wB = [['P:5V', 'c1:1'], ['c1:2', 'P:D2'], ['P:D2', 'c2:1'], ['c2:2', 'P:GND1'], ['P:D13', 'c3:1'], ['c3:2', 'c4:A'], ['c4:K', 'P:GND2']];
{
  const s = new Sim(); s.setCircuit(cB, wB); s.start(compileSketch(btn).factory);
  for (let i = 0; i < 30; i++) s.advance(1e6 / 60, 50);
  let a = s.snapshot(); ok(a[4].b < 0.05, 'btn released LED off');
  cB[0].pressed = true; s.touch();
  for (let i = 0; i < 30; i++) s.advance(1e6 / 60, 50);
  a = s.snapshot(); ok(a[4].b > 0.5, 'btn pressed LED on: ' + a[4].b.toFixed(2));
}

// floating warning
{
  const c2 = [{ id: 1, type: 'btn', pressed: false }]; const w2 = [['P:5V', 'c1:1'], ['c1:2', 'P:D2']];
  const s = new Sim(); s.setCircuit(c2, w2); let w = []; s.onWarn = (k) => w.push(k);
  s.start(compileSketch(btn).factory); for (let i = 0; i < 10; i++) s.advance(1e6 / 60, 50);
  ok(w.includes('fl2'), 'floating pin warning');
}

// language features
const lang = `
#define N 5
int arr[N] = {1,2,3,4,5};
byte b = 250;
long big = 100000L;
unsigned long ms = 0;
int fact(int n){ if(n<=1) return 1; return n*fact(n-1); }
String name = "Hi";
void setup(){
  int sum=0;
  for(int i=0;i<N;i++){ sum += arr[i]; }
  Serial.println(sum);
  b += 10; Serial.println(b);
  int x = 32767; x++; Serial.println(x);
  Serial.println(7/2); Serial.println(7/2.0); Serial.println(-7%3);
  Serial.println(fact(5));
  Serial.println(big*3);
  Serial.println(name + " there " + 5);
  int k=0; while(true){ k++; if(k>=3) break; } Serial.println(k);
  switch(k){ case 3: Serial.println("three"); break; default: Serial.println("other"); }
  Serial.println(255, HEX); Serial.println(5, BIN);
  Serial.println((int)3.9); Serial.println(1.0/3);
  int m[2][2] = {{1,2},{3,4}}; Serial.println(m[1][0]);
  Serial.println(k > 2 ? "yes" : "no");
  char c = 'A'; c++; Serial.println(c);
  arr[2] += 10; arr[3]++; Serial.println(arr[2] + arr[3]);
  Serial.println(constrain(15,0,10));
}
void loop(){ delay(1000); }`;
r = run(lang, [], [], 0.1);
const want = ['15', '4', '-32768', '3', '3.50', '-1', '120', '300000', 'Hi there 5', '3', 'three', 'FF', '101', '3', '0.33', '3', 'yes', 'B', '18', '10'];
ok(r.out.split('\n').slice(0, want.length).join('|') === want.join('|'), 'language features:\n' + r.out.split('\n').join('|'));

// error messages
for (const bad of ['void setup(){ foo(); } void loop(){}', 'void setup(){ int x = 5 } void loop(){}', 'void setup(){ y = 3; } void loop(){}', '#include <Stepper.h>\nvoid setup(){} void loop(){}', 'void setup(){}']) {
  try { compileSketch(bad); ok(false, 'should error: ' + bad); } catch (e) { ok(e.isC, 'error line ' + e.line + ': ' + e.message); }
}

// buzzer tone
{
  const tone = `void setup(){ pinMode(8,OUTPUT); } void loop(){ tone(8,440,200); delay(500); }`;
  const comps = [{ id: 1, type: 'buzzp' }]; const wires = [['P:D8', 'c1:+'], ['c1:-', 'P:GND1']];
  const s = new Sim(); s.setCircuit(comps, wires); s.start(compileSketch(tone).factory);
  for (let i = 0; i < 6; i++) s.advance(1e6 / 60, 50);
  const a = s.snapshot(); ok(a[1].on && a[1].freq === 440, 'buzzer tone 440 on: ' + JSON.stringify(a[1]));
  for (let i = 0; i < 15; i++) s.advance(1e6 / 60, 50); s.snapshot();
  for (let i = 0; i < 6; i++) s.advance(1e6 / 60, 50);
  const b = s.snapshot(); ok(!b[1].on, 'buzzer off after duration');
}
// millis-based busy loop
{
  const code = `unsigned long t0; void setup(){ t0=millis(); while(millis()-t0<500){} Serial.println(millis()); } void loop(){ delay(1000);}`;
  r = run(code, [], [], 1); ok(r.out.trim() === '500' || r.out.trim() === '501', 'busy-wait millis: ' + r.out.trim());
}
console.log(fails ? fails + ' FAILED' : 'ALL PASSED');
