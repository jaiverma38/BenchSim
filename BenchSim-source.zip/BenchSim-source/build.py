import re
d = '/home/claude/bench/'
parts = ['lex.js', 'compile.js', 'boards.js', 'comps.js', 'comps2.js', 'comps3.js','comps4.js', 'libs.js','libs2.js', 'sim.js', 'render.js', 'lint.js', 'examples.js', 'ui.js']
out = []
for p in parts:
    s = open(d + p).read()
    s = re.sub(r"^if \(typeof require.*$", "", s, flags=re.M)
    s = re.sub(r"^if \(typeof module.*$", "", s, flags=re.M)
    s = re.sub(r"^if \(typeof require.*$", "", s, flags=re.M)
    out.append(s)
js = '\n'.join(out)
html = open(d + 'template.html').read().replace('/*__JS__*/', js)
open(d + 'BenchSim.html', 'w').write(html)
open(d + 'bundle.js', 'w').write(js)
print(len(html))
