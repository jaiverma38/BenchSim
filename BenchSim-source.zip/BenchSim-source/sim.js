// ===== Circuit solver + Arduino runtime (v2: boards + device models) =====
if (typeof require !== 'undefined' && typeof compileSketch === 'undefined') { var { compileSketch } = require('./compile.js'); var { BOARDS } = require('./boards.js'); var { COMPS } = require('./comps.js'); require('./comps2.js'); require('./comps3.js'); require('./comps4.js'); var { addLibs } = require('./libs.js'); }
const GMIN = 1e-9, PIN_RS = 25, PULL_RS = 20000;

function gauss(A, b, n) {
  for (let c = 0; c < n; c++) {
    let p = c, m = Math.abs(A[c][c]);
    for (let r = c + 1; r < n; r++) { const v = Math.abs(A[r][c]); if (v > m) { m = v; p = r; } }
    if (m < 1e-18) continue;
    if (p !== c) { const t = A[p]; A[p] = A[c]; A[c] = t; const u = b[p]; b[p] = b[c]; b[c] = u; }
    const piv = A[c][c];
    for (let r = c + 1; r < n; r++) {
      const f = A[r][c] / piv; if (f === 0) continue;
      const Ar = A[r], Ac = A[c];
      for (let k = c; k < n; k++) Ar[k] -= f * Ac[k];
      b[r] -= f * b[c];
    }
  }
  const x = new Float64Array(n);
  for (let r = n - 1; r >= 0; r--) {
    let s = b[r]; for (let k = r + 1; k < n; k++) s -= A[r][k] * x[k];
    x[r] = A[r][r] === 0 ? 0 : s / A[r][r];
  }
  return x;
}

class Sim {
  constructor() {
    this.comps = []; this.wires = [];
    this.onSerial = () => { }; this.onWarn = () => { }; this.onStop = () => { };
    this.running = false; this.netsDirty = true; this.serialIn = '';
    this.setBoard('uno');
  }
  setBoard(id) { this.board = BOARDS[id]; this.netsDirty = true; this.resetState(); }
  resetState() {
    this.pins = []; this.board.pins.forEach(bp => { this.pins[bp.i] = { mode: 0, level: 0, duty: null, pullup: false, tone: 0, toneEnd: 0, rise: -1e12, fall: -1e12, servo: 0 }; });
    this.st = {}; this.res = null; this.lastT = 0; this.frameT = 0; this.libs = []; this.irqs = []; this.adcMax = 0; this.ledc = { pin: {}, ch: {} }; this.i2cPins = null; this.spiPins = null; this.sdOk = false;
    this.warns = new Map(); this.floatNoise = {}; this.shorted = false; this.serialIn = ''; this.ovT = {}; this.dyn = false;
  }
  setCircuit(comps, wires) { this.comps = comps; this.wires = wires; this.netsDirty = true; if (this.running) this.touch(); }
  stOf(c) { return this.st[c.id] || (this.st[c.id] = { acc: {}, stress: {}, burnt: false }); }
  warn(key, msg, level) {
    if (this.warns.has(key)) return;
    this.warns.set(key, { msg, level: level || 'warn' }); this.onWarn(key, msg, level || 'warn');
  }
  pinTerm(i) { return this.board.pinTerm.get(i); }

  // ---- netlist ----
  buildNets() {
    const parent = new Map();
    const find = (a) => { while (parent.get(a) !== a) { parent.set(a, parent.get(parent.get(a))); a = parent.get(a); } return a; };
    const add = (a) => { if (!parent.has(a)) parent.set(a, a); };
    const union = (a, b) => { add(a); add(b); const ra = find(a), rb = find(b); if (ra !== rb) parent.set(ra, rb); };
    this.board.pins.forEach(bp => add('P:' + bp.name));
    ['P:5V', 'P:3V3', 'P:GND1', 'P:GND2', 'P:GND3'].forEach(add);
    union('P:GND1', 'P:GND2'); union('P:GND2', 'P:GND3');
    const used = new Set(['P:5V', 'P:3V3', 'P:GND1']);
    for (const c of this.comps) { const d = COMPS[c.type]; if (!d) continue; for (const t in d.terms) { add(`c${c.id}:${t}`); used.add(`c${c.id}:${t}`); } }
    for (const w of this.wires) if (parent.has(w[0]) && parent.has(w[1])) { union(w[0], w[1]); used.add(w[0]); used.add(w[1]); }
    const usedRoots = new Set([...used].map(find)), cidx = new Map(); let n = 0;
    for (const r of usedRoots) cidx.set(r, n++);
    this.node = new Map(); this.root = new Map();
    for (const t of parent.keys()) { const r = find(t); this.root.set(t, r); this.node.set(t, cidx.has(r) ? cidx.get(r) : n); }
    this.n = n; this.netsDirty = false;
  }
  nd(t) { if (this.netsDirty) this.buildNets(); const v = this.node.get(t); return v === undefined ? this.n : v; }
  sameNet(pinIdx, c, term) { if (this.netsDirty) this.buildNets(); const a = this.root.get(this.pinTerm(pinIdx)), b = this.root.get(`c${c.id}:${term}`); return a !== undefined && a === b; }
  netsEqual(c1, t1, c2, t2) { if (this.netsDirty) this.buildNets(); const a = this.root.get(`c${c1.id}:${t1}`), b = this.root.get(`c${c2.id}:${t2}`); return a !== undefined && a === b; }
  volt(t) { const i = this.nd(t); return this.res && i < this.n ? this.res.V[i] : 0; }
  cv(c, a, b) { return this.volt(`c${c.id}:${a}`) - (b ? this.volt(`c${c.id}:${b}`) : 0); }
  powered(c, vp, gn, min) { return this.cv(c, vp, gn) > (min || 2.7); }
  pinDriver(c, term) { // which MCU output pin is wired to this comp terminal
    if (this.netsDirty) this.buildNets();
    const r = this.root.get(`c${c.id}:${term}`);
    for (const bp of this.board.pins) { const p = this.pins[bp.i]; if (p && p.mode === 1 && this.root.get('P:' + bp.name) === r) return bp.i; }
    return -1;
  }

  // ---- one electrical solve for fixed pin voltages ----
  solvePhase(lv, dt, post) {
    const n = this.n, vcc = this.board.vcc;
    let V, reach, guard = 0, pinI = {}, rail5 = 0, rail3 = 0, srcNodes, edges;
    const devs = [];
    for (const c of this.comps) {
      const def = COMPS[c.type]; if (!def || !def.model) continue;
      const st = this.stOf(c); if (st.burnt) continue;
      const h = { t: (nm) => this.nd(`c${c.id}:${nm}`), st, sim: this, dt, c, vcc };
      const d = def.model(c, h); if (d) devs.push({ c, d, def });
    }
    this.dyn = devs.some(x => x.d.post);
    for (; guard < 40; guard++) {
      const G = Array.from({ length: n }, () => new Float64Array(n)), I = new Float64Array(n);
      srcNodes = new Set(); edges = []; const srcs = [];
      const ok = (a) => a !== undefined && a >= 0 && a < n;
      const x = {
        res(a, b, R) { if (!ok(a) || !ok(b) || a === b) return; const g = 1 / R; G[a][a] += g; G[b][b] += g; G[a][b] -= g; G[b][a] -= g; edges.push([a, b]); },
        src(a, Vs, Rs, tag) { if (!ok(a)) return; const g = 1 / Rs; G[a][a] += g; I[a] += Vs * g; srcNodes.add(a); srcs.push({ a, V: Vs, Rs, tag }); },
        fsrc(a, b, Vs, Rs) { if (!ok(a) || !ok(b) || a === b) return; const g = 1 / Rs; G[a][a] += g; G[b][b] += g; G[a][b] -= g; G[b][a] -= g; I[a] += Vs * g; I[b] -= Vs * g; edges.push([a, b]); },
        inj(a, Ia) { if (ok(a)) I[a] += Ia; },
        vccs(oP, oN, cP, cN, gm) { if (ok(oP)) { if (ok(cP)) G[oP][cP] += gm; if (ok(cN)) G[oP][cN] -= gm; } if (ok(oN)) { if (ok(cP)) G[oN][cP] -= gm; if (ok(cN)) G[oN][cN] += gm; } if (ok(oP) && ok(oN)) edges.push([oP, oN]); },
        edge(a, b) { if (ok(a) && ok(b)) edges.push([a, b]); },
      };
      for (let i = 0; i < n; i++) G[i][i] += GMIN;
      x.src(this.nd('P:5V'), 5, 0.1, '5V'); x.src(this.nd('P:3V3'), 3.3, 0.5, '3V3'); x.src(this.nd('P:GND1'), 0, 0.01, 'GND');
      for (const bp of this.board.pins) {
        const p = this.pins[bp.i], nn = this.nd('P:' + bp.name);
        if (p.mode === 1) x.src(nn, lv[bp.i], PIN_RS, bp.i); else if (p.mode === 2 || p.pullup) x.src(nn, vcc, PULL_RS, 'pu' + bp.i); else if (p.mode === 3) x.src(nn, 0, PULL_RS, 'pd' + bp.i);
      }
      for (const e of devs) e.d.stamp(x);
      V = gauss(G, I, n);
      let changed = false;
      for (const e of devs) if (e.d.update && e.d.update(V)) changed = true;
      if (!changed) {
        for (const s of srcs) { const cur = (s.V - V[s.a]) / s.Rs; if (typeof s.tag === 'number') pinI[s.tag] = Math.abs(cur); else if (s.tag === '5V') rail5 = Math.abs(cur); else if (s.tag === '3V3') rail3 = Math.abs(cur); }
        break;
      }
    }
    const adj = Array.from({ length: n }, () => []);
    for (const [a, b] of edges) { adj[a].push(b); adj[b].push(a); }
    reach = new Uint8Array(n); const q = [...srcNodes]; for (const s of q) reach[s] = 1;
    while (q.length) { const a = q.pop(); for (const b of adj[a]) if (!reach[b]) { reach[b] = 1; q.push(b); } }
    const m = {};
    for (const e of devs) { if (e.d.meas) m[e.c.id] = e.d.meas(V); if (post && e.d.post) e.d.post(V); }
    return { V, reach, pinI, rail5, rail3, m };
  }

  // ---- full solve: PWM phases (or single averaged phase for transient steps) ----
  solve(dtc) {
    if (this.netsDirty) this.buildNets();
    const vcc = this.board.vcc, step = dtc > 0, dt = step ? dtc : 1e-3, n = this.n, K = 32;
    const maxI = Math.max(...this.board.pins.map(p => p.i)) + 1;
    const pw = [], base = new Float64Array(maxI);
    for (const bp of this.board.pins) {
      const p = this.pins[bp.i]; base[bp.i] = p.mode === 1 ? p.level * vcc : 0;
      if (p.mode === 1 && (p.tone > 0 || (p.duty !== null && p.duty > 0 && p.duty < 1))) pw.push(bp.i);
    }
    const phases = pw.length && !step ? K : 1;
    const res = { n, V: new Float64Array(n), m: {}, pinMax: {}, rail5: 0, rail3: 0, reach: new Uint8Array(n).fill(1) };
    for (let ph = 0; ph < phases; ph++) {
      const lv = Float64Array.from(base);
      for (const i of pw) { const p = this.pins[i]; if (step) lv[i] = p.tone > 0 ? vcc / 2 : p.duty * vcc; else lv[i] = p.tone > 0 ? (ph % 2 === 0 ? vcc : 0) : ((ph + 0.5) / K < p.duty ? vcc : 0); }
      const r = this.solvePhase(lv, dt, step && ph === phases - 1);
      for (let i = 0; i < n; i++) { res.V[i] += r.V[i] / phases; if (!r.reach[i]) res.reach[i] = 0; }
      for (const id in r.m) { const o = res.m[id] || (res.m[id] = {}); for (const k in r.m[id]) { const v = r.m[id][k]; o[k] = k.startsWith('max') ? Math.max(o[k] === undefined ? -Infinity : o[k], v) : (o[k] || 0) + v / phases; } }
      for (const i in r.pinI) res.pinMax[i] = Math.max(res.pinMax[i] || 0, r.pinI[i]);
      res.rail5 = Math.max(res.rail5, r.rail5); res.rail3 = Math.max(res.rail3, r.rail3);
    }
    return res;
  }

  // ---- time integration ----
  accum(res, dt) {
    for (const c of this.comps) {
      const m = res.m[c.id], def = COMPS[c.type]; if (!m) continue;
      const s = this.stOf(c);
      for (const k in m) s.acc[k] = (s.acc[k] || 0) + m[k] * dt;
      if (def.rate) for (const r of def.rate) {
        const v = m[r.k] || 0, key = r.k, lim = typeof r.lim === 'function' ? r.lim(c) : r.lim;
        if (v > lim && !s.burnt) {
          s.stress[key] = (s.stress[key] || 0) + dt;
          if (s.stress[key] > r.t) { s.burnt = true; this.warn('burn' + c.id, r.msg(c, v), 'err'); this.resolveNow(); }
        } else if (s.stress[key] > 0) s.stress[key] = Math.max(0, s.stress[key] - dt * 0.5);
      }
    }
    for (const k in res.pinMax) {
      if (res.pinMax[k] > 0.04) { this.ovT[k] = (this.ovT[k] || 0) + dt; if (this.ovT[k] > 20000) this.warn('ov' + k, `${this.pname(+k)} par ${(res.pinMax[k] * 1000).toFixed(0)} mA current khich raha hai. Pin ki limit 40 mA hai (aaram se 20 mA). Resistor lagao, ya motor/relay ke liye transistor use karo.`, 'err'); }
      else this.ovT[k] = 0;
    }
  }
  pname(i) { const p = this.board.byIdx.get(i); return p ? p.name : 'pin ' + i; }
  integrate(t) {
    const dt = t - this.lastT;
    if (dt > 0 && this.res) {
      if (this.dyn) {
        const ns = Math.min(16, Math.max(1, Math.ceil(dt / 2000))), h = dt / ns;
        for (let s = 0; s < ns; s++) { const r = this.solve(h / 1e6); this.res = r; this.accum(r, h); }
      } else this.accum(this.res, dt);
    }
    this.lastT = t;
  }
  advanceTo(t) {
    for (;;) {
      let te = Infinity, pi = -1;
      this.pins.forEach((p, i) => { if (p && p.toneEnd > 0 && p.toneEnd < te) { te = p.toneEnd; pi = i; } });
      if (pi < 0 || te > t) break;
      this.integrate(te); this.pins[pi].tone = 0; this.pins[pi].toneEnd = 0; this.resolveNow();
    }
    this.integrate(t);
  }
  resolveNow() {
    for (let k = 0; k < 4; k++) {
      this.res = this.solve(); let ch = false;
      for (const c of this.comps) { const d = COMPS[c.type]; if (d && d.onSolved && d.onSolved(c, this.stOf(c), this)) ch = true; }
      if (!ch) break;
    }
    const r = this.res, vcc = this.board.vcc;
    if (r.rail5 > 1 || r.rail3 > 0.5) { this.shorted = true; this.warn('short', 'SHORT CIRCUIT! Power aur GND seedha jud gaye. Asli board mein USB band ho jaata ya chip kharab hoti. Wire hatao.', 'err'); this.onStop('short'); }
    else if (r.rail5 > 0.5) this.warn('rail', `5V pin se ${(r.rail5 * 1000).toFixed(0)} mA khich raha hai. USB sirf ~500 mA deta hai. Motor/servo ke liye alag supply (battery) lagao.`);
    if (vcc < 4) for (const bp of this.board.pins) { const p = this.pins[bp.i]; if (p.mode !== 1) { const nn = this.nd('P:' + bp.name); if (nn < this.n && r.V[nn] > vcc + 0.6) this.warn('hv' + bp.i, `${bp.name} par ${r.V[nn].toFixed(1)}V aa raha hai, par ye board 3.3V ka hai. Pin kharab ho sakta hai. Voltage divider ya level shifter lagao.`, 'err'); } }
    this.checkIrqs();
  }
  touch() { if (!this.running || !this.B) return; this.advanceTo(this.B.now); this.resolveNow(); }
  levelNow(i) {
    const p = this.pins[i]; if (!p) return 0;
    if (p.mode === 1) return p.duty !== null ? (p.duty > 0.5 ? 1 : 0) : p.level;
    const nn = this.nd(this.pinTerm(i)); if (!this.res || nn >= this.n) return p.pullup || p.mode === 2 ? 1 : 0;
    return this.res.V[nn] >= this.board.vcc / 2 ? 1 : 0;
  }
  checkIrqs() {
    for (const q of this.irqs) {
      const cur = this.levelNow(q.pin); if (q.last === undefined) { q.last = cur; continue; }
      if (cur !== q.last) {
        const rising = cur === 1; q.last = cur;
        if (q.mode === 1 || (q.mode === 3 && rising) || (q.mode === 2 && !rising)) this.B.pending.push(q.fn);
      }
    }
  }

  snapshot() {
    if (!this.running || !this.B) return null;
    this.advanceTo(this.B.now);
    const dur = Math.max(1, this.B.now - this.frameT), out = {};
    for (const c of this.comps) {
      const s = this.stOf(c), def = COMPS[c.type], o = { burnt: s.burnt };
      for (const k in s.acc) o[k] = s.acc[k] / dur; s.acc = {};
      if (def && def.state) Object.assign(o, def.state(c, s, this, o));
      out[c.id] = o;
    }
    this.frameT = this.B.now;
    return out;
  }
  readNet(i) {
    if (this.netsDirty) this.buildNets(); if (!this.res) this.res = this.solve();
    const nn = this.nd(this.pinTerm(i)); if (nn >= this.n) return { v: 0, floating: true };
    return { v: this.res.V[nn], floating: !this.res.reach[nn] };
  }

  // ---- program control ----
  compile(code) { return compileSketch(code, this.board); }
  start(factory) {
    this.resetState(); this.running = true;
    this.B = this.makeB(); this.gen = factory(this.B);
    this.target = 0; this.sleeping = false; this.halted = false;
    this.buildNets(); this.res = this.solve(); this.B.now = 0; this.B.limit = 0; this.resolveNow();
  }
  stop() { this.running = false; this.B = null; this.gen = null; this.res = null; this.st = {}; }
  runIsrs() {
    const B = this.B;
    while (B.pending.length) { const f = B.pending.shift(); try { const it = f(); for (let k = 0; k < 50000; k++) if (it.next().done) break; } catch (e) { this.warn('isr' + Date.now(), 'ISR mein error: ' + e.message, 'err'); } }
  }
  advance(dtUs, wallMs) {
    if (!this.running || this.halted) return;
    const B = this.B, t0 = Date.now();
    this.target += dtUs; B.limit = this.target;
    try {
      for (;;) {
        this.runIsrs();
        if (this.sleeping) {
          if (B.wake <= this.target) { B.now = B.wake; this.sleeping = false; }
          else { B.now = Math.max(B.now, this.target); break; }
        }
        const r = this.gen.next();
        if (r.done) { this.halted = true; break; }
        if (r.value === 1) { this.sleeping = true; continue; }
        if (B.now >= this.target) break;
        if (Date.now() - t0 > wallMs) { this.target = B.now; break; }
        if (this.shorted) break;
      }
    } catch (e) {
      this.halted = true;
      const msg = e instanceof RangeError ? 'Stack overflow: function khud ko bina ruke call kar raha hai' : 'Runtime error: ' + e.message;
      this.warn('rt' + Date.now(), msg, 'err'); this.onStop('error');
    }
    if (this.target < B.now) this.target = B.now;
  }

  makeB() {
    const sim = this, pins = this.pins, bd = this.board, vcc = bd.vcc;
    const P = (p, fn) => { p = Math.trunc(p); const o = pins[p]; if (!o) { sim.warn('bp' + fn + p, `${fn}(${p}): ${bd.name} par pin ${p} nahi hai.`); return null; } return o; };
    let rs = 1;
    const B = {
      now: 0, limit: 0, wake: 0, pending: [],
      pinMode(p, m) {
        const o = P(p, 'pinMode'); if (!o) return; m = Math.trunc(m);
        { const bp0 = bd.byIdx.get(Math.trunc(p)); if (bp0 && bp0.note) sim.warn('pn' + p, `${bp0.name}: ${bp0.note}`); }
        if (m === 1 && bd.byIdx.get(Math.trunc(p)).inOnly) sim.warn('io' + p, `GPIO${p} sirf input hai, OUTPUT nahi ho sakta.`);
        if (o.mode !== m || o.pullup !== (m === 2)) { o.mode = m; o.pullup = m === 2; if (m !== 1) { o.tone = 0; o.duty = null; } if (m === 1) o.level = 0; sim.touch(); }
      },
      setLevel(o, v, p) { if (o.level !== v) { if (v) o.rise = B.now; else o.fall = B.now; } o.level = v; },
      digitalWrite(p, v) {
        const o = P(p, 'digitalWrite'); if (!o) return; v = v ? 1 : 0;
        if (o.mode === 1) { const ch = o.level !== v || o.duty !== null; if (ch) { B.setLevel(o, v); o.duty = null; sim.touch(); } }
        else {
          sim.warn('nm' + p, `digitalWrite(${Math.trunc(p)}, ...) hua, par pinMode(${Math.trunc(p)}, OUTPUT) set nahi kiya. Pin sirf kamzor pull-up ban gaya hai, LED nahi jalegi.`);
          if (o.pullup !== !!v) { o.pullup = !!v; sim.touch(); }
        }
      },
      analogWrite(p, v) {
        const o = P(p, 'analogWrite'); if (!o) return; p = Math.trunc(p); v = Math.max(0, Math.min(255, Math.trunc(v)));
        if (o.mode !== 1) { o.mode = 1; o.pullup = false; }
        if (bd.pwmSet.has(p)) { if (v === 0) { B.setLevel(o, 0); o.duty = null; } else if (v === 255) { B.setLevel(o, 1); o.duty = null; } else { o.duty = v / 255; o.level = 1; } }
        else { sim.warn('npwm' + p, `${sim.pname(p)} PWM support nahi karta. Sirf ${[...bd.pwmSet].slice(0, 12).map(sim.pname.bind(sim)).join(', ')} par analogWrite se dimming hoti hai. Yahan sirf HIGH/LOW milega.`); B.setLevel(o, v >= 128 ? 1 : 0); o.duty = null; }
        sim.touch();
      },
      digitalRead(p) {
        const o = P(p, 'digitalRead'); if (!o) return 0; p = Math.trunc(p);
        if (o.mode === 1) return o.level;
        const r = sim.readNet(p);
        if (r.floating && !o.pullup && o.mode !== 2 && o.mode !== 3) { sim.warn('fl' + p, `${sim.pname(p)} floating hai (kisi se connected nahi). Reading random aayegi. Button ke saath 10kΩ pull-down ya INPUT_PULLUP lagao.`); return Math.random() < 0.5 ? 1 : 0; }
        return r.v >= vcc / 2 ? 1 : 0;
      },
      analogRead(p) {
        p = Math.trunc(p); if (p >= 0 && p < bd.analogCount) p += bd.analogBase;
        const o = P(p, 'analogRead'); if (!o) return 0;
        if (!bd.byIdx.get(p).adc) { sim.warn('noadc' + p, `${sim.pname(p)} par ADC nahi hai. Analog pin use karo (A0, A1... ya ADC wale GPIO).`); return 0; }
        const AM = sim.adcMax || bd.adcMax;
        if (o.mode === 1) return o.level ? AM : 0;
        const r = sim.readNet(p);
        if (r.floating && !o.pullup && o.mode !== 2 && o.mode !== 3) {
          sim.warn('fl' + p, `${sim.pname(p)} floating hai, isliye reading random hai. Sensor ya pot sahi se connect karo.`);
          const prev = sim.floatNoise[p] === undefined ? AM * 0.3 : sim.floatNoise[p];
          const nv = Math.max(0, Math.min(AM, prev + Math.round((Math.random() - 0.5) * 0.12 * AM))); sim.floatNoise[p] = nv; return nv;
        }
        let v = Math.round(Math.max(0, Math.min(vcc, r.v)) / vcc * AM);
        if (Math.random() < 0.15) v += Math.random() < 0.5 ? -1 : 1;
        return Math.max(0, Math.min(AM, v));
      },
      *delay(ms) { ms = Math.max(0, Math.trunc(ms)); if (ms === 0) { B.now += 1; return; } B.wake = B.now + ms * 1000; yield 1; },
      *delayUs(us) { us = Math.max(0, Math.trunc(us)); B.now += us; if (B.now >= B.limit) yield 0; },
      millis() { return Math.floor(B.now / 1000) >>> 0; },
      micros() { return Math.floor(B.now / 4) * 4 >>> 0; },
      tone(p, f, d) {
        const o = P(p, 'tone'); if (!o) return; f = Math.trunc(f);
        if (f > 0) { o.mode = 1; o.pullup = false; o.tone = f; o.toneEnd = d > 0 ? B.now + d * 1000 : 0; } else { o.tone = 0; o.toneEnd = 0; o.level = 0; }
        sim.touch();
      },
      attachInterrupt(p, fn, mode) {
        p = Math.trunc(p); if (!bd.irqSet.has(p)) { sim.warn('irq' + p, `${sim.pname(p)} par interrupt nahi hai. ${bd.name} par interrupt pins: ${[...bd.irqSet].slice(0, 8).map(sim.pname.bind(sim)).join(', ')}`); return; }
        sim.irqs = sim.irqs.filter(q => q.pin !== p); sim.irqs.push({ pin: p, fn, mode: Math.trunc(mode), last: sim.levelNow(p) });
      },
      detachInterrupt(p) { sim.irqs = sim.irqs.filter(q => q.pin !== Math.trunc(p)); },
      map(x, a, b, c, d) { x = Math.trunc(x); a = Math.trunc(a); b = Math.trunc(b); c = Math.trunc(c); d = Math.trunc(d); return b === a ? c : (Math.trunc((x - a) * (d - c) / (b - a)) + c) | 0; },
      seed(s) { rs = (Math.trunc(s) || 1) >>> 0; },
      random(a, b) { a = Math.trunc(a); b = Math.trunc(b); if (b <= a) return a; rs = (Math.imul(rs, 1664525) + 1013904223) >>> 0; return a + Math.floor((rs / 4294967296) * (b - a)); },
      idiv(a, b) { return b === 0 ? 0 : Math.trunc(a / b); },
      imod(a, b) { return b === 0 ? 0 : Math.trunc(a) % Math.trunc(b); },
      fmod(a, b) { return b === 0 ? NaN : a % b; },
      mkArr(list, size, fill) { const n = size === null ? list.length : size; const a = new Array(n).fill(fill); for (let i = 0; i < list.length && i < n; i++) a[i] = list[i]; return a; },
      cc(v) { return String.fromCharCode(v & 255); },
      adcMaxNow() { return sim.adcMax || bd.adcMax; },
      printf(f, ...a) {
        let i = 0; const out = String(f).replace(/%([-+ 0#]*)(\d*)(?:\.(\d+))?(l{0,2}|h{0,2}|z)([diuxXfFeEgGcsp%])/g, (m0, fl, w, pr, lm, c) => {
          if (c === '%') return '%'; let v = a[i++], s;
          if (c === 'd' || c === 'i') s = String(Math.trunc(+v)); else if (c === 'u') s = String(Math.trunc(+v) >>> 0); else if (c === 'x') s = (Math.trunc(+v) >>> 0).toString(16); else if (c === 'X') s = (Math.trunc(+v) >>> 0).toString(16).toUpperCase();
          else if ('fFeEgG'.includes(c)) s = (+v).toFixed(pr === undefined ? 6 : +pr); else if (c === 'c') s = typeof v === 'number' ? String.fromCharCode(v) : String(v); else s = String(v);
          if (w) { const wn = +w; s = fl.includes('-') ? s.padEnd(wn) : s.padStart(wn, fl.includes('0') && c !== 's' ? '0' : ' '); } return s;
        }); sim.onSerial(out);
      },
      ledcAttach(p, f, r) { sim.ledc.pin[Math.trunc(p)] = { res: Math.trunc(r) }; const o = P(p, 'ledcAttach'); if (o) { o.mode = 1; o.pullup = false; } },
      ledcSetup(ch, f, r) { sim.ledc.ch[Math.trunc(ch)] = { res: Math.trunc(r), pin: -1 }; },
      ledcAttachPin(p, ch) { const c = sim.ledc.ch[Math.trunc(ch)]; if (!c) { sim.warn('ledcs', 'ledcAttachPin se pehle ledcSetup(channel, freq, bits) karo.'); return; } c.pin = Math.trunc(p); sim.ledc.pin[c.pin] = { res: c.res }; const o = P(p, 'ledcAttachPin'); if (o) { o.mode = 1; o.pullup = false; } },
      ledcWrite(x, duty) {
        x = Math.trunc(x); let pin = -1, res = 8; if (sim.ledc.pin[x]) { pin = x; res = sim.ledc.pin[x].res; } else if (sim.ledc.ch[x] && sim.ledc.ch[x].pin >= 0) { pin = sim.ledc.ch[x].pin; res = sim.ledc.ch[x].res; }
        if (pin < 0) { sim.warn('ledcn' + x, `ledcWrite(${x}, ...): pehle ledcAttach(pin, freq, bits) karo.`); return; }
        const o = pins[pin]; if (!o) return; const fr = Math.max(0, Math.min(1, duty / (Math.pow(2, res) - 1)));
        if (fr <= 0) { B.setLevel(o, 0); o.duty = null; } else if (fr >= 1) { B.setLevel(o, 1); o.duty = null; } else { o.duty = fr; o.level = 1; } sim.touch();
      },
      newArrF(n, f) { return Array.from({ length: Math.max(0, Math.trunc(n)) }, f); },
      adcRes(b) { sim.adcMax = Math.pow(2, Math.max(1, Math.min(16, Math.trunc(b)))) - 1; },
      newArr(n, fill) { return new Array(Math.max(0, Math.trunc(n))).fill(fill); },
      newArr2(r, c, fill) { return Array.from({ length: Math.max(0, Math.trunc(r)) }, () => new Array(Math.max(0, Math.trunc(c))).fill(fill)); },
      clone(o) { return o && typeof o === 'object' ? JSON.parse(JSON.stringify(o)) : o; },
      str(v, t) { if (t === 'str') return v; if (t === 'char') return String.fromCharCode(v & 255); if (t === 'float') return isFinite(v) ? v.toFixed(2) : String(v); return String(v); },
      toInt(s) { const m = /^\s*[-+]?\d+/.exec(s); return m ? parseInt(m[0], 10) | 0 : 0; },
      toFloat(s) { const v = parseFloat(s); return isNaN(v) ? 0 : v; },
      fmt(v, t, f) {
        if (t === 'str') return v; if (t === 'char') return String.fromCharCode(v & 255);
        if (t === 'float') return !isFinite(v) ? (isNaN(v) ? 'nan' : (v > 0 ? 'inf' : '-inf')) : v.toFixed(f === undefined ? 2 : Math.trunc(f));
        if (t === 'bool') return v ? '1' : '0';
        const base = f === undefined ? 10 : Math.trunc(f); if (base === 10 || base < 2) return String(v);
        let u = v; if (v < 0) u = t === 'long' ? v >>> 0 : v & 0xFFFF; return u.toString(base).toUpperCase();
      },
      sprint(v, t, f, nl) { const s = B.fmt(v, t, f); sim.onSerial(nl ? s + '\n' : s); },
      sAvail() { return sim.serialIn.length; },
      sRead() { if (!sim.serialIn.length) return -1; const c = sim.serialIn.charCodeAt(0); sim.serialIn = sim.serialIn.slice(1); return c; },
      sPeek() { return sim.serialIn.length ? sim.serialIn.charCodeAt(0) : -1; },
      sParseInt() { const m = /[-+]?\d+/.exec(sim.serialIn); if (!m) { sim.serialIn = ''; return 0; } sim.serialIn = sim.serialIn.slice(m.index + m[0].length); return parseInt(m[0], 10) | 0; },
      sParseFloat() { const m = /[-+]?\d*\.?\d+/.exec(sim.serialIn); if (!m) { sim.serialIn = ''; return 0; } sim.serialIn = sim.serialIn.slice(m.index + m[0].length); return parseFloat(m[0]); },
      sReadStr(ch) { let s = sim.serialIn; if (ch !== null && ch !== undefined) { const i = s.indexOf(String.fromCharCode(ch)); if (i >= 0) { sim.serialIn = s.slice(i + 1); return s.slice(0, i); } } sim.serialIn = ''; return s; },
    };
    addLibs(sim, B, P);
    return B;
  }
}

if (typeof module !== 'undefined') module.exports = { Sim };
