// ===== Rendering helpers for components =====
const PREFIX = { led: 'LED', res: 'R', btn: 'BTN', sw: 'SW', pot: 'POT', buzz: 'BZ', buzzp: 'BZ', ldr: 'LDR', ntc: 'NTC', cap: 'C', ind: 'L', diode: 'D', zener: 'DZ', npn: 'Q', pnp: 'Q', nmos: 'Q', pmos: 'Q', rgb: 'RGB', seg7: 'SEG', lcd: 'LCD', lcdi2c: 'LCD', batt: 'BAT', psu: 'PSU', motor: 'M', servo: 'SV', relay: 'K', relaymod: 'K', hbridge: 'DRV', reg7805: 'U', vmeter: 'VM', ameter: 'AM', rail: 'RAIL', gnd: 'GND', lm35: 'LM35', tmp36: 'TMP', dht: 'DHT', hcsr04: 'US', pir: 'PIR', irsens: 'IR', soil: 'SOIL', gas: 'MQ', joy: 'JOY', ic595: 'U', mpu6050: 'IMU', oled: 'OLED', inmp441: 'MIC', vl53: 'TOF', sdcard: 'SD', radar: 'RDR', camera: 'CAM', tb6612: 'DRV', mt3608: 'BST', max98357: 'AMP', speaker: 'SPK' };
function compMarkup(c) {
  const d = COMPS[c.type], [bx, by, bw, bh] = d.box;
  const terms = Object.keys(d.terms).map(k => termMarkup(`c${c.id}:${k}`, d.terms[k][0], d.terms[k][1], 'ct')).join('');
  const lab = d.lab ? d.lab(c) : c.label;
  return `<rect class="chit" x="${bx}" y="${by}" width="${bw}" height="${bh}" rx="10"/>${d.draw(c)}<text class="clab" x="0" y="${by + bh + 10}" text-anchor="middle">${lab}</text>${terms}`;
}
if (typeof module !== 'undefined') module.exports = { compMarkup, PREFIX };
