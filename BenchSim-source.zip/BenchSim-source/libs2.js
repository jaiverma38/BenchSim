// ===== Libraries part 2: I2C sensors, OLED, SD, I2S, camera =====
function addLibs2(sim, B, P) {
  const bd = sim.board;
  if (!sim.fs) sim.fs = new Map();
  const noise = (a) => (Math.random() - 0.5) * 2 * a;
  const pn = (i) => sim.pname(i);

  // find an I2C device of a type that is wired to the board's I2C pins and powered
  sim.i2c = (type, label, o) => {
    const cs = sim.comps.filter(c => c.type === type);
    if (!cs.length) { sim.warn('nodev' + type, `Sketch ${label} use kar rahi hai, par bench par ${label} nahi hai.`, 'err'); return null; }
    const [sda, scl] = sim.i2cPins || bd.i2c;
    const c = cs.find(q => sim.sameNet(sda, q, 'SDA') && sim.sameNet(scl, q, 'SCL'));
    if (!c) { sim.warn('i2cw' + type, `${label} ka SDA/SCL galat jagah hai. ${bd.name} par SDA = ${pn(sda)}, SCL = ${pn(scl)} hona chahiye (ya code mein Wire.begin(sda, scl) do).`, 'err'); return null; }
    const [vp, gn, min] = o.pw;
    if (!sim.powered(c, vp, gn, min)) { sim.warn('pw' + type + c.id, `${label} ko power nahi mil rahi (${vp} aur ${gn} check karo).`, 'err'); return null; }
    return c;
  };
  const addrCheck = (c, want, label) => { if (want !== undefined && c.addr !== undefined && c.addr !== want) { sim.warn('addr' + c.id, `${label} ka address 0x${c.addr.toString(16).toUpperCase()} hai, par code mein 0x${want.toString(16).toUpperCase()} diya hai.`, 'err'); return false; } return true; };

  // ---- MPU6050 (MPU6050_light API) ----
  class MPU6050 { constructor() { this.kind = 'MPU6050'; this.addr = 0x68; this.az = 0; this.lt = 0; this.v = null; }
    begin() { this.c = sim.i2c('mpu6050', 'MPU6050', { pw: ['VCC', 'GND', 2.4] }); if (!this.c) return 1; if (!addrCheck(this.c, this.addr, 'MPU6050')) { this.c = null; return 1; } this.lt = B.now; return 0; }
    setAddress(a) { this.addr = Math.trunc(a); } setFilterGyroCoef() { }
    *calcOffsets() { yield* B.delay(1000); }
    update() { const c = this.c; if (!c) return; const dt = Math.max(0, (B.now - this.lt) / 1e6); this.lt = B.now; const px = c.pitch * Math.PI / 180, py = c.roll * Math.PI / 180;
      this.az += c.spin * dt; this.v = { ax: Math.sin(py) + noise(0.004), ay: -Math.sin(px) * Math.cos(py) + noise(0.004), az: Math.cos(px) * Math.cos(py) + noise(0.004), gx: noise(0.3), gy: noise(0.3), gz: c.spin + noise(0.3), px: c.pitch + noise(0.05), py: c.roll + noise(0.05), t: c.temp + noise(0.1) }; }
    _g(k) { return this.v ? this.v[k] : 0; }
    getAccX() { return this._g('ax'); } getAccY() { return this._g('ay'); } getAccZ() { return this._g('az'); }
    getGyroX() { return this._g('gx'); } getGyroY() { return this._g('gy'); } getGyroZ() { return this._g('gz'); }
    getAngleX() { return this._g('px'); } getAngleY() { return this._g('py'); } getAngleZ() { return this.az; } getTemp() { return this._g('t'); } }

  // ---- OLED SSD1306 (Adafruit_SSD1306 API, command-list renderer) ----
  class SSD1306 { constructor(w, h) { this.kind = 'Adafruit_SSD1306'; this.w = w || 128; this.h = h || 64; this.cmds = []; this.shown = []; this.ver = 0; this.cx = 0; this.cy = 0; this.size = 1; this.col = 1; this.wrap = true; this.ok = false; this.inv = false; sim.libs.push(this); }
    begin(vcs, addr) { this.c = sim.i2c('oled', 'OLED SSD1306', { pw: ['VCC', 'GND', 2.7] }); if (!this.c) return 0; if (!addrCheck(this.c, addr === undefined ? 0x3C : Math.trunc(addr), 'OLED')) { this.c = null; return 0; } this.ok = true; return 1; }
    _p(o) { if (!this.ok) return; this.cmds.push(o); if (this.cmds.length > 4000) this.cmds.shift(); }
    clearDisplay() { this.cmds = []; this.cx = 0; this.cy = 0; }
    *display() { if (!this.ok) return; B.now += 20000; this.shown = this.cmds.slice(); this.ver++; if (B.now >= B.limit) yield 0; }
    setTextSize(s) { this.size = Math.max(1, Math.trunc(s)); } setTextColor(c) { this.col = Math.trunc(c); } setCursor(x, y) { this.cx = Math.trunc(x); this.cy = Math.trunc(y); } setTextWrap(w) { this.wrap = !!w; } setRotation() { } dim() { }
    width() { return this.w; } height() { return this.h; }
    invertDisplay(i) { this.inv = !!i; this._p({ t: 'inv', v: !!i }); }
    print(s) { s = String(s); const cw = 6 * this.size; let seg = '', sx = this.cx, sy = this.cy;
      const flush = () => { if (seg) this._p({ t: 'tx', x: sx, y: sy, s: seg, z: this.size, c: this.col }); seg = ''; };
      for (const ch of s) { if (ch === '\n') { flush(); this.cx = 0; this.cy += 8 * this.size; sx = this.cx; sy = this.cy; continue; } if (ch === '\r') continue;
        if (this.wrap && this.cx + cw > this.w) { flush(); this.cx = 0; this.cy += 8 * this.size; sx = 0; sy = this.cy; }
        if (!seg) { sx = this.cx; sy = this.cy; } seg += ch; this.cx += cw; } flush(); }
    println(s) { this.print((s === undefined ? '' : String(s)) + '\n'); } write(v) { this.print(typeof v === 'string' ? v : String.fromCharCode(v & 255)); }
    drawPixel(x, y, c) { this._p({ t: 'px', x: Math.trunc(x), y: Math.trunc(y), c: Math.trunc(c) }); }
    drawLine(x0, y0, x1, y1, c) { this._p({ t: 'ln', x0: Math.trunc(x0), y0: Math.trunc(y0), x1: Math.trunc(x1), y1: Math.trunc(y1), c: Math.trunc(c) }); }
    drawFastHLine(x, y, w, c) { this.drawLine(x, y, x + w - 1, y, c); } drawFastVLine(x, y, h, c) { this.drawLine(x, y, x, y + h - 1, c); }
    drawRect(x, y, w, h, c) { this._p({ t: 'rc', x: Math.trunc(x), y: Math.trunc(y), w: Math.trunc(w), h: Math.trunc(h), f: 0, c: Math.trunc(c) }); } fillRect(x, y, w, h, c) { this._p({ t: 'rc', x: Math.trunc(x), y: Math.trunc(y), w: Math.trunc(w), h: Math.trunc(h), f: 1, c: Math.trunc(c) }); }
    drawCircle(x, y, r, c) { this._p({ t: 'ci', x: Math.trunc(x), y: Math.trunc(y), r: Math.trunc(r), f: 0, c: Math.trunc(c) }); } fillCircle(x, y, r, c) { this._p({ t: 'ci', x: Math.trunc(x), y: Math.trunc(y), r: Math.trunc(r), f: 1, c: Math.trunc(c) }); } }

  // ---- VL53L0X (Pololu API) ----
  class VL53L0X { constructor() { this.kind = 'VL53L0X'; this.to = false; }
    init() { this.c = sim.i2c('vl53', 'VL53L0X', { pw: ['VIN', 'GND', 2.6] }); if (this.c && sim.cv(this.c, 'XSHUT', 'GND') < 0.8) { sim.warn('xsh' + this.c.id, 'VL53L0X ka XSHUT LOW hai, sensor band hai.', 'err'); this.c = null; } return this.c ? 1 : 0; }
    setTimeout() { } startContinuous() { } stopContinuous() { } setAddress() { } setMeasurementTimingBudget() { return 1; } timeoutOccurred() { const t = this.to; this.to = false; return t ? 1 : 0; }
    *readRangeContinuousMillimeters() { yield* B.delay(33); if (!this.c) { this.to = true; return 65535; } return this._m(); }
    *readRangeSingleMillimeters() { yield* B.delay(40); if (!this.c) { this.to = true; return 65535; } return this._m(); }
    _m() { const d = this.c.dist; if (d > 1200 || d < 0) return 8190; return Math.max(0, Math.round(d + noise(2.5))); } }

  // ---- SD card + File ----
  class SDFile { constructor(name, mode) { this.kind = 'File'; this.n = name; this.mode = mode; this.buf = ''; this.pos = 0; this.data = sim.fs.get(name) || ''; this.open = true; }
    _f(s) { this.buf += s; } print(s) { this._f(String(s)); } println(s) { this._f((s === undefined ? '' : String(s)) + '\r\n'); } write(v) { this._f(typeof v === 'string' ? v : String.fromCharCode(v & 255)); }
    flush() { if (this.buf && this.mode !== 0) { sim.fs.set(this.n, (sim.fs.get(this.n) || '') + this.buf); this.buf = ''; } } close() { this.flush(); this.open = false; }
    available() { return Math.max(0, this.data.length - this.pos); } read() { return this.pos < this.data.length ? this.data.charCodeAt(this.pos++) : -1; } peek() { return this.pos < this.data.length ? this.data.charCodeAt(this.pos) : -1; }
    readStringUntil(ch) { const i = this.data.indexOf(String.fromCharCode(ch), this.pos); let s; if (i < 0) { s = this.data.slice(this.pos); this.pos = this.data.length; } else { s = this.data.slice(this.pos, i); this.pos = i + 1; } return s; }
    readString() { const s = this.data.slice(this.pos); this.pos = this.data.length; return s; }
    size() { return (this.mode === 0 ? this.data.length : (sim.fs.get(this.n) || '').length + this.buf.length); } position() { return this.pos; } seek(p) { this.pos = Math.trunc(p); return 1; } name() { return this.n.replace(/^\//, ''); } isDirectory() { return 0; } }
  const norm = (p) => '/' + String(p).replace(/^\/+/, '');
  B.SPI = { begin(sck, miso, mosi) { if (sck !== undefined && miso !== undefined && mosi !== undefined) sim.spiPins = [Math.trunc(sck), Math.trunc(miso), Math.trunc(mosi)]; }, end() { }, setClockDivider() { }, setDataMode() { }, setBitOrder() { }, transfer(v) { return 0; } };
  B.SD = {
    begin(cs) { cs = Math.trunc(cs === undefined ? bd.spi ? 10 : 10 : cs); const cards = sim.comps.filter(c => c.type === 'sdcard');
      if (!cards.length) { sim.warn('nosd', 'SD.begin() chala, par bench par micro SD card module nahi hai.', 'err'); return 0; }
      const [sck, miso, mosi] = sim.spiPins || bd.spi, c = cards[0], bad = [];
      if (!sim.sameNet(sck, c, 'SCK')) bad.push(`SCK -> ${pn(sck)}`); if (!sim.sameNet(miso, c, 'MISO')) bad.push(`MISO -> ${pn(miso)}`); if (!sim.sameNet(mosi, c, 'MOSI')) bad.push(`MOSI -> ${pn(mosi)}`); if (!sim.sameNet(cs, c, 'CS')) bad.push(`CS -> ${pn(cs)} (SD.begin mein diya pin)`);
      if (bad.length) { sim.warn('sdw', `SD module ki wiring galat hai. Ye jodo: ${bad.join(', ')}.`, 'err'); return 0; }
      if (!sim.powered(c, 'VCC', 'GND', 4.4)) { sim.warn('sdp', 'SD module ko 5V chahiye (usme regulator hai). VCC ko 5V pin se jodo, 3.3V par card init fail hota hai.', 'err'); return 0; }
      sim.sdOk = true; return 1; },
    end() { sim.sdOk = false; },
    open(p, mode) { if (!sim.sdOk) { sim.warn('sdnb', 'SD.open() se pehle SD.begin() sahi se chalna chahiye (abhi card init nahi hua).', 'err'); return 0; } p = norm(p); mode = Math.trunc(mode || 0);
      if (mode === 0 && !sim.fs.has(p)) return 0; if (mode !== 0 && !sim.fs.has(p)) sim.fs.set(p, ''); return new SDFile(p, mode); },
    exists(p) { return sim.sdOk && sim.fs.has(norm(p)) ? 1 : 0; }, remove(p) { return sim.sdOk && sim.fs.delete(norm(p)) ? 1 : 0; }, mkdir() { return 1; }, rmdir() { return 1; },
  };

  // ---- I2S (ESP_I2S API: single-sample read()/write()) ----
  class I2SClass { constructor() { this.kind = 'I2SClass'; this.pins = {}; this.rate = 16000; this.bits = 16; this.w = { t: -1e9, zc: 0, t0: 0, mx: 0, prev: 0, freq: 0, amp: 0 }; sim.libs.push(this); }
    setPins(sck, ws, dout, din) { this.pins = { sck: Math.trunc(sck), ws: Math.trunc(ws), dout: dout === undefined ? -1 : Math.trunc(dout), din: din === undefined ? -1 : Math.trunc(din) }; return 1; }
    begin(mode, rate, bits) { if (this.pins.sck === undefined) { sim.warn('i2sp', 'I2S.begin() se pehle I2S.setPins(bclk, ws, dout, din) karo.', 'err'); return 0; } this.rate = Math.max(1000, Math.trunc(rate)); this.bits = Math.trunc(bits) || 16; this.on = true; return 1; }
    end() { this.on = false; } available() { return 1024; }
    _mic() { const p = this.pins; if (this._mc !== undefined) return this._mc; const cs = sim.comps.filter(c => c.type === 'inmp441');
      if (!cs.length) { sim.warn('nomic', 'I2S.read() chala, par bench par INMP441 microphone nahi hai.', 'err'); return (this._mc = null); }
      const c = cs.find(q => p.din >= 0 && sim.sameNet(p.sck, q, 'SCK') && sim.sameNet(p.ws, q, 'WS') && sim.sameNet(p.din, q, 'SD'));
      if (!c) { sim.warn('micw', `INMP441 ki wiring setPins se match nahi karti. SCK->${pn(p.sck)}, WS->${pn(p.ws)}, SD->${p.din >= 0 ? pn(p.din) : '(din -1 hai!)'} hona chahiye.`, 'err'); return (this._mc = null); }
      if (!sim.powered(c, 'VDD', 'GND', 1.6)) { sim.warn('micp', 'INMP441 ko power nahi mil rahi (3.3V aur GND).', 'err'); return (this._mc = null); } return (this._mc = c); }
    *read() { B.now += 1e6 / this.rate; if (B.now >= B.limit) yield 0; const c = this._mic(); if (!c) return 0; const t = B.now / 1e6, big = this.bits > 16 ? 1073741824 : 16383;
      return Math.round(c.level * big * Math.sin(2 * Math.PI * c.freq * t) + noise(0.01 * big * (0.2 + c.level))); }
    *write(s) { B.now += 1e6 / this.rate; if (B.now >= B.limit) yield 0; const w = this.w, full = Math.pow(2, this.bits - 1), v = s / full;
      if (B.now - w.t0 > 50000) { w.freq = w.zc / ((B.now - w.t0) / 1e6); w.amp = w.mx; w.zc = 0; w.mx = 0; w.t0 = B.now; } if (w.prev < 0 && v >= 0) w.zc++; w.prev = v; w.mx = Math.max(w.mx, Math.abs(v)); w.t = B.now; return 4; } }
  sim.ampPlaying = (c) => { const io = sim.libs.find(l => l.kind === 'I2SClass' && l.on && l.pins.dout >= 0 && sim.sameNet(l.pins.dout, c, 'DIN') && sim.sameNet(l.pins.sck, c, 'BCLK') && sim.sameNet(l.pins.ws, c, 'LRC')); if (!io || !sim.B) return null; return B.now - io.w.t < 120000 ? io.w : null; };

  // ---- USB camera (simplified API) ----
  class USBCamera { constructor() { this.kind = 'USBCamera'; this.prev = null; this.W = 320; this.H = 240; }
    begin() { if (!bd.usb) { sim.warn('camb', `${bd.name} par USB host nahi hai. USB camera ke liye ESP32-S3 use karo.`, 'err'); return 0; } const c = sim.comps.find(q => q.type === 'camera'); if (!c) { sim.warn('camn', 'Bench par USB camera nahi hai.', 'err'); return 0; }
      const dm = 19, dp = 20; if (!(sim.sameNet(dm, c, 'DM') && sim.sameNet(dp, c, 'DP'))) { sim.warn('camw', 'Camera D- ko GPIO19 aur D+ ko GPIO20 se jodo (USB pins).', 'err'); return 0; }
      if (!sim.powered(c, 'VBUS', 'GND', 4.4)) { sim.warn('camp', 'Camera ko 5V (VBUS) aur GND chahiye.', 'err'); return 0; } this.c = c; return 1; }
    *capture() { yield* B.delay(33); if (!this.c) return 0; const x = this.c.objX; this.mot = this.prev === null ? 0 : Math.min(100, Math.round(Math.abs(x - this.prev) * 400 + (this.c.motion ? 25 : 0))); this.prev = x; this.f = { l: this.c.light, x }; return 1; }
    width() { return this.W; } height() { return this.H; } brightness() { return this.f ? Math.round(255 * this.f.l) : 0; } objectX() { return this.f ? Math.round(this.f.x * (this.W - 1)) : 0; } motion() { return this.mot || 0; } }

  Object.assign(B.libs, { MPU6050, Adafruit_SSD1306: SSD1306, VL53L0X, File: function () { return 0; }, I2SClass, USBCamera });
  B.SPI.begin = B.SPI.begin;
}
if (typeof module !== 'undefined') module.exports = { addLibs2 };
