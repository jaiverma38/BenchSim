// ===== Lexer + preprocessor for the Arduino C++ subset =====
function CErr(line, msg) { const e = new Error(msg); e.line = line; e.isC = true; return e; }

const OPS3 = ['<<=', '>>='];
const OPS2 = ['==', '!=', '<=', '>=', '&&', '||', '++', '--', '+=', '-=', '*=', '/=', '%=', '&=', '|=', '^=', '<<', '>>', '->', '::'];
const OPS1 = '+-*/%=<>!&|^~?:;,.(){}[]';

function lex(src, line0) {
  const toks = []; let i = 0, line = line0 || 1; const n = src.length;
  const isD = (ch) => ch !== undefined && ch >= '0' && ch <= '9';
  while (i < n) {
    const c = src[i];
    if (c === '\n') { line++; i++; continue; }
    if (c === ' ' || c === '\t' || c === '\r') { i++; continue; }
    if (c === '/' && src[i + 1] === '/') { while (i < n && src[i] !== '\n') i++; continue; }
    if (c === '/' && src[i + 1] === '*') {
      i += 2;
      while (i < n && !(src[i] === '*' && src[i + 1] === '/')) { if (src[i] === '\n') line++; i++; }
      i += 2; continue;
    }
    if (c === '#') {
      let j = i;
      while (j < n && src[j] !== '\n') { if (src[j] === '\\' && src[j + 1] === '\n') { j += 2; line++; continue; } j++; }
      toks.push({ t: 'pp', v: src.slice(i, j), line }); i = j; continue;
    }
    if (isD(c) || (c === '.' && isD(src[i + 1]))) {
      let j = i, isF = false, val, radix = false;
      if (c === '0' && (src[i + 1] === 'x' || src[i + 1] === 'X')) {
        j += 2; while (/[0-9a-fA-F]/.test(src[j] || '')) j++;
        val = parseInt(src.slice(i + 2, j), 16); radix = true;
      } else if (c === '0' && (src[i + 1] === 'b' || src[i + 1] === 'B')) {
        j += 2; while (/[01]/.test(src[j] || '')) j++;
        val = parseInt(src.slice(i + 2, j), 2); radix = true;
      } else {
        while (isD(src[j])) j++;
        if (src[j] === '.') { isF = true; j++; while (isD(src[j])) j++; }
        if ((src[j] === 'e' || src[j] === 'E') && /[-+0-9]/.test(src[j + 1] || '')) { isF = true; j += 2; while (isD(src[j])) j++; }
        val = parseFloat(src.slice(i, j));
      }
      let suf = '';
      while (/[uUlLfF]/.test(src[j] || '')) { suf += src[j].toLowerCase(); j++; }
      if (suf.includes('f')) isF = true;
      let ty;
      if (isF) ty = 'float';
      else if (suf.includes('u') && suf.includes('l')) ty = 'ulong';
      else if (suf.includes('l')) ty = 'long';
      else if (suf.includes('u')) ty = val > 65535 ? 'ulong' : 'uint';
      else if (val <= 32767) ty = 'int';
      else if (radix && val <= 65535) ty = 'uint';
      else if (val <= 2147483647) ty = 'long';
      else ty = 'ulong';
      toks.push({ t: 'num', v: val, ty, line }); i = j; continue;
    }
    if (/[A-Za-z_]/.test(c)) {
      let j = i; while (/[A-Za-z0-9_]/.test(src[j] || '')) j++;
      const w = src.slice(i, j);
      if (/^B[01]{1,8}$/.test(w)) toks.push({ t: 'num', v: parseInt(w.slice(1), 2), ty: 'byte', line });
      else toks.push({ t: 'id', v: w, line });
      i = j; continue;
    }
    if (c === '"' || c === "'") {
      let j = i + 1, s = '';
      while (j < n && src[j] !== c) {
        if (src[j] === '\n') throw CErr(line, 'Text ya character band nahi kiya (closing quote chahiye)');
        if (src[j] === '\\') {
          const e = src[j + 1]; j += 2;
          s += e === 'n' ? '\n' : e === 't' ? '\t' : e === 'r' ? '\r' : e === '0' ? '\0' : e;
        } else { s += src[j]; j++; }
      }
      if (j >= n) throw CErr(line, 'Text ya character band nahi kiya (closing quote chahiye)');
      if (c === '"') toks.push({ t: 'str', v: s, line });
      else toks.push({ t: 'num', v: s.length ? s.charCodeAt(0) : 0, ty: 'char', line });
      i = j + 1; continue;
    }
    const t3 = src.substr(i, 3), t2 = src.substr(i, 2);
    if (OPS3.includes(t3)) { toks.push({ t: 'op', v: t3, line }); i += 3; continue; }
    if (OPS2.includes(t2)) { toks.push({ t: 'op', v: t2, line }); i += 2; continue; }
    if (OPS1.includes(c)) { toks.push({ t: 'op', v: c, line }); i++; continue; }
    throw CErr(line, 'Ye character samajh nahi aaya: ' + c);
  }
  return toks;
}

function preprocess(toks) {
  const macros = new Map(), out = [];
  for (const t of toks) {
    if (t.t !== 'pp') { out.push(t); continue; }
    const m = /^#\s*define\s+([A-Za-z_]\w*)(\(?)\s*(.*)$/.exec(t.v);
    if (m) {
      if (m[2] === '(') throw CErr(t.line, 'Function jaisa #define abhi support nahi hai');
      const body = lex(m[3], t.line).filter(x => x.t !== 'pp');
      macros.set(m[1], body);
    }
  }
  let cur = out;
  for (let depth = 0; depth < 8 && macros.size; depth++) {
    let changed = false; const next = [];
    for (const t of cur) {
      if (t.t === 'id' && macros.has(t.v)) {
        changed = true;
        for (const b of macros.get(t.v)) next.push(Object.assign({}, b, { line: t.line }));
      } else next.push(t);
    }
    cur = next; if (!changed) break;
  }
  return cur;
}

if (typeof module !== 'undefined') module.exports = { lex, preprocess, CErr };
