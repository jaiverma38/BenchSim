// ===== Component registry: drawing + electrical model + properties =====
const COMPS = {};
const CATS = [['basic', 'Basic'], ['semi', 'Semiconductor'], ['out', 'Output / Display'], ['sensor', 'Sensors'], ['power', 'Power / Motor'], ['ic', 'ICs / Modules'], ['tool', 'Tools']];
function reg(type, d) { d.type = type; COMPS[type] = d; }
const LEDCOL = { red: '#ff3b30', green: '#2fd45a', yellow: '#ffcc1a', blue: '#2e8bff', white: '#f4f4ea', orange: '#ff8a1c' };
const LED_VF = { red: 1.9, green: 2.1, yellow: 2.0, blue: 3.0, white: 3.0, orange: 2.0 };
const BAND = ['#111', '#7b4a21', '#d62d20', '#f08a1c', '#f2d21b', '#2e9b3e', '#2b6fd6', '#8a4fc7', '#888', '#f4f4f4'];
const E12 = [10, 12, 15, 18, 22, 27, 33, 39, 47, 56, 68, 82];
const RPRESET = [10, 47, 100, 220, 330, 470, 1000, 2200, 4700, 10000, 47000, 100000, 1000000];
const leg = (x1, y1, x2, y2) => `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" class="leg"/>`;
const UNITS = { R: [['Ω', 1], ['kΩ', 1e3], ['MΩ', 1e6]], C: [['pF', 1e-12], ['nF', 1e-9], ['µF', 1e-6], ['mF', 1e-3]], L: [['µH', 1e-6], ['mH', 1e-3], ['H', 1]], V: [['V', 1]] };
function bandsFor(v) { let e = 0, m = v; while (m >= 100) { m /= 10; e++; } return [Math.floor(m / 10) % 10, Math.round(m % 10) % 10, Math.min(e, 9)]; }
function fmtU(v, u) { const t = UNITS[u]; let best = t[0]; for (const x of t) if (v >= x[1] * 0.999) best = x; return +(v / best[1]).toPrecision(3) + best[0]; }

// diode-like piecewise device. s = persistent state object, key = flag name
function diodeDev(a, k, vf, Rs, s, key) {
  return {
    stamp(x) { if (s[key]) x.fsrc(a, k, vf, Rs); },
    update(V) { const vd = V[a] - V[k]; if (s[key]) { if ((vd - vf) / Rs < -1e-6) { s[key] = false; return true; } } else if (vd > vf + 1e-4) { s[key] = true; return true; } return false; },
    i(V) { return s[key] ? Math.max(0, (V[a] - V[k] - vf) / Rs) : 0; },
  };
}
const bright = (i) => 1 - Math.exp(-Math.max(i, 0) / 0.006);

// ---------- BASIC ----------
reg('res', { name: 'Resistor', cat: 'basic', terms: { 1: [-36, 0], 2: [36, 0] }, box: [-44, -22, 88, 56], init: { val: 220 }, lab: (c) => fmtU(c.val, 'R'),
  props: [{ k: 'val', label: 'Value', kind: 'num', units: 'R', presets: RPRESET }],
  draw: (c) => { const [d1, d2, e] = bandsFor(c.val); return `${leg(-36, 0, 36, 0)}<rect x="-22" y="-8" width="44" height="16" rx="7" class="resbody"/><rect x="-14" y="-8" width="4" height="16" fill="${BAND[d1]}"/><rect x="-6" y="-8" width="4" height="16" fill="${BAND[d2]}"/><rect x="2" y="-8" width="4" height="16" fill="${BAND[e]}"/><rect x="12" y="-8" width="3" height="16" fill="#c9a227"/>`; },
  model: (c, h) => { const a = h.t(1), b = h.t(2), R = Math.max(c.val, 0.001); return { stamp: (x) => x.res(a, b, R), meas: (V) => ({ p: (V[a] - V[b]) ** 2 / R }) }; },
  rate: [{ k: 'p', lim: 0.25, t: 400000, msg: (c, v) => `Resistor ${c.label} garam hokar jal gaya! ${v.toFixed(2)} W lag raha tha (normal resistor 0.25 W tak). Bada resistor ya zyada watt wala lagao.` }] });
reg('pot', { name: 'Potentiometer', cat: 'basic', terms: { 1: [-18, 32], W: [0, 32], 2: [18, 32] }, box: [-30, -28, 60, 90], init: { val: 0.5 }, lab: (c) => c.label + ' 10kΩ',
  live: [{ k: 'val', label: 'Knob', min: 0, max: 1, step: 0.01, pct: true }],
  draw: (c) => `${leg(-18, 20, -18, 32)}${leg(0, 20, 0, 32)}${leg(18, 20, 18, 32)}<circle r="22" class="potbody"/><circle r="14" class="potknob"/><line class="potptr" x1="0" y1="0" x2="0" y2="-12" transform="rotate(${-135 + 270 * c.val})"/>`,
  model: (c, h) => { const a = h.t(1), w = h.t('W'), b = h.t(2), p = Math.min(0.9999, Math.max(0.0001, c.val)); return { stamp: (x) => { x.res(a, w, 10000 * p); x.res(w, b, 10000 * (1 - p)); } }; } });
reg('btn', { name: 'Push button', cat: 'basic', terms: { 1: [-26, 0], 2: [26, 0] }, box: [-34, -26, 68, 56], init: { pressed: false }, hold: { k: 'pressed', label: 'Dabao (hold)' },
  draw: (c) => `${leg(-26, 0, -14, 0)}${leg(14, 0, 26, 0)}<rect x="-20" y="-20" width="40" height="40" rx="5" class="btnbase"/><circle class="btncap${c.pressed ? ' down' : ''}" data-press="${c.id}" r="${c.pressed ? 9 : 11}"/>`,
  model: (c, h) => { const a = h.t(1), b = h.t(2); return { stamp: (x) => { if (c.pressed) x.res(a, b, 0.05); } }; } });
reg('sw', { name: 'Slide switch', cat: 'basic', terms: { 1: [-24, 0], 2: [24, 0] }, box: [-32, -18, 64, 46], init: { on: false }, toggle: { k: 'on', label: 'Switch ON' },
  draw: (c) => `${leg(-24, 0, -12, 0)}${leg(12, 0, 24, 0)}<rect x="-14" y="-9" width="28" height="18" rx="4" class="btnbase"/><rect x="${c.on ? 1 : -11}" y="-6" width="10" height="12" rx="2" fill="#dfe3e6"/>`,
  model: (c, h) => { const a = h.t(1), b = h.t(2); return { stamp: (x) => { if (c.on) x.res(a, b, 0.05); } }; } });
reg('cap', { name: 'Capacitor', cat: 'basic', terms: { 1: [-9, 30], 2: [9, 30] }, box: [-22, -26, 44, 80], init: { val: 100e-6 }, lab: (c) => fmtU(c.val, 'C'),
  props: [{ k: 'val', label: 'Value', kind: 'num', units: 'C', presets: [1e-9, 1e-8, 1e-7, 1e-6, 4.7e-6, 1e-5, 4.7e-5, 1e-4, 4.7e-4, 1e-3] }],
  draw: (c) => `${leg(-9, 14, -9, 30)}${leg(9, 14, 9, 30)}<rect x="-14" y="-22" width="28" height="36" rx="5" fill="#1d4f8a"/><rect x="5" y="-22" width="6" height="36" fill="#cfd6dd"/><text x="-4" y="0" class="bt2" text-anchor="middle">+</text>`,
  model: (c, h) => { const a = h.t(1), b = h.t(2), C = Math.max(c.val, 1e-12), g = C / h.dt, vc = h.st.vc || 0; return { stamp: (x) => { x.res(a, b, 1 / g); x.inj(a, g * vc); x.inj(b, -g * vc); }, post: (V) => { h.st.vc = V[a] - V[b]; }, meas: (V) => ({ v: V[a] - V[b] }) }; },
  state: (c, s) => ({ v: s.vc || 0 }) });
reg('ind', { name: 'Inductor', cat: 'basic', terms: { 1: [-30, 0], 2: [30, 0] }, box: [-38, -18, 76, 44], init: { val: 10e-3 }, lab: (c) => fmtU(c.val, 'L'),
  props: [{ k: 'val', label: 'Value', kind: 'num', units: 'L', presets: [1e-5, 1e-4, 1e-3, 1e-2, 1e-1] }],
  draw: () => `${leg(-30, 0, -20, 0)}${leg(20, 0, 30, 0)}<path d="M-20 0 a5 7 0 0 1 10 0 a5 7 0 0 1 10 0 a5 7 0 0 1 10 0 a5 7 0 0 1 10 0" fill="none" stroke="#b87333" stroke-width="3"/>`,
  model: (c, h) => { const a = h.t(1), b = h.t(2), L = Math.max(c.val, 1e-9), il = h.st.il || 0, g = h.dt / L; return { stamp: (x) => { x.res(a, b, 1 / g); x.inj(a, -il); x.inj(b, il); }, post: (V) => { h.st.il = il + g * (V[a] - V[b]); }, meas: () => ({ i: il }) }; } });
reg('rail', { name: 'Junction strip (8 holes)', cat: 'basic', terms: Object.fromEntries([...Array(8)].map((_, i) => ['r' + (i + 1), [-70 + i * 20, 0]])), box: [-82, -14, 164, 44], init: {}, lab: () => '',
  draw: () => `<rect x="-80" y="-8" width="160" height="16" rx="4" fill="#cfd3c8" stroke="#8b917f"/>`,
  model: (c, h) => { const t = [...Array(8)].map((_, i) => h.t('r' + (i + 1))); return { stamp: (x) => { for (let i = 1; i < 8; i++) x.res(t[0], t[i], 0.0005); } }; } });
reg('gnd', { name: 'Ground symbol', cat: 'basic', terms: { G: [0, -10] }, box: [-16, -22, 32, 44], init: {}, lab: () => '',
  draw: () => `${leg(0, -10, 0, 4)}<path d="M-12 4 h24 M-8 9 h16 M-4 14 h8" stroke="#2b2f33" stroke-width="2.5" fill="none"/>`,
  model: (c, h) => { const g = h.t('G'); return { stamp: (x) => x.src(g, 0, 0.01) }; } });

// ---------- SEMICONDUCTORS ----------
reg('led', { name: 'LED', cat: 'semi', terms: { A: [-8, 32], K: [8, 32] }, box: [-24, -30, 48, 96], init: { val: 'red' },
  props: [{ k: 'val', label: 'Rang', kind: 'sel', opts: Object.keys(LEDCOL) }],
  draw: (c) => { const col = LEDCOL[c.val] || LEDCOL.red; return `<circle class="glow" r="30" cy="-6" fill="${col}" opacity="0"/>${leg(-8, 9, -8, 32)}${leg(8, 9, 8, 32)}<path d="M-14 6 V-8 a14 14 0 0 1 28 0 V6 Z" class="ledbody" fill="${col}" fill-opacity="0.28" stroke="${col}" stroke-width="1.6"/><path d="M-14 6 V-8 a14 14 0 0 1 28 0 V6 Z" class="ledlit" fill="${col}" opacity="0"/><rect x="-16" y="6" width="32" height="4" rx="1" class="ledflat"/><path class="burnx" d="M-8 -14 L8 2 M8 -14 L-8 2" stroke="#222" stroke-width="3" opacity="0"/><text x="-8" y="46" class="pm" text-anchor="middle">+</text>`; },
  model: (c, h) => { const a = h.t('A'), k = h.t('K'), vf = LED_VF[c.val] || 2, d = diodeDev(a, k, vf, 10, h.st, 'on'); d.meas = (V) => { const i = d.i(V); return { i, b: bright(i), maxI: i }; }; return d; },
  rate: [{ k: 'maxI', lim: 0.045, t: 200000, msg: (c, v) => `LED ${c.label} jal gayi! Current ${(v * 1000).toFixed(0)} mA tha (limit ~20 mA). LED ke saath resistor (220Ω ke aas-paas) lagao.` }],
  view: (c, g, s) => { g.querySelector('.glow').setAttribute('opacity', (s.b * 0.75).toFixed(2)); g.querySelector('.ledlit').setAttribute('opacity', (s.b * 0.9).toFixed(2)); g.querySelector('.burnx').setAttribute('opacity', s.burnt ? 1 : 0); } });
reg('diode', { name: 'Diode 1N4007', cat: 'semi', terms: { A: [-30, 0], K: [30, 0] }, box: [-38, -18, 76, 44], init: {}, lab: (c) => c.label,
  draw: () => `${leg(-30, 0, 30, 0)}<rect x="-16" y="-7" width="32" height="14" rx="3" fill="#24292d"/><rect x="8" y="-7" width="5" height="14" fill="#cfd6dd"/>`,
  model: (c, h) => { const d = diodeDev(h.t('A'), h.t('K'), 0.7, 0.5, h.st, 'on'); const a = h.t('A'), k = h.t('K'); d.meas = (V) => { const i = d.i(V); return { i, maxI: i }; }; return d; },
  rate: [{ k: 'maxI', lim: 1.5, t: 500000, msg: (c, v) => `Diode ${c.label} jal gaya (${v.toFixed(1)} A). 1N4007 ki limit 1 A hai.` }] });
reg('zener', { name: 'Zener 5.1V', cat: 'semi', terms: { A: [-30, 0], K: [30, 0] }, box: [-38, -18, 76, 44], init: { vz: 5.1 }, lab: () => 'Zener 5.1V',
  draw: () => `${leg(-30, 0, 30, 0)}<rect x="-16" y="-7" width="32" height="14" rx="3" fill="#7a5a2e"/><rect x="8" y="-7" width="5" height="14" fill="#111"/>`,
  model: (c, h) => { const a = h.t('A'), k = h.t('K'), s = h.st, f = diodeDev(a, k, 0.7, 0.5, s, 'on'), vz = c.vz || 5.1; return { stamp: (x) => { f.stamp(x); if (s.rev) x.fsrc(k, a, vz, 1); }, update: (V) => { let ch = f.update(V); const vr = V[k] - V[a]; if (s.rev) { if ((vr - vz) < -1e-4) { s.rev = false; ch = true; } } else if (vr > vz + 1e-4) { s.rev = true; ch = true; } return ch; } }; } });
function bjt(isP) {
  return (c, h) => {
    const B = h.t('B'), C = h.t('C'), E = h.t('E'), s = h.st, beta = c.beta || 100;
    const jp = isP ? E : B, jn = isP ? B : E, cp = isP ? E : C, cn = isP ? C : E;
    return {
      stamp(x) { const m = s.m | 0; if (!m) return; x.fsrc(jp, jn, 0.7, 10); if (m === 1) { x.vccs(cp, cn, jp, jn, beta / 10); x.inj(cp, beta * 0.07); x.inj(cn, -beta * 0.07); } else x.fsrc(cp, cn, 0.2, 2); },
      update(V) { const m = s.m | 0, vbe = V[jp] - V[jn]; let nm = m; const ib = (vbe - 0.7) / 10;
        if (m === 0) { if (vbe > 0.72) nm = 1; } else if (ib <= 0) nm = 0; else if (m === 1) { if (V[cp] - V[cn] < 0.2) nm = 2; } else if ((V[cp] - V[cn] - 0.2) / 2 > beta * ib) nm = 1;
        if (nm !== m) { s.m = nm; return true; } return false; },
      meas(V) { const m = s.m | 0, ic = m === 0 ? 0 : m === 1 ? beta * Math.max(0, (V[jp] - V[jn] - 0.7) / 10) : Math.max(0, (V[cp] - V[cn] - 0.2) / 2); return { ic, maxIc: ic }; },
    };
  };
}
const BJT_I = { '2N2222': 0.8, 'BC547': 0.1, 'TIP120': 5, '2N3055': 15 };
['npn', 'pnp'].forEach(t => reg(t, { name: t === 'npn' ? 'NPN transistor' : 'PNP transistor', cat: 'semi', terms: { B: [-22, 0], C: [10, -30], E: [10, 30] }, box: [-32, -42, 62, 84], init: { val: 'BC547' }, lab: (c) => c.label + ' ' + c.val,
  props: [{ k: 'val', label: 'Part', kind: 'sel', opts: Object.keys(BJT_I) }],
  draw: () => `${leg(-22, 0, -6, 0)}${leg(10, -30, 10, -14)}${leg(10, 14, 10, 30)}<circle r="22" fill="#2a2f33" fill-opacity=".25" stroke="#7d868c" stroke-width="1.5"/><line x1="-6" y1="-12" x2="-6" y2="12" stroke="#222" stroke-width="3"/><line x1="-6" y1="-5" x2="10" y2="-14" stroke="#222" stroke-width="2.4"/><line x1="-6" y1="5" x2="10" y2="14" stroke="#222" stroke-width="2.4"/>`,
  model: bjt(t === 'pnp'),
  rate: [{ k: 'maxIc', lim: (c) => BJT_I[c.val] || 0.5, t: 300000, msg: (c, v) => `Transistor ${c.label} jal gaya (${v.toFixed(2)} A). ${c.val} ki limit ${BJT_I[c.val]} A hai.` }] }));
['nmos', 'pmos'].forEach(t => reg(t, { name: t === 'nmos' ? 'N-MOSFET (logic level)' : 'P-MOSFET', cat: 'semi', terms: { G: [-22, 0], D: [10, -30], S: [10, 30] }, box: [-32, -42, 62, 84], init: {}, lab: (c) => c.label,
  draw: () => `${leg(-22, 0, -8, 0)}${leg(10, -30, 10, -14)}${leg(10, 14, 10, 30)}<rect x="-14" y="-22" width="36" height="44" rx="4" fill="#24292d"/><text x="4" y="4" class="bt2" text-anchor="middle">${t === 'nmos' ? 'N-FET' : 'P-FET'}</text>`,
  model: (c, h) => { const G = h.t('G'), D = h.t('D'), S = h.t('S'), s = h.st, p = t === 'pmos'; return { stamp: (x) => { if (s.on) x.res(D, S, 0.08); }, update: (V) => { const vg = p ? V[S] - V[G] : V[G] - V[S]; const on = s.on ? vg > 1.6 : vg > 2.2; if (on !== !!s.on) { s.on = on; return true; } return false; }, meas: (V) => ({ maxIc: s.on ? Math.abs(V[D] - V[S]) / 0.08 : 0 }) }; },
  rate: [{ k: 'maxIc', lim: 20, t: 300000, msg: (c, v) => `MOSFET ${c.label} jal gaya (${v.toFixed(0)} A).` }] }));

if (typeof module !== 'undefined') module.exports = { COMPS, CATS, reg, LEDCOL, LED_VF, UNITS, fmtU, leg, diodeDev, bright, BAND, bandsFor };
