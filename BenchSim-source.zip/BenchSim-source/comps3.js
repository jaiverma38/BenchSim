// ===== Components part 3: sensors + ICs =====
if (typeof require !== 'undefined' && typeof reg === 'undefined') { var { COMPS, reg, leg } = require('./comps.js'); var { row, findLib } = require('./comps2.js'); }

// generic powered analog/digital sensor module. o.out(c, vin) -> [[term, volts, ohms], ...]
function sensor(type, o) {
  const [vp, gn] = o.pw || ['VCC', 'GND'];
  reg(type, Object.assign({ cat: 'sensor', init: {}, lab: (c) => c.label,
    model: (c, h) => { const a = h.t(vp), b = h.t(gn), s = h.st; return { stamp: (x) => { x.res(a, b, o.load || 5000); for (const [p, q, r] of o.pulls || []) x.res(h.t(p), h.t(q), r); if ((s.vin || 0) > (o.min || 2.7)) for (const [t, v, r] of o.out ? o.out(c, s.vin) : []) x.fsrc(h.t(t), b, v, r); }, update: (V) => { const p = V[a] - V[b]; if (Math.abs(p - (s.vin || 0)) > 0.05) { s.vin = p; return true; } return false; } }; },
  }, o));
}
const modTitle = (w, h, col, t) => `<rect x="${-w / 2}" y="${-h / 2}" width="${w}" height="${h}" rx="4" fill="${col}" stroke="#0004"/><text x="0" y="${-h / 2 + 11}" class="bt" text-anchor="middle" font-size="8" fill="#fff">${t}</text>`;
const pinLab = (names, y, step) => names.map((k, i) => `<text x="${(i - (names.length - 1) / 2) * step}" y="${y}" class="pl" style="font-size:6px" text-anchor="middle">${k}</text>`).join('');

reg('ldr', { name: 'LDR (light sensor)', cat: 'sensor', terms: { 1: [-9, 30], 2: [9, 30] }, box: [-34, -28, 68, 84], init: { val: 0.7 }, lab: (c) => c.label,
  live: [{ k: 'val', label: 'Roshni', min: 0, max: 1, step: 0.01, pct: true }],
  draw: (c) => `${leg(-9, 14, -9, 30)}${leg(9, 14, 9, 30)}<circle r="17" class="ldrbody"/><path d="M-10 -6 h20 M-10 0 h20 M-10 6 h20" class="ldrz"/><g opacity="${0.25 + 0.75 * c.val}"><path d="M-24 -22 l8 8 M-30 -14 l8 8" class="wave"/></g>`,
  model: (c, h) => { const a = h.t(1), b = h.t(2), l = Math.min(1, Math.max(0, c.val)); return { stamp: (x) => x.res(a, b, 1e6 * Math.pow(1e-3, l)) }; } });
reg('ntc', { name: 'Thermistor NTC 10k', cat: 'sensor', terms: { 1: [-9, 30], 2: [9, 30] }, box: [-26, -26, 52, 82], init: { temp: 25 }, lab: (c) => c.label + ' ' + c.temp + '°C',
  live: [{ k: 'temp', label: 'Temperature', min: -20, max: 120, step: 1, unit: '°C' }],
  draw: () => `${leg(-9, 12, -9, 30)}${leg(9, 12, 9, 30)}<ellipse rx="14" ry="16" fill="#c0392b" stroke="#7b241c" stroke-width="2"/><text y="4" class="bt2" text-anchor="middle" font-size="9">NTC</text>`,
  model: (c, h) => { const a = h.t(1), b = h.t(2), T = c.temp + 273.15; return { stamp: (x) => x.res(a, b, 10000 * Math.exp(3950 * (1 / T - 1 / 298.15))) }; } });
const tempLive = [{ k: 'temp', label: 'Temperature', min: -5, max: 120, step: 0.5, unit: '°C' }];
const to3 = (w, col, t, names) => (c) => `${names.map((k, i) => leg((i - 1) * 16, 12, (i - 1) * 16, 32)).join('')}${modTitle(w, 30, col, t)}${pinLab(names, 44, 16)}`;
sensor('lm35', { name: 'LM35 temperature', terms: { VCC: [-16, 32], OUT: [0, 32], GND: [16, 32] }, box: [-30, -22, 60, 80], init: { temp: 25 }, live: tempLive, min: 3.9, load: 100000, out: (c) => [['OUT', 0.01 * c.temp, 100]], draw: to3(46, '#2a2f33', 'LM35', ['VCC', 'OUT', 'GND']) });
sensor('tmp36', { name: 'TMP36 temperature', terms: { VCC: [-16, 32], OUT: [0, 32], GND: [16, 32] }, box: [-30, -22, 60, 80], init: { temp: 25 }, live: tempLive, min: 2.6, load: 100000, out: (c) => [['OUT', 0.5 + 0.01 * c.temp, 100]], draw: to3(46, '#2a2f33', 'TMP36', ['VCC', 'OUT', 'GND']) });
sensor('dht', { name: 'DHT11 / DHT22', terms: { VCC: [-16, 36], DATA: [0, 36], GND: [16, 36] }, box: [-30, -34, 60, 86], init: { temp: 26, hum: 55 }, live: [{ k: 'temp', label: 'Temperature', min: 0, max: 50, step: 0.5, unit: '°C' }, { k: 'hum', label: 'Humidity', min: 20, max: 95, step: 1, unit: '%' }], min: 2.9, load: 10000,
  out: () => [], draw: () => `${[-16, 0, 16].map(x => leg(x, 18, x, 36)).join('')}<rect x="-24" y="-30" width="48" height="48" rx="4" fill="#2d9bd8" stroke="#16587d"/>${[-20, -12, -4, 4, 12, 20].map(y => `<line x1="-20" y1="${y - 6}" x2="20" y2="${y - 6}" stroke="#16587d"/>`).join('')}<text x="0" y="12" class="bt" text-anchor="middle" fill="#fff" font-size="9">DHT</text>${pinLab(['VCC', 'DATA', 'GND'], 50, 16)}`,
  model: (c, h) => { const a = h.t('VCC'), d = h.t('DATA'), b = h.t('GND'), s = h.st; return { stamp: (x) => { x.res(a, b, 8000); x.res(a, d, 10000); }, update: (V) => { const p = V[a] - V[b]; if (Math.abs(p - (s.vin || 0)) > 0.05) { s.vin = p; return true; } return false; } }; } });
sensor('hcsr04', { name: 'HC-SR04 ultrasonic', terms: row(['VCC', 'TRIG', 'ECHO', 'GND'], 38, 20), box: [-48, -30, 96, 84], init: { dist: 100 }, live: [{ k: 'dist', label: 'Doori', min: 2, max: 400, step: 1, unit: 'cm' }], min: 4.4, load: 330, out: () => [],
  draw: () => `${modTitle(92, 52, '#2f6fb0', 'HC-SR04')}<circle cx="-22" cy="2" r="14" fill="#c9ced3" stroke="#555"/><circle cx="22" cy="2" r="14" fill="#c9ced3" stroke="#555"/>${pinLab(['VCC', 'TRIG', 'ECHO', 'GND'], 50, 20)}` });
sensor('pir', { name: 'PIR motion (HC-SR501)', terms: { VCC: [-18, 38], OUT: [0, 38], GND: [18, 38] }, box: [-36, -34, 72, 86], init: { motion: false }, toggle: { k: 'motion', label: 'Motion hai' }, min: 4.4, load: 15000, out: (c) => [['OUT', c.motion ? 3.3 : 0, 100]],
  draw: (c) => `${[-18, 0, 18].map(x => leg(x, 22, x, 38)).join('')}${modTitle(66, 44, '#3a8c4a', 'PIR')}<circle cy="2" r="14" fill="#f4f1e6" stroke="#bbb"/><circle cy="2" r="6" fill="${c.motion ? '#ff8a1c' : '#ddd'}"/>${pinLab(['VCC', 'OUT', 'GND'], 50, 18)}` });
sensor('irsens', { name: 'IR obstacle sensor', terms: { VCC: [-18, 38], OUT: [0, 38], GND: [18, 38] }, box: [-36, -34, 72, 86], init: { obstacle: false }, toggle: { k: 'obstacle', label: 'Obstacle samne' }, min: 2.9, load: 5000, out: (c, v) => [['OUT', c.obstacle ? 0.1 : v, 200]],
  draw: (c) => `${[-18, 0, 18].map(x => leg(x, 22, x, 38)).join('')}${modTitle(66, 44, '#2a5b8c', 'IR')}<circle cx="-12" cy="4" r="6" fill="${c.obstacle ? '#ff4040' : '#444'}"/><circle cx="12" cy="4" r="6" fill="#222"/>${pinLab(['VCC', 'OUT', 'GND'], 50, 18)}` });
sensor('soil', { name: 'Soil moisture sensor', terms: { VCC: [-18, 38], AO: [0, 38], GND: [18, 38] }, box: [-36, -34, 72, 86], init: { moist: 0.4 }, live: [{ k: 'moist', label: 'Nami', min: 0, max: 1, step: 0.01, pct: true }], min: 2.9, load: 3000, out: (c, v) => [['AO', v * (0.9 - 0.7 * c.moist), 2000]],
  draw: () => `${[-18, 0, 18].map(x => leg(x, 22, x, 38)).join('')}${modTitle(66, 44, '#7a4f2a', 'SOIL')}<rect x="-8" y="-6" width="16" height="20" fill="#e5d3a0"/>${pinLab(['VCC', 'AO', 'GND'], 50, 18)}` });
sensor('gas', { name: 'Gas sensor MQ-2', terms: { VCC: [-18, 38], AO: [0, 38], GND: [18, 38] }, box: [-36, -34, 72, 86], init: { gas: 0.1 }, live: [{ k: 'gas', label: 'Gas level', min: 0, max: 1, step: 0.01, pct: true }], min: 4.4, load: 33, out: (c, v) => [['AO', v * (0.08 + 0.7 * Math.pow(c.gas, 1.4)), 3000]],
  draw: () => `${[-18, 0, 18].map(x => leg(x, 22, x, 38)).join('')}${modTitle(66, 44, '#2b3a55', 'MQ-2')}<circle cy="4" r="12" fill="#b7bcc2" stroke="#666"/>${pinLab(['VCC', 'AO', 'GND'], 50, 18)}` });
reg('joy', { name: 'Joystick module', cat: 'sensor', terms: row(['GND', 'VCC', 'VRX', 'VRY', 'SW'], 40, 18), box: [-54, -36, 108, 90], init: { jx: 0.5, jy: 0.5, pressed: false },
  live: [{ k: 'jx', label: 'X axis', min: 0, max: 1, step: 0.01, pct: true }, { k: 'jy', label: 'Y axis', min: 0, max: 1, step: 0.01, pct: true }], hold: { k: 'pressed', label: 'Joystick dabao' }, lab: (c) => c.label,
  draw: (c) => `${modTitle(104, 66, '#27323b', 'JOYSTICK')}<circle cy="2" r="18" fill="#111"/><circle cx="${(c.jx - 0.5) * 20}" cy="${2 + (c.jy - 0.5) * 20}" r="10" fill="#3b4650" stroke="#8a97a3"/>${pinLab(['GND', 'VCC', 'VRX', 'VRY', 'SW'], 53, 18)}`,
  model: (c, h) => { const vc = h.t('VCC'), g = h.t('GND'), x1 = h.t('VRX'), y1 = h.t('VRY'), sw = h.t('SW'), cl = (v) => Math.min(0.999, Math.max(0.001, v)); return { stamp: (x) => { x.res(vc, x1, 10000 * (1 - cl(c.jx))); x.res(x1, g, 10000 * cl(c.jx)); x.res(vc, y1, 10000 * (1 - cl(c.jy))); x.res(y1, g, 10000 * cl(c.jy)); if (c.pressed) x.res(sw, g, 0.1); } }; } });

// ---------- 74HC595 shift register ----------
const IC595 = ['VCC', 'GND', 'SER', 'SRCLK', 'RCLK', 'OE', 'SRCLR'];
reg('ic595', { name: '74HC595 shift register', cat: 'ic', terms: Object.assign(row(IC595, -34, 22), row(['Q0', 'Q1', 'Q2', 'Q3', 'Q4', 'Q5', 'Q6', 'Q7'], 34, 20)), box: [-84, -46, 168, 92], init: {}, lab: (c) => c.label,
  draw: () => `${modTitle(160, 56, '#202427', '74HC595')}${pinLab(IC595, -40, 22).replace(/y="-40"/g, 'y="-38"')}${pinLab(['Q0', 'Q1', 'Q2', 'Q3', 'Q4', 'Q5', 'Q6', 'Q7'], 30, 20)}`,
  model: (c, h) => { const vc = h.t('VCC'), g = h.t('GND'), s = h.st, q = [...Array(8)].map((_, i) => h.t('Q' + i)), oe = h.t('OE'), sr = h.t('SRCLR'), vcc = h.vcc;
    return { stamp: (x) => { x.res(vc, g, 100000); x.res(oe, g, 100000); x.res(sr, vc, 100000); if (!s.pw || s.oe) return; for (let i = 0; i < 8; i++) x.fsrc(q[i], g, ((s.out || 0) >> i) & 1 ? s.vin : 0, 60); },
      update: (V) => { const p = V[vc] - V[g], pw = p > 2.7; let ch = false; if (pw !== !!s.pw || Math.abs(p - (s.vin || 0)) > 0.05) { s.pw = pw; s.vin = p; ch = true; } return ch; } }; },
  onSolved: (c, s, sim) => {
    if (!s.pw) return false;
    const th = (s.vin || 5) / 2, rd = (t) => sim.cv(c, t, 'GND') > th, ser = rd('SER'), clk = rd('SRCLK'), lat = rd('RCLK'), oe = rd('OE'), clr = rd('SRCLR');
    let ch = false;
    if (!sim.nc) sim.nc = {};
    if (s.prevClk === undefined) { s.prevClk = clk; s.prevLat = lat; }
    if (!clr && !s.clrWasLow) { s.sh = 0; s.clrWasLow = true; } if (clr) s.clrWasLow = false;
    if (clk && !s.prevClk && clr) s.sh = (((s.sh || 0) << 1) | (ser ? 1 : 0)) & 255;
    if (lat && !s.prevLat) { if ((s.out || 0) !== (s.sh || 0)) { s.out = s.sh || 0; ch = true; } }
    if (oe !== !!s.oe) { s.oe = oe; ch = true; }
    s.prevClk = clk; s.prevLat = lat; return ch;
  } });

if (typeof module !== 'undefined') module.exports = { sensor, modTitle, pinLab };
