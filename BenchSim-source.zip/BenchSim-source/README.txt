BenchSim source
- BenchSim.html  : poora app (ek hi file, browser mein kholo)
- Source badalne ke baad:  python3 build.py   -> BenchSim.html dobara banta hai
- Tests: node test.js ; node test2.js ; node test3.js ; node extest.js
- build.py ke andar folder ka path /home/claude/bench/ hai; apne folder ke hisaab se badlo.
