if (typeof require !== 'undefined' && typeof addLibs2 === 'undefined') { var { addLibs2 } = require('./libs2.js'); }
// ===== Arduino libraries (runtime emulation) =====
function addLibs(sim, B, P) {
  const bd = sim.board, find = (type, f) => sim.comps.find(c => c.type === type && (!f || f(c)));
  if (!sim.eeprom) sim.eeprom = new Uint8Array(1024).fill(255);
  const isStr = (v) => typeof v === 'string';

  // ---- Servo ----
  class Servo { constructor() { this.kind = 'Servo'; this.pin = -1; this.angle = 90; sim.libs.push(this); }
    attach(p) { p = Math.trunc(p); const o = P(p, 'Servo.attach'); if (!o) return 0; this.pin = p; o.mode = 1; o.level = 0; o.duty = null; sim.touch(); return 1; }
    detach() { this.pin = -1; } attached() { return this.pin >= 0 ? 1 : 0; }
    write(a) { if (this.pin < 0) sim.warn('svna', 'Servo.write() se pehle servo.attach(pin) karo.'); a = Math.trunc(a); if (a > 180 && a < 544) a = 180; this.angle = Math.max(0, Math.min(180, a >= 544 ? (a - 544) / (2400 - 544) * 180 : a)); }
    writeMicroseconds(us) { this.angle = Math.max(0, Math.min(180, (us - 544) / (2400 - 544) * 180)); }
    read() { return Math.round(this.angle); } }

  // ---- LCD ----
  class Lcd { constructor() { this.rows = [Array(16).fill(' '), Array(16).fill(' ')]; this.cx = 0; this.cy = 0; this.on = true; this.checked = false; }
    lines() { return this.on ? this.rows.map(r => r.join('')) : ['', '']; }
    begin() { this.clear(); return 0; } init() { this.clear(); return 0; }
    clear() { this.rows = [Array(16).fill(' '), Array(16).fill(' ')]; this.cx = 0; this.cy = 0; } home() { this.cx = 0; this.cy = 0; }
    setCursor(x, y) { this.cx = Math.max(0, Math.trunc(x)); this.cy = Math.max(0, Math.min(1, Math.trunc(y))); }
    print(s) { this.check(); if (!isStr(s)) s = String(s); for (const ch of s) { if (this.cx < 16) this.rows[this.cy][this.cx] = ch; this.cx++; } }
    write(v) { this.print(isStr(v) ? v : String.fromCharCode(v & 255)); }
    display() { this.on = true; } noDisplay() { this.on = false; } backlight() { } noBacklight() { } cursor() { } noCursor() { } blink() { } noBlink() { } createChar() { }
    scrollDisplayLeft() { this.rows = this.rows.map(r => r.slice(1).concat(' ')); } scrollDisplayRight() { this.rows = this.rows.map(r => [' '].concat(r.slice(0, 15))); }
    check() { if (this.checked) return; this.checked = true; this.verify(); } }
  class LiquidCrystal extends Lcd { constructor(rs, en, d4, d5, d6, d7) { super(); this.kind = 'LiquidCrystal'; this.pins = [rs, en, d4, d5, d6, d7].map(Math.trunc); sim.libs.push(this); this.pins.forEach(p => { const o = sim.pins[p]; if (o) { o.mode = 1; o.level = 0; } }); }
    verify() { const lcds = sim.comps.filter(c => c.type === 'lcd'); if (!lcds.length) { sim.warn('lcdnone', 'Sketch LiquidCrystal use kar rahi hai, par bench par LCD 16x2 (parallel) nahi hai.'); return; }
      if (lcds.some(c => ['RS', 'E', 'D4', 'D5', 'D6', 'D7'].every((t, i) => sim.sameNet(this.pins[i], c, t)))) return;
      const c = lcds[0], bad = ['RS', 'E', 'D4', 'D5', 'D6', 'D7'].filter((t, i) => !sim.sameNet(this.pins[i], c, t)); sim.warn('lcdwire', `LCD ki wiring code se match nahi karti. Ye pins galat/adhoori hain: ${bad.join(', ')}. Code mein LiquidCrystal(rs, en, d4, d5, d6, d7) ke pin number dekho.`, 'err'); } }
  class LiquidCrystal_I2C extends Lcd { constructor(addr) { super(); this.kind = 'LiquidCrystal_I2C'; this.addr = Math.trunc(addr); sim.libs.push(this); }
    verify() { const l = find('lcdi2c'); if (!l) { sim.warn('lcdnone', 'Sketch LiquidCrystal_I2C use kar rahi hai, par bench par LCD 16x2 (I2C) nahi hai.'); return; }
      const [sda, scl] = bd.i2c; if (!(sim.sameNet(sda, l, 'SDA') && sim.sameNet(scl, l, 'SCL'))) sim.warn('i2cwire', `I2C LCD ka SDA/SCL galat pins par hai. ${bd.name} par SDA = ${sim.pname(sda)}, SCL = ${sim.pname(scl)} hona chahiye.`, 'err');
      else if (l.addr !== this.addr) sim.warn('i2caddr', `LCD ka address 0x${l.addr.toString(16).toUpperCase()} hai, par code mein 0x${this.addr.toString(16).toUpperCase()} diya hai. Screen khali rahegi.`, 'err'); } }

  // ---- ultrasonic ----
  sim.sonarUs = (echoPin, trigPin) => {
    const c = find('hcsr04', (c) => sim.sameNet(echoPin, c, 'ECHO') && (trigPin === null || sim.sameNet(trigPin, c, 'TRIG')));
    if (!c) { sim.warn('sonar' + echoPin, 'HC-SR04 sensor ka ECHO pin is pin se connected nahi hai ya bench par sensor nahi hai.'); return null; }
    if (!sim.powered(c, 'VCC', 'GND', 4.4)) { sim.warn('sonarpw' + c.id, 'HC-SR04 ko 5V power nahi mil rahi (VCC aur GND jodo).'); return null; }
    if (bd.vcc < 4 && sim.cv(c, 'VCC', 'GND') > 4) sim.warn('sonar5v' + c.id, 'HC-SR04 ECHO pin 5V deta hai, ye 3.3V board ke pin ko kharab kar sakta hai. Voltage divider (1k + 2k) lagao.', 'err');
    if (trigPin === null) { const tp = sim.pinDriver(c, 'TRIG'), p = sim.pins[tp]; if (tp < 0) { sim.warn('trigw' + c.id, 'HC-SR04 ka TRIG pin kisi output pin se connected nahi hai.'); return null; }
      if (!(p.fall > p.rise && B.now - p.fall < 5000 && p.fall - p.rise >= 9)) { sim.warn('trigp' + c.id, 'TRIG par 10 microsecond ka HIGH pulse nahi mila (digitalWrite(trig, HIGH); delayMicroseconds(10); digitalWrite(trig, LOW)). Sensor jawab nahi dega.'); return null; } p.fall = -1e12; }
    if (c.dist > 400 || c.dist < 2) return null;
    return Math.round(c.dist * 58 + (Math.random() - 0.5) * 4);
  };
  B.pulseIn = function* (pin, level, to) { to = to === undefined ? 1000000 : Math.trunc(to); const us = sim.sonarUs(Math.trunc(pin), null); if (us === null || us > to) { yield* B.delayUs(Math.min(to, 1000000)); return 0; } B.now += 400 + us; if (B.now >= B.limit) yield 0; return us; };
  class NewPing { constructor(t, e, max) { this.t = Math.trunc(t); this.e = Math.trunc(e); this.max = max || 500; }
    ping() { B.now += 6000; const us = sim.sonarUs(this.e, this.t); return us === null || us > this.max * 58 ? 0 : us; }
    ping_cm() { return Math.floor(this.ping() / 58); } ping_in() { return Math.floor(this.ping() / 148); } ping_median(n) { return this.ping(); } }

  // ---- DHT ----
  class DHT { constructor(pin, type) { this.pin = Math.trunc(pin); this.type = type; }
    begin() { } 
    _c() { B.now += 20000; const c = find('dht', (c) => sim.sameNet(this.pin, c, 'DATA')); if (!c) { sim.warn('dhtw', 'DHT sensor ka DATA pin sketch ke pin se connected nahi hai. Reading NaN aayegi.', 'err'); return null; } if (!sim.powered(c, 'VCC', 'GND', 2.9)) { sim.warn('dhtp', 'DHT ko power nahi mil rahi (VCC/GND check karo). Reading NaN aayegi.', 'err'); return null; } return c; }
    readTemperature(f) { const c = this._c(); if (!c) return NaN; const t = c.temp + (Math.random() - 0.5) * 0.2; return f ? t * 1.8 + 32 : (this.type === 11 ? Math.round(t) : t); }
    readHumidity() { const c = this._c(); if (!c) return NaN; return this.type === 11 ? Math.round(c.hum) : c.hum + (Math.random() - 0.5) * 0.4; } }

  B.libs = { Servo, LiquidCrystal, LiquidCrystal_I2C, NewPing, DHT };
  B.mk = (type, args) => { const L = B.libs[type]; if (!L) return 0; return new L(...args); };
  B.m = function* (o, name, ...args) { const r = o[name](...args); if (r && typeof r.next === 'function') return yield* r; return r; };
  B.shiftOut = function* (d, c, order, val) { val = Math.trunc(val) & 255; for (let i = 0; i < 8; i++) { const bit = order === 1 ? (val >> (7 - i)) & 1 : (val >> i) & 1; B.digitalWrite(d, bit); B.digitalWrite(c, 1); B.digitalWrite(c, 0); B.now += 4; } if (B.now >= B.limit) yield 0; };
  B.shiftIn = function* (d, c, order) { let v = 0; for (let i = 0; i < 8; i++) { B.digitalWrite(c, 1); const b = B.digitalRead(d); B.digitalWrite(c, 0); v = order === 1 ? (v << 1) | b : v | (b << i); } if (B.now >= B.limit) yield 0; return v; };
  B.Wire = { begin(a, b) { if (a !== undefined && b !== undefined) sim.i2cPins = [Math.trunc(a), Math.trunc(b)]; }, setClock() { }, setPins(a, b) { sim.i2cPins = [Math.trunc(a), Math.trunc(b)]; }, beginTransmission() { sim.warn('wire', 'Raw I2C (Wire.beginTransmission) abhi support nahi. LiquidCrystal_I2C library use karo.'); }, write() { }, endTransmission() { return 0; }, requestFrom() { return 0; }, available() { return 0; }, read() { return -1; } };
  B.EEPROM = { read(a) { a = Math.trunc(a); return sim.eeprom[a] === undefined ? 255 : sim.eeprom[a]; }, write(a, v) { a = Math.trunc(a); if (sim.eeprom[a] !== undefined) sim.eeprom[a] = v & 255; }, update(a, v) { B.EEPROM.write(a, v); }, length() { return 1024; } };
  addLibs2(sim, B, P);
}
if (typeof module !== 'undefined') module.exports = { addLibs };
