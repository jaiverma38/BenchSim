// ===== Components part 4: ESP32-S3 era modules (I2C sensors, OLED, mic, ToF, SD, radar, camera, TB6612, MT3608, amp, speaker) =====
if (typeof require !== 'undefined' && typeof reg === 'undefined') { var { COMPS, reg, leg } = require('./comps.js'); var { row, findLib } = require('./comps2.js'); var { sensor, modTitle, pinLab } = require('./comps3.js'); }

const hexs = (v) => '0x' + v.toString(16).toUpperCase();
const legs = (names, y0, y1, step) => names.map((k, i) => { const x = (i - (names.length - 1) / 2) * step; return leg(x, y0, x, y1); }).join('');
const modDraw = (w, h, col, title, names, step, extra) => `${legs(names, h / 2 - 6, h / 2 + 8, step)}${modTitle(w, h, col, title)}${extra || ''}${pinLab(names, h / 2 + 18, step)}`;
const PULL = (vcc) => [['SDA', vcc, 4700], ['SCL', vcc, 4700]];

// ---------- MPU6050 (GY-521) ----------
const MPUT = ['VCC', 'GND', 'SCL', 'SDA', 'AD0'];
sensor('mpu6050', { name: 'MPU6050 (accel + gyro)', terms: row(MPUT, 40, 20), box: [-60, -34, 120, 90], init: { addr: 0x68, pitch: 0, roll: 0, spin: 0, temp: 25 },
  lab: (c) => c.label + ' @' + hexs(c.addr), pw: ['VCC', 'GND'], min: 2.4, load: 900, pulls: [['VCC', 'SDA', 4700], ['VCC', 'SCL', 4700], ['AD0', 'GND', 100000]],
  props: [{ k: 'addr', label: 'I2C address (AD0)', kind: 'sel', opts: [0x68, 0x69], fmt: hexs }],
  live: [{ k: 'pitch', label: 'Pitch (aage-peeche tilt)', min: -90, max: 90, step: 1, unit: '°' }, { k: 'roll', label: 'Roll (side tilt)', min: -90, max: 90, step: 1, unit: '°' }, { k: 'spin', label: 'Ghoomne ki speed (gyro Z)', min: -250, max: 250, step: 1, unit: '°/s' }, { k: 'temp', label: 'Chip temperature', min: -10, max: 80, step: 1, unit: '°C' }],
  out: () => [], draw: (c) => `${legs(MPUT, 22, 40, 20)}${modTitle(110, 44, '#3b4aa8', 'MPU6050')}<rect x="-14" y="-4" width="28" height="18" rx="2" fill="#16181b"/><g transform="rotate(${c.roll} 0 5)"><rect x="-8" y="2" width="16" height="6" rx="1" fill="#8da0ff" transform="translate(0,${-c.pitch / 12})"/></g>${pinLab(MPUT, 52, 20)}` });

// ---------- OLED SSD1306 0.96" ----------
const OLT = ['GND', 'VCC', 'SCL', 'SDA'];
function oledRender(cmds, W, H) {
  if (typeof document === 'undefined') return '';
  const cv = document.createElement('canvas'); cv.width = W; cv.height = H; const g = cv.getContext('2d'); g.imageSmoothingEnabled = false;
  const col = (c) => c === 0 ? '#000' : '#cfe8ff', px = (x, y, c) => { g.fillStyle = col(c); g.fillRect(x, y, 1, 1); };
  g.fillStyle = '#000'; g.fillRect(0, 0, W, H); g.textBaseline = 'top';
  for (const o of cmds) {
    if (o.t === 'px') px(o.x, o.y, o.c);
    else if (o.t === 'ln') { let { x0, y0, x1, y1 } = o; const dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0), sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1; let e = dx + dy, n = 0; for (; ;) { px(x0, y0, o.c); if ((x0 === x1 && y0 === y1) || ++n > 600) break; const e2 = 2 * e; if (e2 >= dy) { e += dy; x0 += sx; } if (e2 <= dx) { e += dx; y0 += sy; } } }
    else if (o.t === 'rc') { g.fillStyle = col(o.c); if (o.f) g.fillRect(o.x, o.y, o.w, o.h); else { g.fillRect(o.x, o.y, o.w, 1); g.fillRect(o.x, o.y + o.h - 1, o.w, 1); g.fillRect(o.x, o.y, 1, o.h); g.fillRect(o.x + o.w - 1, o.y, 1, o.h); } }
    else if (o.t === 'ci') { for (let y = -o.r; y <= o.r; y++) for (let x = -o.r; x <= o.r; x++) { const d = Math.sqrt(x * x + y * y); if (o.f ? d <= o.r + 0.3 : Math.abs(d - o.r) < 0.6) px(o.x + x, o.y + y, o.c); } }
    else if (o.t === 'tx') { g.fillStyle = col(o.c); g.font = `${7 * o.z}px monospace`; for (let i = 0; i < o.s.length; i++) { g.fillText(o.s[i], o.x + i * 6 * o.z, o.y); } }
    else if (o.t === 'inv') { /* handled below */ }
  }
  return cv.toDataURL();
}
reg('oled', { name: 'OLED 0.96" SSD1306 (I2C)', cat: 'out', terms: row(OLT, 56, 22), box: [-70, -50, 140, 112], init: { addr: 0x3C }, lab: (c) => c.label + ' @' + hexs(c.addr),
  props: [{ k: 'addr', label: 'I2C address', kind: 'sel', opts: [0x3C, 0x3D], fmt: hexs }],
  draw: (c) => `${legs(OLT, 42, 56, 22)}<rect x="-64" y="-46" width="128" height="90" rx="5" fill="#1c2a44" stroke="#0a1220"/><rect x="-50" y="-40" width="100" height="52" fill="#000" stroke="#445"/><image class="scr" x="-48" y="-38" width="96" height="48" preserveAspectRatio="none" style="image-rendering:pixelated"/><text x="0" y="26" class="bt" text-anchor="middle" fill="#9ab" font-size="7">0.96" OLED 128x64</text>${pinLab(OLT, 66, 22)}`,
  model: (c, h) => { const a = h.t('VCC'), b = h.t('GND'); return { stamp: (x) => { x.res(a, b, 1200); x.res(a, h.t('SDA'), 10000); x.res(a, h.t('SCL'), 10000); } }; },
  state: (c, s, sim) => { const pw = sim.powered(c, 'VCC', 'GND', 2.7); const l = findLib(sim, 'Adafruit_SSD1306', (q) => q.c === c); return { pw, ver: l ? l.ver : -1, cmds: l && pw ? l.shown : null, W: l ? l.w : 128, H: l ? l.h : 64 }; },
  view: (c, g, s) => { const im = g.querySelector('.scr'); if (!im) return; const key = s.pw + ':' + s.ver; if (g._k === key) return; g._k = key; if (!s.pw || !s.cmds) { im.setAttribute('href', ''); return; } im.setAttribute('href', oledRender(s.cmds, s.W, s.H)); } });

// ---------- INMP441 I2S mic ----------
const MICT = ['VDD', 'GND', 'SCK', 'WS', 'SD', 'L/R'];
reg('inmp441', { name: 'INMP441 mic (I2S)', cat: 'sensor', terms: row(MICT.map(k => k === 'L/R' ? 'LR' : k), 40, 20), box: [-66, -32, 132, 88], init: { level: 0.3, freq: 440 }, lab: (c) => c.label,
  live: [{ k: 'level', label: 'Awaaz ki loudness', min: 0, max: 1, step: 0.01, pct: true }, { k: 'freq', label: 'Awaaz ki frequency', min: 50, max: 4000, step: 10, unit: 'Hz' }],
  draw: (c) => `${legs(MICT, 22, 40, 20)}${modTitle(120, 44, '#1b6f5a', 'INMP441')}<circle cx="0" cy="6" r="7" fill="#222" stroke="#999"/><circle cx="0" cy="6" r="2.5" fill="#000"/><g opacity="${0.2 + 0.8 * c.level}"><path d="M14 0 q6 6 0 12 M20 -3 q9 9 0 18" fill="none" stroke="#8ff" stroke-width="1.4"/></g>${pinLab(MICT, 52, 20)}`,
  model: (c, h) => { const a = h.t('VDD'), b = h.t('GND'), l = h.t('LR'); return { stamp: (x) => { x.res(a, b, 3000); x.res(l, b, 100000); } }; } });

// ---------- VL53L0X ToF ----------
const TOFT = ['VIN', 'GND', 'SCL', 'SDA', 'XSHUT', 'GPIO1'];
sensor('vl53', { name: 'VL53L0X ToF distance', terms: row(TOFT, 40, 20), box: [-66, -32, 132, 90], init: { dist: 300 }, lab: (c) => c.label + ' ' + c.dist + 'mm', pw: ['VIN', 'GND'], min: 2.6, load: 1100, pulls: [['VIN', 'XSHUT', 10000], ['VIN', 'SDA', 10000], ['VIN', 'SCL', 10000]],
  live: [{ k: 'dist', label: 'Doori (object)', min: 20, max: 2000, step: 5, unit: 'mm' }], out: () => [],
  draw: (c) => `${legs(TOFT, 22, 40, 20)}${modTitle(120, 44, '#6a2d8f', 'VL53L0X')}<rect x="-18" y="-2" width="14" height="12" fill="#111" stroke="#888"/><rect x="4" y="-2" width="14" height="12" fill="#222" stroke="#888"/>${pinLab(TOFT, 52, 20)}` });

// ---------- Micro SD card module (SPI) ----------
const SDT = ['GND', 'VCC', 'MISO', 'MOSI', 'SCK', 'CS'];
sensor('sdcard', { name: 'Micro SD card module', terms: row(SDT, 40, 20), box: [-66, -32, 132, 90], init: {}, lab: (c) => c.label, pw: ['VCC', 'GND'], min: 3.0, load: 500, out: () => [],
  draw: () => `${legs(SDT, 22, 40, 20)}${modTitle(120, 44, '#1d4f7a', 'MICRO SD')}<rect x="-30" y="-3" width="60" height="14" rx="2" fill="#aab2b8" stroke="#555"/><rect x="-8" y="0" width="20" height="8" fill="#222"/>${pinLab(SDT, 52, 20)}`,
  state: (c, s, sim) => ({ files: sim.fs ? [...sim.fs].map(([n, d]) => [n, d.length]) : [], ok: !!sim.sdOk }) });

// ---------- RCWL-0516 microwave radar ----------
sensor('radar', { name: 'Radar motion (RCWL-0516)', terms: { VIN: [-18, 38], OUT: [0, 38], GND: [18, 38] }, box: [-36, -34, 72, 86], init: { motion: false }, toggle: { k: 'motion', label: 'Harkat (motion) hai' }, min: 3.9, load: 800, out: (c) => [['OUT', c.motion ? 3.3 : 0, 100]], pw: ['VIN', 'GND'],
  draw: (c) => `${[-18, 0, 18].map(x => leg(x, 22, x, 38)).join('')}${modTitle(66, 44, '#2a3f6e', 'RADAR')}<circle cy="3" r="${c.motion ? 14 : 9}" fill="none" stroke="${c.motion ? '#ff9a2a' : '#6af'}" stroke-width="1.5"/><circle cy="3" r="5" fill="none" stroke="#6af"/>${pinLab(['VIN', 'OUT', 'GND'], 50, 18)}` });

// ---------- USB camera ----------
const CAMT = ['VBUS', 'DM', 'DP', 'GND'];
sensor('camera', { name: 'USB camera module', terms: row(CAMT, 40, 22), box: [-52, -34, 104, 90], init: { objX: 0.5, light: 0.7, motion: false }, lab: (c) => c.label, pw: ['VBUS', 'GND'], min: 4.4, load: 60, out: () => [],
  live: [{ k: 'objX', label: 'Object ki position (left-right)', min: 0, max: 1, step: 0.01, pct: true }, { k: 'light', label: 'Roshni (brightness)', min: 0, max: 1, step: 0.01, pct: true }], toggle: { k: 'motion', label: 'Frame mein halchal' },
  draw: (c) => `${legs(CAMT, 22, 40, 22)}${modTitle(96, 46, '#333a40', 'USB CAM')}<rect x="-30" y="-10" width="60" height="24" rx="2" fill="${`hsl(210 20% ${10 + 60 * c.light}%)`}" stroke="#000"/><circle cx="${-26 + 52 * c.objX}" cy="2" r="5" fill="#ffd54a"/>${pinLab(CAMT, 52, 22)}` });

// ---------- TB6612FNG dual motor driver ----------
const TBTOP = ['VCC', 'GND', 'STBY', 'PWMA', 'AIN1', 'AIN2', 'PWMB', 'BIN1', 'BIN2'], TBBOT = ['VM', 'AO1', 'AO2', 'BO1', 'BO2'];
reg('tb6612', { name: 'TB6612FNG dual motor driver', cat: 'power', terms: Object.assign(row(TBTOP, -48, 20), row(TBBOT, 44, 28)), box: [-96, -60, 192, 118], init: {}, lab: (c) => c.label,
  draw: () => `${legs(TBTOP, -34, -48, 20)}${legs(TBBOT, 28, 44, 28)}<rect x="-92" y="-34" width="184" height="62" rx="4" fill="#6b2a8a" stroke="#3a1050"/><rect x="-26" y="-20" width="52" height="30" rx="2" fill="#16181b"/><text x="0" y="0" class="bt chipt" text-anchor="middle">TB6612FNG</text>${pinLab(TBTOP, -52, 20).replace(/y="-52"/g, 'y="-52"')}${pinLab(TBBOT, 56, 28)}`,
  model: (c, h) => { const vc = h.t('VCC'), gn = h.t('GND'), vm = h.t('VM'), sb = h.t('STBY'), s = h.st;
    const pin = { PWMA: h.t('PWMA'), AIN1: h.t('AIN1'), AIN2: h.t('AIN2'), PWMB: h.t('PWMB'), BIN1: h.t('BIN1'), BIN2: h.t('BIN2') }, out = { AO1: h.t('AO1'), AO2: h.t('AO2'), BO1: h.t('BO1'), BO2: h.t('BO2') };
    return { stamp: (x) => { x.res(vc, gn, 8000); x.res(vm, gn, 200000); if (!s.run) return; for (const ch of ['A', 'B']) { const m = s['m' + ch]; if (m === 0 || m === undefined) continue; const hi = s.vm - 0.4; const [a, b] = ch === 'A' ? ['AO1', 'AO2'] : ['BO1', 'BO2'];
          if (m === 1) { x.fsrc(out[a], gn, hi, 0.5); x.fsrc(out[b], gn, 0, 0.5); } else if (m === 2) { x.fsrc(out[a], gn, 0, 0.5); x.fsrc(out[b], gn, hi, 0.5); } else if (m === 3) { x.fsrc(out[a], gn, 0, 0.5); x.fsrc(out[b], gn, 0, 0.5); } } },
      update: (V) => { const g = V[gn], lg = (i) => V[i] - g > 1.9; const run = lg(sb) && V[vc] - g > 2.5 && V[vm] - g > 2.5, vmv = V[vm] - g; let ch = false;
        const md = (p, i1, i2) => { const a = lg(i1), b = lg(i2); if (a && b) return 3; if (!lg(p)) return 0; if (a) return 1; if (b) return 2; return 0; };
        const nA = md(pin.PWMA, pin.AIN1, pin.AIN2), nB = md(pin.PWMB, pin.BIN1, pin.BIN2); if (nA !== s.mA) { s.mA = nA; ch = true; } if (nB !== s.mB) { s.mB = nB; ch = true; } if (run !== !!s.run) { s.run = run; ch = true; } if (Math.abs(vmv - (s.vm || 0)) > 0.05) { s.vm = vmv; ch = true; } return ch; } }; },
  state: (c, s) => ({ run: !!s.run, mA: s.mA, mB: s.mB }) });

// ---------- MT3608 boost converter ----------
reg('mt3608', { name: 'MT3608 boost converter', cat: 'power', terms: { 'IN+': [-30, 40], 'IN-': [-10, 40], 'OUT-': [10, 40], 'OUT+': [30, 40] }, box: [-50, -30, 100, 90], init: { vout: 9 }, lab: (c) => c.label + ' ' + c.vout + 'V',
  live: [{ k: 'vout', label: 'Output voltage (trimmer)', min: 5, max: 28, step: 0.5, unit: 'V' }],
  draw: (c) => `${[-30, -10, 10, 30].map(x => leg(x, 20, x, 40)).join('')}<rect x="-46" y="-26" width="92" height="46" rx="4" fill="#2057a8" stroke="#10305f"/><rect x="-36" y="-18" width="30" height="22" rx="2" fill="#222"/><circle cx="24" cy="-6" r="9" fill="#d9a441" stroke="#7a5a1a"/><line x1="24" y1="-6" x2="${24 + 7 * Math.cos(c.vout / 28 * 5)}" y2="${-6 + 7 * Math.sin(c.vout / 28 * 5)}" stroke="#222" stroke-width="2"/><text x="-21" y="12" class="bt" fill="#fff" font-size="7" text-anchor="middle">MT3608</text><text x="-30" y="52" class="pl" style="font-size:6px" text-anchor="middle">IN+</text><text x="-10" y="52" class="pl" style="font-size:6px" text-anchor="middle">IN-</text><text x="10" y="52" class="pl" style="font-size:6px" text-anchor="middle">OUT-</text><text x="30" y="52" class="pl" style="font-size:6px" text-anchor="middle">OUT+</text>`,
  model: (c, h) => { const ip = h.t('IN+'), im = h.t('IN-'), op = h.t('OUT+'), om = h.t('OUT-'), s = h.st;
    return { stamp: (x) => { x.res(im, om, 0.001); x.res(ip, im, 2e6); if (!s.on) return; x.fsrc(op, om, c.vout, 0.25); if (s.iin) x.inj(ip, -s.iin), x.inj(im, s.iin); },
      update: (V) => { const vi = V[ip] - V[im], on = (s.on ? vi > 1.6 : vi > 2.3) && vi < 24 && c.vout > vi + 0.5; let ch = false; if (on !== !!s.on) { s.on = on; ch = true; } if (Math.abs(vi - (s.vin || 0)) > 0.02) { s.vin = vi; ch = true; }
        const io = on ? Math.max(0, (c.vout - (V[op] - V[om])) / 0.25) : 0, ii = on ? Math.min(4, (c.vout * io) / (0.85 * vi)) : 0; if (Math.abs(ii - (s.iin || 0)) > 0.003 + 0.01 * ii) { s.iin = ii; ch = true; } s.iout = io; return ch; } }; },
  state: (c, s) => ({ on: !!s.on, iout: s.iout || 0, iin: s.iin || 0 }),
  rate: [{ k: 'iin', lim: 2.1, t: 500000, msg: (c) => `MT3608 ${c.label} ka input current 2A se upar gaya. Chip garam ho kar band ho jaati hai. Load kam karo ya output voltage kam rakho.` }] });

// ---------- Speaker ----------
reg('speaker', { name: 'Speaker 8Ω 3W', cat: 'out', terms: { '+': [-10, 34], '-': [10, 34] }, box: [-30, -28, 60, 86], init: {}, lab: (c) => c.label,
  draw: () => `${leg(-10, 18, -10, 34)}${leg(10, 18, 10, 34)}<circle r="22" fill="#2a2d30" stroke="#111" stroke-width="3"/><circle r="13" fill="#3d4146"/><circle r="4" fill="#111"/>`,
  model: (c, h) => { const a = h.t('+'), b = h.t('-'); return { stamp: (x) => x.res(a, b, 8) }; } });

// ---------- MAX98357A I2S amp ----------
const AMPT = ['VIN', 'GND', 'SD', 'GAIN', 'DIN', 'BCLK', 'LRC'];
reg('max98357', { name: 'MAX98357A I2S amp', cat: 'power', terms: Object.assign(row(AMPT, -44, 20), { 'SPK+': [-14, 44], 'SPK-': [14, 44] }), box: [-80, -56, 160, 112], init: {}, lab: (c) => c.label,
  draw: () => `${legs(AMPT, -30, -44, 20)}${[-14, 14].map(x => leg(x, 24, x, 44)).join('')}<rect x="-76" y="-30" width="152" height="56" rx="4" fill="#c4452f" stroke="#6b2214"/><rect x="-22" y="-16" width="44" height="26" rx="2" fill="#16181b"/><text x="0" y="1" class="bt chipt" text-anchor="middle" font-size="7">MAX98357A</text>${pinLab(AMPT, -50, 20)}<text x="-14" y="56" class="pl" style="font-size:6px" text-anchor="middle">SPK+</text><text x="14" y="56" class="pl" style="font-size:6px" text-anchor="middle">SPK-</text>`,
  model: (c, h) => { const a = h.t('VIN'), b = h.t('GND'), sd = h.t('SD'), gain = h.t('GAIN'); return { stamp: (x) => { x.res(a, b, 2500); x.res(a, sd, 1e6); x.res(gain, b, 1e8); } }; },
  state: (c, s, sim) => { const pw = sim.powered(c, 'VIN', 'GND', 2.5), sdOn = sim.cv(c, 'SD', 'GND') > 0.7; const w = pw && sdOn ? sim.ampPlaying(c) : null;
    const sp = sim.comps.find(q => q.type === 'speaker' && sim.netsEqual(c, 'SPK+', q, '+') && sim.netsEqual(c, 'SPK-', q, '-'));
    if (w && !sp) sim.warn('nosp' + c.id, 'MAX98357A awaaz de raha hai, par SPK+ / SPK- par speaker nahi juda hai.', 'err');
    if (sim.libs.some(l => l.kind === 'I2SClass' && l.on && l.pins.dout >= 0 && sim.sameNet(l.pins.dout, c, 'DIN')) && !pw) sim.warn('amppw' + c.id, 'MAX98357A ko power nahi mil rahi (VIN 2.5-5.5V aur GND).', 'err');
    const on = !!(w && sp && w.freq > 20 && w.amp > 0.01); return { on, freq: on ? w.freq : 0, amp: on ? Math.min(1, w.amp) : 0, pw }; } });

if (typeof module !== 'undefined') module.exports = {};
