// ===== Static circuit lint: wiring galtiyan chalane se pehle pakdo =====
function lintCircuit(sim, comps) {
  if (!comps.length) return [];
  sim.buildNets();
  const out = [], groups = new Map();
  for (const [t, r] of sim.root) { if (!groups.has(r)) groups.set(r, []); groups.get(r).push(t); }
  const net = (t) => groups.get(sim.root.get(t)) || [t], wired = (t) => net(t).length > 1;
  const hasT = (t, p) => net(t).includes(p);
  const POWER = /^(VCC|VDD|VIN|VBUS|VM|VS|V|GND|G)$/, SKIP = new Set(['rail', 'gnd']);
  const OPT = { mpu6050: ['AD0'], vl53: ['XSHUT', 'GPIO1'], max98357: ['SD', 'GAIN'], inmp441: ['LR'], sdcard: [] };
  const NEED5 = { hcsr04: 'VCC', sdcard: 'VCC', camera: 'VBUS', radar: 'VIN', pir: 'VCC', gas: 'VCC', servo: 'V' };
  const nm = (c) => c.label || c.type;
  for (const c of comps) {
    const d = COMPS[c.type]; if (!d || SKIP.has(c.type)) continue;
    const terms = Object.keys(d.terms), open = terms.filter(k => !wired(`c${c.id}:${k}`));
    if (open.length === terms.length) { out.push(['lint' + c.id, `${nm(c)} kisi se juda nahi hai. Iske pins ko board ya doosre parts se wire karo.`, 'warn']); continue; }
    const need = terms.length <= 3 ? terms : terms.filter(k => POWER.test(k));
    const miss = open.filter(k => need.includes(k) && !(OPT[c.type] || []).includes(k));
    if (miss.length) out.push(['lint' + c.id, `${nm(c)} ke ye pins khule hain (kahin jude nahi): ${miss.join(', ')}. ${miss.some(k => POWER.test(k)) ? 'Power/GND ke bina ye kaam nahi karega.' : 'Circuit adhoora hai.'}`, 'err']);
    if (NEED5[c.type] && hasT(`c${c.id}:${NEED5[c.type]}`, 'P:3V3')) out.push(['lint5' + c.id, `${nm(c)} ko 5V chahiye, par ye 3.3V se juda hai. Asli hardware mein ye kaam nahi karega (5V pin se jodo).`, 'err']);
    if (c.type === 'inmp441' && hasT(`c${c.id}:VDD`, 'P:5V')) out.push(['lint33' + c.id, `${nm(c)} sirf 3.3V ka part hai, 5V se kharab ho jaayega. 3V3 pin se jodo.`, 'err']);
    if (c.type === 'led') {
      const side = (k) => net(`c${c.id}:${k}`).filter(t => /^c\d+:/.test(t) && !t.startsWith(`c${c.id}:`));
      if (!side('A').length && !side('K').length && wired(`c${c.id}:A`) && wired(`c${c.id}:K`)) out.push(['lintR' + c.id, `${nm(c)} ke saath resistor nahi hai. Bina resistor ke LED jal jaati hai. 220Ω-330Ω series mein lagao.`, 'err']);
    }
  }
  const g = net('P:GND1');
  if (g.length <= 3 && g.every(t => /^P:GND/.test(t))) out.push(['lintG', 'Koi bhi part board ke GND se nahi juda. Circuit poora karne ke liye GND wire zaroori hai.', 'err']);
  return out;
}
if (typeof module !== 'undefined') module.exports = { lintCircuit };
