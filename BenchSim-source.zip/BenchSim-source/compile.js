// ===== Compiler: Arduino C++ subset -> JS generator source =====
if (typeof require !== 'undefined' && typeof lex === 'undefined') { var { lex, preprocess, CErr } = require('./lex.js'); }

const TYPEWORDS = new Set(['int', 'long', 'short', 'unsigned', 'signed', 'char', 'byte', 'bool', 'boolean', 'float', 'double', 'void', 'word', 'String', 'uint8_t', 'int8_t', 'uint16_t', 'int16_t', 'uint32_t', 'int32_t', 'uint64_t', 'int64_t', 'size_t']);
const QUALS = new Set(['const', 'static', 'volatile', 'extern', 'inline']);
const PREC = { '||': 1, '&&': 2, '|': 3, '^': 4, '&': 5, '==': 6, '!=': 6, '<': 7, '>': 7, '<=': 7, '>=': 7, '<<': 8, '>>': 8, '+': 9, '-': 9, '*': 10, '/': 10, '%': 10 };
const ASSIGN = ['=', '+=', '-=', '*=', '/=', '%=', '&=', '|=', '^=', '<<=', '>>='];
const RANKT = ['', 'int', 'uint', 'long', 'ulong', 'float'];
const RANK = { bool: 1, byte: 1, char: 1, int: 1, uint: 2, long: 3, ulong: 4, float: 5 };
function lev(a, b) { const m = a.length, n = b.length, d = []; for (let i = 0; i <= m; i++) { d[i] = [i]; } for (let j = 1; j <= n; j++) d[0][j] = j; for (let i = 1; i <= m; i++) for (let j = 1; j <= n; j++) d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); return d[m][n]; }
function dym(name, list) { let best = null, bd = 99; const lo = name.toLowerCase(); for (const c of new Set(list)) { if (!c || c === name) continue; const d = c.toLowerCase() === lo ? 0 : lev(lo, c.toLowerCase()); if (d < bd) { bd = d; best = c; } } return best && bd <= Math.max(1, Math.min(3, Math.floor(name.length / 3))) ? ` Sahi shayad: "${best}"?` : ''; }
const LIB_M = {
  Servo: { attach: 'int', detach: 'void', write: 'void', writeMicroseconds: 'void', read: 'int', attached: 'bool' },
  LiquidCrystal: { begin: 'void', init: 'void', clear: 'void', home: 'void', setCursor: 'void', print: 'void', write: 'void', display: 'void', noDisplay: 'void', cursor: 'void', noCursor: 'void', blink: 'void', noBlink: 'void', createChar: 'void', scrollDisplayLeft: 'void', scrollDisplayRight: 'void' },
  DHT: { begin: 'void', readTemperature: 'float', readHumidity: 'float' },
  NewPing: { ping: 'uint', ping_cm: 'uint', ping_in: 'uint', ping_median: 'uint' },
  Wire: { begin: 'void', setClock: 'void', setPins: 'void', beginTransmission: 'void', write: 'void', endTransmission: 'int', requestFrom: 'int', available: 'int', read: 'int' },
  EEPROM: { read: 'byte', write: 'void', update: 'void', length: 'uint' },
};
const V = 'void';
LIB_M.MPU6050 = { begin: 'byte', calcOffsets: V, update: V, getAccX: 'float', getAccY: 'float', getAccZ: 'float', getGyroX: 'float', getGyroY: 'float', getGyroZ: 'float', getAngleX: 'float', getAngleY: 'float', getAngleZ: 'float', getTemp: 'float', setAddress: V, setFilterGyroCoef: V };
LIB_M.Adafruit_SSD1306 = { begin: 'bool', clearDisplay: V, display: V, setTextSize: V, setTextColor: V, setCursor: V, print: V, println: V, write: V, drawPixel: V, drawLine: V, drawRect: V, fillRect: V, drawCircle: V, fillCircle: V, drawFastHLine: V, drawFastVLine: V, invertDisplay: V, dim: V, setRotation: V, setTextWrap: V, width: 'int', height: 'int' };
LIB_M.VL53L0X = { init: 'bool', setTimeout: V, startContinuous: V, stopContinuous: V, readRangeContinuousMillimeters: 'uint', readRangeSingleMillimeters: 'uint', timeoutOccurred: 'bool', setAddress: V, setMeasurementTimingBudget: 'bool' };
LIB_M.File = { print: V, println: V, write: V, close: V, flush: V, available: 'int', read: 'int', peek: 'int', readStringUntil: 'str', readString: 'str', size: 'ulong', position: 'ulong', seek: 'bool', name: 'str', isDirectory: 'bool' };
LIB_M.SD = { begin: 'bool', open: 'lib:File', exists: 'bool', remove: 'bool', mkdir: 'bool', rmdir: 'bool', end: V };
LIB_M.SPI = { begin: V, end: V, setClockDivider: V, setDataMode: V, setBitOrder: V, transfer: 'byte' };
LIB_M.I2SClass = { setPins: 'bool', begin: 'bool', end: V, read: 'long', write: 'uint', available: 'int' };
LIB_M.USBCamera = { begin: 'bool', capture: 'bool', width: 'int', height: 'int', brightness: 'int', objectX: 'int', motion: 'int' };
const GLOBAL_LIBS = ['Wire', 'EEPROM', 'SD', 'SPI'];
LIB_M.LiquidCrystal_I2C = Object.assign({ backlight: 'void', noBacklight: 'void' }, LIB_M.LiquidCrystal);
const SUPPORTED_INC = new Set(['Arduino.h', 'Servo.h', 'LiquidCrystal.h', 'LiquidCrystal_I2C.h', 'Wire.h', 'DHT.h', 'NewPing.h', 'EEPROM.h', 'SPI.h', 'Adafruit_Sensor.h', 'MPU6050_light.h', 'Adafruit_SSD1306.h', 'Adafruit_GFX.h', 'VL53L0X.h', 'SD.h', 'FS.h', 'ESP_I2S.h', 'USBCamera.h']);
const SIZEOF = { int: 2, uint: 2, long: 4, ulong: 4, byte: 1, char: 1, bool: 1, float: 4 };
const CONSTS = {
  HIGH: ['1', 'int'], LOW: ['0', 'int'], INPUT: ['0', 'int'], OUTPUT: ['1', 'int'], INPUT_PULLUP: ['2', 'int'], INPUT_PULLDOWN: ['3', 'int'],
  WHITE: ['1', 'int'], BLACK: ['0', 'int'], INVERSE: ['2', 'int'], SSD1306_WHITE: ['1', 'int'], SSD1306_BLACK: ['0', 'int'], SSD1306_INVERSE: ['2', 'int'], SSD1306_SWITCHCAPVCC: ['2', 'int'], SSD1306_EXTERNALVCC: ['1', 'int'],
  FILE_READ: ['0', 'int'], FILE_WRITE: ['1', 'int'], FILE_APPEND: ['2', 'int'], I2S_MODE_STD: ['0', 'int'], I2S_DATA_BIT_WIDTH_16BIT: ['16', 'int'], I2S_DATA_BIT_WIDTH_24BIT: ['24', 'int'], I2S_DATA_BIT_WIDTH_32BIT: ['32', 'int'], I2S_SLOT_MODE_MONO: ['1', 'int'], I2S_SLOT_MODE_STEREO: ['2', 'int'],
  CHANGE: ['1', 'int'], FALLING: ['2', 'int'], RISING: ['3', 'int'], MSBFIRST: ['1', 'int'], LSBFIRST: ['0', 'int'], DHT11: ['11', 'int'], DHT21: ['21', 'int'], DHT22: ['22', 'int'],
  true: ['1', 'bool'], false: ['0', 'bool'], PI: ['Math.PI', 'float'], DEC: ['10', 'int'], HEX: ['16', 'int'], OCT: ['8', 'int'], BIN: ['2', 'int'],
  NULL: ['0', 'int'], INT_MAX: ['32767', 'int'], INT_MIN: ['-32768', 'int'], LONG_MAX: ['2147483647', 'long'], TWO_PI: ['(Math.PI*2)', 'float'], HALF_PI: ['(Math.PI/2)', 'float'],
};

function promote(a, b) {
  if (a === 'str' || b === 'str') return 'str';
  return RANKT[Math.max(RANK[a] || 1, RANK[b] || 1)];
}
function wrap(t, c) {
  switch (t) {
    case 'int': return `((${c})<<16>>16)`;
    case 'uint': return `((${c})&65535)`;
    case 'long': return `((${c})|0)`;
    case 'ulong': return `((${c})>>>0)`;
    case 'byte': return `((${c})&255)`;
    case 'char': return `((${c})<<24>>24)`;
    case 'bool': return `((${c})?1:0)`;
    default: return c;
  }
}

class Compiler {
  constructor(toks, sigs, board, pass1) {
    this.board = board; this.t = toks; this.p = 0; this.sigs = sigs || {}; this.newSigs = {}; this.pass1 = !!pass1;
    this.i32 = !!(board && board.bits === 32); this.consts = Object.assign({}, CONSTS); this.structs = {}; this.enumTypes = new Set(); this.fnNames = new Set();
    if (board) for (const k in board.consts) this.consts[k] = [String(board.consts[k]), 'int'];
    if (pass1) { let d = 0; for (let i = 0; i < toks.length; i++) { const k = toks[i]; if (k.t === 'op') { if (k.v === '{') d++; else if (k.v === '}') d--; } else if (d === 0 && k.t === 'id' && toks[i + 1] && toks[i + 1].v === '(' && i > 0 && toks[i - 1].t === 'id') this.fnNames.add(k.v); } }
    this.globals = []; this.funcs = []; this.scopes = []; this.gsym = new Map();
    this.tmps = []; this.statics = 0; this.curFn = null; this.fnName = '';
  }
  peek(o = 0) { return this.t[this.p + o] || { t: 'eof', v: '', line: (this.t[this.t.length - 1] || {}).line || 1 }; }
  next() { const k = this.peek(); this.p++; return k; }
  isOp(v, o = 0) { const k = this.peek(o); return k.t === 'op' && k.v === v; }
  isId(v, o = 0) { const k = this.peek(o); return k.t === 'id' && k.v === v; }
  expectOp(v) {
    const k = this.peek();
    if (k.t === 'op' && k.v === v) { this.p++; return k; }
    const got = k.t === 'eof' ? 'file khatam' : `"${k.v}"`;
    throw CErr(k.line, `"${v}" chahiye tha, par ${got} mila` + (v === ';' ? ' (semicolon bhool gaye?)' : ''));
  }
  tmp() { const n = '$t' + this.tmps.length; this.tmps.push(n); return n; }
  push() { this.scopes.push(new Map()); }
  pop() { this.scopes.pop(); }
  lookup(n) {
    for (let i = this.scopes.length - 1; i >= 0; i--) if (this.scopes[i].has(n)) return this.scopes[i].get(n);
    return this.gsym.get(n) || null;
  }
  declare(n, sym) { (this.scopes.length ? this.scopes[this.scopes.length - 1] : this.gsym).set(n, sym); }

  // ---- types ----
  n(x) { if (this.i32) { if (x.t === 'int') return Object.assign({}, x, { t: 'long' }); if (x.t === 'uint') return Object.assign({}, x, { t: 'ulong' }); } return x; }
  p2(t) { return this.i32 ? (t === 'int' ? 'long' : t === 'uint' ? 'ulong' : t) : t; }
  parseType() {
    const save = this.p, words = [];
    { const k0 = this.peek(); if (k0.t === 'id') { if (this.structs[k0.v]) { this.next(); return 'S:' + k0.v; } if (this.enumTypes.has(k0.v)) { this.next(); return 'int'; } if (LIB_M[k0.v] && !GLOBAL_LIBS.includes(k0.v)) { this.next(); return 'lib:' + k0.v; } } }
    while (this.peek().t === 'id' && (TYPEWORDS.has(this.peek().v) || QUALS.has(this.peek().v) && false)) words.push(this.next().v);
    if (!words.length) { this.p = save; return null; }
    const u = words.includes('unsigned');
    const rest = words.filter(x => x !== 'unsigned' && x !== 'signed');
    const base = rest.join(' ');
    const tbl = {
      '': u ? 'uint' : 'int', 'int': u ? 'uint' : 'int', 'short': u ? 'uint' : 'int', 'short int': u ? 'uint' : 'int',
      'long': u ? 'ulong' : 'long', 'long int': u ? 'ulong' : 'long', 'long long': u ? 'ulong' : 'long', 'long long int': u ? 'ulong' : 'long',
      'char': u ? 'byte' : 'char', 'byte': 'byte', 'bool': 'bool', 'boolean': 'bool', 'float': 'float', 'double': 'float', 'long double': 'float',
      'void': 'void', 'word': 'uint', 'String': 'str', 'uint8_t': 'byte', 'int8_t': 'char', 'uint16_t': 'uint', 'int16_t': 'int',
      'uint32_t': 'ulong', 'int32_t': 'long', 'uint64_t': 'ulong', 'int64_t': 'long', 'size_t': 'uint',
    };
    if (!(base in tbl)) { this.p = save; return null; }
    if (this.i32 && (base === '' || base === 'int')) return u ? 'ulong' : 'long';
    if (this.i32 && base === 'size_t') return 'ulong';
    return tbl[base];
  }
  skipQuals() { const m = {}; while (this.peek().t === 'id' && QUALS.has(this.peek().v)) m[this.next().v] = true; return m; }
  startsDecl() {
    let o = 0;
    while (this.peek(o).t === 'id' && QUALS.has(this.peek(o).v)) o++;
    const k = this.peek(o);
    if (k.t === 'id' && (this.structs[k.v] || this.enumTypes.has(k.v) || (LIB_M[k.v] && !GLOBAL_LIBS.includes(k.v))) && this.peek(o + 1).t === 'id') return true;
    return k.t === 'id' && TYPEWORDS.has(k.v) && !this.isOp('(', o + 1);
  }

  // ---- conversions ----
  conv(x, to) {
    if (to.startsWith('S:')) return `B.clone(${x.c})`;
    if (to === 'void' || to === x.t) return x.c;
    if (to === 'str') return `B.str(${x.c},'${x.t}')`;
    if (x.t === 'str') throw CErr(this.peek().line, 'Text ko seedha number mein nahi badal sakte (toInt() use karo)');
    if (to === 'float') return x.c;
    if (to === 'bool') return `((${x.c})?1:0)`;
    let c = x.c;
    if (x.t === 'float') c = `Math.trunc(${c})`;
    else if ((x.t === 'byte' || x.t === 'bool') && (to === 'int' || to === 'uint' || to === 'long' || to === 'ulong')) return c;
    else if (x.t === 'int' && to === 'long') return c;
    else if (x.t === 'uint' && (to === 'long' || to === 'ulong')) return c;
    return wrap(to, c);
  }

  binop(op, a, b, line) {
    if (a.t === 'str' || b.t === 'str') {
      if (op === '+') return { c: `(B.str(${a.c},'${a.t}')+B.str(${b.c},'${b.t}'))`, t: 'str' };
      if (op === '==' || op === '!=') return { c: `((${a.c}${op === '==' ? '===' : '!=='}${b.c})?1:0)`, t: 'bool' };
      throw CErr(line, `Text ke saath "${op}" nahi chal sakta`);
    }
    if (op === '&&') return { c: `(((${a.c})&&(${b.c}))?1:0)`, t: 'bool' };
    if (op === '||') return { c: `(((${a.c})||(${b.c}))?1:0)`, t: 'bool' };
    if (['==', '!=', '<', '>', '<=', '>='].includes(op)) return { c: `((${a.c}${op === '==' ? '===' : op === '!=' ? '!==' : op}${b.c})?1:0)`, t: 'bool' };
    const rt = this.p2(promote(a.t, b.t));
    const A = a.c, Bc = b.c;
    if (op === '<<' || op === '>>') {
      const lt = this.p2(promote(a.t, 'int'));
      if (op === '<<') return { c: wrap(lt, `(${A})<<(${Bc})`), t: lt };
      return { c: lt === 'ulong' ? `((${A})>>>(${Bc}))` : `((${A})>>(${Bc}))`, t: lt };
    }
    if (rt === 'float') {
      if (op === '%') return { c: `B.fmod(${A},${Bc})`, t: 'float' };
      if (op === '&' || op === '|' || op === '^') return { c: wrap('long', `Math.trunc(${A})${op}Math.trunc(${Bc})`), t: 'long' };
      return { c: `(${A}${op}${Bc})`, t: 'float' };
    }
    switch (op) {
      case '+': case '-': return { c: wrap(rt, `${A}${op}${Bc}`), t: rt };
      case '*':
        if (rt === 'long') return { c: `Math.imul(${A},${Bc})`, t: rt };
        if (rt === 'ulong') return { c: `(Math.imul(${A},${Bc})>>>0)`, t: rt };
        return { c: wrap(rt, `${A}*${Bc}`), t: rt };
      case '/': return { c: wrap(rt, `B.idiv(${A},${Bc})`), t: rt };
      case '%': return { c: wrap(rt, `B.imod(${A},${Bc})`), t: rt };
      case '&': case '|': case '^': return { c: wrap(rt, `(${A})${op}(${Bc})`), t: rt };
    }
    throw CErr(line, 'Operator samajh nahi aaya: ' + op);
  }

  // ---- program ----
  parseProgram() {
    while (this.peek().t !== 'eof') {
      if (this.isOp(';')) { this.next(); continue; }
      this.topLevel();
    }
  }
  topLevel() {
    const line = this.peek().line;
    const k = this.peek();
    if (k.t === 'id' && k.v === 'struct' && this.peek(1).t === 'id' && !this.isOp('{', 2) && !this.isOp(';', 2)) { /* struct var decl: handled via parseType */ this.next(); }
    else if (k.t === 'id' && k.v === 'struct') { this.next(); const d = this.parseStruct(); if (d.name) this.structs[d.name] = d; this.expectOp(';'); return; }
    else if (k.t === 'id' && k.v === 'enum') { this.next(); this.parseEnum(); return; }
    else if (k.t === 'id' && k.v === 'typedef' && this.isId('struct', 1)) { this.next(); this.next(); const d = this.parseStruct(); const nt = this.next(); if (nt.t !== 'id') throw CErr(nt.line, 'typedef ka naam chahiye'); d.name = nt.v; this.structs[d.name] = d; this.expectOp(';'); return; }
    else if (k.t === 'id' && ['class', 'typedef', 'union', 'template', 'namespace'].includes(k.v))
      throw CErr(line, k.v === 'class' ? '"class" abhi support nahi hai. struct use karo (variables + functions alag).' : `"${k.v}" abhi support nahi hai`);
    const mods = this.skipQuals();
    const ty = this.parseType();
    if (!ty) {
      const w = this.peek();
      if (w.t === 'id' && this.peek(1).t === 'id') throw CErr(line, `"${w.v}" library/type abhi support nahi hai (Servo, Wire, LCD jaisi libraries agle version mein)`);
      throw CErr(line, `Samajh nahi aaya: "${w.v}". Yahan variable ya function ka type chahiye (jaise int, void)`);
    }
    const nameTok = this.next();
    if (nameTok.t !== 'id') throw CErr(line, 'Naam chahiye tha (variable ya function ka)');
    if (this.isOp('(') && !ty.startsWith('lib:')) return this.funcDef(ty, nameTok);
    this.p--;
    const decl = this.varDecl(ty, mods, true);
    this.globals.push(decl + ';');
    this.expectOp(';');
  }
  parseStruct() {
    let name = null; if (this.peek().t === 'id') name = this.next().v;
    this.expectOp('{'); const fields = [];
    while (!this.isOp('}')) {
      if (this.peek().t === 'eof') throw CErr(this.peek().line, 'struct band nahi hua ("}" chahiye)');
      this.skipQuals(); const ty = this.parseType(); if (!ty) throw CErr(this.peek().line, 'struct ke andar field ka type chahiye (jaise int x;)');
      for (;;) { const nt = this.next(); if (nt.t !== 'id') throw CErr(nt.line, 'Field ka naam chahiye'); const dims = []; while (this.isOp('[')) { this.next(); dims.push(this.expr().c); this.expectOp(']'); } fields.push({ n: nt.v, t: ty, dims }); if (this.isOp(',')) this.next(); else break; }
      this.expectOp(';');
    }
    this.expectOp('}'); return { name, fields };
  }
  fieldDefault(f) {
    const base = f.t.startsWith('S:') ? this.structDefault(f.t.slice(2)) : f.t === 'str' ? "''" : '0';
    if (!f.dims.length) return base;
    if (f.t.startsWith('S:')) return `B.newArrF(${f.dims[0]},()=>(${base}))`;
    return f.dims.length === 1 ? `B.newArr(${f.dims[0]},${base})` : `B.newArr2(${f.dims[0]},${f.dims[1]},${base})`;
  }
  structDefault(name) { return '({' + this.structs[name].fields.map(f => `${f.n}:${this.fieldDefault(f)}`).join(',') + '})'; }
  structInit(name) {
    const f = this.structs[name].fields, vals = []; let i = 0; this.expectOp('{');
    while (!this.isOp('}')) { const fd = f[i++]; if (!fd) throw CErr(this.peek().line, `struct ${name} mein itni values nahi aati`); if (this.isOp('{')) vals.push(fd.t.startsWith('S:') ? this.structInit(fd.t.slice(2)) : this.initList(fd.t, fd.dims.length)); else vals.push(this.conv(this.assign(), fd.t)); if (this.isOp(',')) this.next(); else break; }
    this.expectOp('}'); return '({' + f.map((fd, j) => `${fd.n}:${j < vals.length ? vals[j] : this.fieldDefault(fd)}`).join(',') + '})';
  }
  parseEnum() {
    let name = null; if (this.peek().t === 'id') name = this.next().v; if (name) this.enumTypes.add(name);
    this.expectOp('{'); let val = 0;
    while (!this.isOp('}')) {
      const nt = this.next(); if (nt.t !== 'id') throw CErr(nt.line, 'enum ka naam chahiye');
      if (this.isOp('=')) { this.next(); const e = this.ternary(); try { val = Math.trunc(Function('"use strict";return (' + e.c + ')')()); } catch (er) { throw CErr(nt.line, 'enum ki value constant number honi chahiye'); } }
      this.consts[nt.v] = [String(val), 'int']; val++;
      if (this.isOp(',')) this.next(); else break;
    }
    this.expectOp('}'); this.expectOp(';');
  }
  funcDef(ret, nameTok) {
    this.expectOp('(');
    const params = [];
    if (this.isId('void') && this.isOp(')', 1)) this.next();
    while (!this.isOp(')')) {
      this.skipQuals();
      const pt = this.parseType();
      if (!pt) throw CErr(this.peek().line, 'Parameter ka type chahiye');
      if (this.isOp('&') || this.isOp('*')) throw CErr(this.peek().line, 'Pointer / reference parameter abhi support nahi (&, *)');
      const pn = this.next(); if (pn.t !== 'id') throw CErr(pn.line, 'Parameter ka naam chahiye');
      let arr = 0; while (this.isOp('[')) { this.next(); while (!this.isOp(']')) this.next(); this.next(); arr++; }
      params.push({ n: pn.v, t: pt, arr });
      if (this.isOp(',')) this.next(); else break;
    }
    this.expectOp(')');
    this.newSigs[nameTok.v] = { ret, params };
    if (this.isOp(';')) { this.next(); return; }
    this.curFn = { ret }; this.fnName = nameTok.v;
    this.push();
    for (const p of params) this.declare(p.n, { t: p.t, dims: p.arr, js: 'v_' + p.n });
    const body = this.block(true);
    this.pop(); this.curFn = null;
    this.funcs.push(`function* f_${nameTok.v}(${params.map(p => 'v_' + p.n).join(',')}){B.now+=2;${body}}`);
  }

  // ---- declarations ----
  varDecl(ty, mods, isGlobal) {
    if (ty === 'void') throw CErr(this.peek().line, 'void type ka variable nahi ho sakta');
    const parts = [];
    for (;;) {
      if (this.isOp('*') || this.isOp('&')) throw CErr(this.peek().line, 'Pointer / reference abhi support nahi');
      const nt = this.next();
      if (nt.t !== 'id') throw CErr(nt.line, 'Variable ka naam chahiye');
      const dims = [];
      while (this.isOp('[')) {
        this.next();
        if (this.isOp(']')) dims.push(null); else dims.push(this.expr().c);
        this.expectOp(']');
      }
      let init = null, js = 'v_' + nt.v;
      const fill = ty === 'str' ? "''" : '0';
      if (mods.static && !isGlobal) { js = `v_${nt.v}$s${this.statics++}`; }
      if (ty.startsWith('lib:')) {
        let ca = [], mk;
        if (this.isOp('=')) { this.next(); mk = this.assign().c; } else { if (this.isOp('(')) { this.next(); ca = this.args().map(a => a.c); } mk = `B.mk('${ty.slice(4)}',[${ca.join(',')}])`; }
        this.declare(nt.v, { t: ty, dims: dims.length, js });
        parts.push(`${js}=${dims.length ? `B.newArrF(${dims[0]},()=>${mk})` : mk}`);
        if (this.isOp(',')) { this.next(); continue; } break;
      }
      if (this.isOp('=')) {
        this.next();
        if (this.isOp('{')) init = (ty.startsWith('S:') && !dims.length) ? this.structInit(ty.slice(2)) : this.initList(ty, dims.length);
        else {
          if (dims.length) throw CErr(nt.line, 'Array ko {a, b, c} se initialize karo');
          init = this.conv(this.assign(), ty);
        }
      } else if (ty.startsWith('S:')) { init = null; }
      else if (this.isOp('(') && !dims.length) {
        this.next(); init = this.conv(this.assign(), ty); this.expectOp(')');
      }
      let code;
      if (dims.length) {
        if (dims.length > 2) throw CErr(nt.line, '2 se zyada dimension wale array abhi support nahi');
        if (init) {
          if (dims.length === 1) code = `B.mkArr(${init},${dims[0] === null ? 'null' : dims[0]},${fill})`;
          else code = init;
        } else {
          if (dims.some(d => d === null)) throw CErr(nt.line, 'Array ka size likho, ya {..} se bharo');
          if (ty.startsWith('S:')) code = `B.newArrF(${dims[0]},()=>${this.structDefault(ty.slice(2))})`;
          else code = dims.length === 1 ? `B.newArr(${dims[0]},${fill})` : `B.newArr2(${dims[0]},${dims[1]},${fill})`;
        }
      } else code = init !== null ? init : (ty.startsWith('S:') ? this.structDefault(ty.slice(2)) : ty === 'str' ? "''" : '0');
      const sym = { t: ty, dims: dims.length, js };
      this.declare(nt.v, sym);
      if (mods.static && !isGlobal) { this.globals.push(`let ${js}=${code};`); }
      else parts.push(`${js}=${code}`);
      if (this.isOp(',')) { this.next(); continue; }
      break;
    }
    return parts.length ? 'let ' + parts.join(',') : '';
  }
  initList(ty, nd) {
    this.expectOp('{');
    const items = [];
    while (!this.isOp('}')) {
      if (this.isOp('{')) items.push(ty.startsWith('S:') && nd <= 1 ? this.structInit(ty.slice(2)) : this.initList(ty, nd - 1));
      else items.push(this.conv(this.assign(), ty));
      if (this.isOp(',')) this.next(); else break;
    }
    this.expectOp('}');
    return '[' + items.join(',') + ']';
  }

  // ---- statements ----
  block(noScope) {
    this.expectOp('{');
    if (!noScope) this.push();
    let out = '';
    while (!this.isOp('}')) {
      if (this.peek().t === 'eof') throw CErr(this.peek().line, '"}" band karna bhool gaye (block khatam nahi hua)');
      out += this.stmt() + '\n';
    }
    this.expectOp('}');
    if (!noScope) this.pop();
    return out;
  }
  body() {
    this.push();
    let s;
    if (this.isOp('{')) s = this.block(true); else s = this.stmt();
    this.pop();
    return '{' + s + '}';
  }
  edge() { return 'B.now+=4;if(B.now>=B.limit)yield 0;'; }
  stmt() {
    const k = this.peek();
    if (k.t === 'op') {
      if (k.v === '{') { return '{' + this.block() + '}'; }
      if (k.v === ';') { this.next(); return ''; }
    }
    if (k.t === 'id') {
      switch (k.v) {
        case 'if': {
          this.next(); this.expectOp('(');
          const c = this.expr(); this.expectOp(')');
          let s = `if(${c.c})${this.body()}`;
          if (this.isId('else')) { this.next(); s += this.isId('if') ? `else ${this.stmt()}` : `else${this.body()}`; }
          return s;
        }
        case 'while': {
          this.next(); this.expectOp('(');
          const c = this.expr(); this.expectOp(')');
          return `while(${c.c}){${this.edge()}${this.body()}}`;
        }
        case 'do': {
          this.next(); const b = this.body();
          if (!this.isId('while')) throw CErr(this.peek().line, '"while" chahiye (do ... while)');
          this.next(); this.expectOp('(');
          const c = this.expr(); this.expectOp(')'); this.expectOp(';');
          return `do{${this.edge()}${b}}while(${c.c});`;
        }
        case 'for': {
          this.next(); this.expectOp('('); this.push();
          let init = '';
          if (!this.isOp(';')) {
            if (this.startsDecl()) { const m = this.skipQuals(); init = this.varDecl(this.parseType(), m, false); }
            else init = this.exprList();
          }
          this.expectOp(';');
          const cond = this.isOp(';') ? '' : this.expr().c;
          this.expectOp(';');
          const step = this.isOp(')') ? '' : this.exprList();
          this.expectOp(')');
          const b = this.body(); this.pop();
          return `for(${init};${cond};${step}){${this.edge()}${b}}`;
        }
        case 'switch': {
          this.next(); this.expectOp('(');
          const c = this.expr(); this.expectOp(')'); this.expectOp('{'); this.push();
          let s = `switch(${c.c}){`;
          while (!this.isOp('}')) {
            if (this.isId('case')) { this.next(); const v = this.ternary(); this.expectOp(':'); s += `case ${v.c}:`; }
            else if (this.isId('default')) { this.next(); this.expectOp(':'); s += 'default:'; }
            else if (this.peek().t === 'eof') throw CErr(k.line, 'switch band nahi hua');
            else s += this.stmt();
          }
          this.expectOp('}'); this.pop();
          return s + '}';
        }
        case 'return': {
          this.next();
          if (this.isOp(';')) { this.next(); return 'return;'; }
          const e = this.expr(); this.expectOp(';');
          const rt = this.curFn ? this.curFn.ret : 'void';
          return `return ${rt === 'void' ? e.c : this.conv(e, rt)};`;
        }
        case 'break': this.next(); this.expectOp(';'); return 'break;';
        case 'continue': this.next(); this.expectOp(';'); return 'continue;';
      }
      if (this.startsDecl()) {
        const m = this.skipQuals(); const ty = this.parseType();
        const d = this.varDecl(ty, m, false); this.expectOp(';');
        return d ? d + ';' : '';
      }
    }
    const c = this.exprList(); this.expectOp(';');
    return c + ';';
  }
  exprList() {
    const parts = [this.exprStmt()];
    while (this.isOp(',')) { this.next(); parts.push(this.exprStmt()); }
    return parts.join(',');
  }
  exprStmt() {
    const a = this.peek(), b = this.peek(1), c = this.peek(2);
    const endOk = (x) => x.t === 'op' && (x.v === ';' || x.v === ')' || x.v === ',');
    if (a.t === 'id' && b.t === 'op' && (b.v === '++' || b.v === '--') && endOk(c)) {
      const s = this.lookup(a.v);
      if (s && !s.dims && s.t !== 'str') { this.p += 2; return `${s.js}=${wrap(s.t, `${s.js}${b.v[0]}1`)}`; }
    }
    if (a.t === 'op' && (a.v === '++' || a.v === '--') && b.t === 'id' && endOk(c)) {
      const s = this.lookup(b.v);
      if (s && !s.dims && s.t !== 'str') { this.p += 2; return `${s.js}=${wrap(s.t, `${s.js}${a.v[0]}1`)}`; }
    }
    return this.expr().c;
  }

  // ---- expressions ----
  expr() { return this.assign(); }
  assign() {
    const lhs = this.ternary();
    const k = this.peek();
    if (k.t === 'op' && ASSIGN.includes(k.v)) {
      if (!lhs.lv) throw CErr(k.line, 'Assignment (=) ke baayein taraf variable chahiye');
      this.next();
      const rhs = this.assign();
      const lv = lhs.lv, T = lv.t;
      const tgt = lv.kind === 'var' ? lv.js : `${lv.base}[${lv.idx}]`;
      if (k.v === '=') return { c: `(${tgt}=${this.conv(rhs, T)})`, t: T };
      const bop = k.v.slice(0, -1);
      if (lv.kind === 'var') return { c: `(${lv.js}=${this.conv(this.binop(bop, { c: lv.js, t: T }, rhs, k.line), T)})`, t: T };
      const tm = this.tmp();
      return { c: `(${tm}=${lv.idx},${lv.base}[${tm}]=${this.conv(this.binop(bop, { c: `${lv.base}[${tm}]`, t: T }, rhs, k.line), T)})`, t: T };
    }
    return lhs;
  }
  ternary() {
    const c = this.binary(1);
    if (this.isOp('?')) {
      this.next();
      const a = this.assign(); this.expectOp(':'); const b = this.ternary();
      const rt = (a.t === 'str' || b.t === 'str') ? 'str' : promote(a.t, b.t);
      return { c: `(${c.c}?${this.conv(a, rt)}:${this.conv(b, rt)})`, t: rt };
    }
    return c;
  }
  binary(minP) {
    let l = this.unary();
    for (;;) {
      const k = this.peek();
      if (k.t !== 'op') break;
      const p = PREC[k.v];
      if (!p || p < minP) break;
      this.next();
      const r = this.binary(p + 1);
      l = this.binop(k.v, l, r, k.line);
    }
    return l;
  }
  incdec(x, op, prefix, line) {
    if (!x.lv) throw CErr(line, '++ / -- sirf variable par chal sakta hai');
    const lv = x.lv, T = lv.t, d = op[0];
    const nv = (cur) => this.conv(this.binop(d, { c: cur, t: T }, { c: '1', t: 'int' }, line), T);
    if (lv.kind === 'var') {
      if (prefix) return { c: `(${lv.js}=${nv(lv.js)})`, t: T };
      const u = this.tmp();
      return { c: `(${u}=${lv.js},${lv.js}=${nv(lv.js)},${u})`, t: T };
    }
    const tm = this.tmp(), u = this.tmp(), e = `${lv.base}[${tm}]`;
    if (prefix) return { c: `(${tm}=${lv.idx},${e}=${nv(e)})`, t: T };
    return { c: `(${tm}=${lv.idx},${u}=${e},${e}=${nv(e)},${u})`, t: T };
  }
  unary() {
    const k = this.peek();
    if (k.t === 'op') {
      if (k.v === '!') { this.next(); const x = this.unary(); return { c: `(${x.c}?0:1)`, t: 'bool' }; }
      if (k.v === '-') { this.next(); const x = this.unary(); const t = this.p2(promote(x.t, 'int')); return { c: t === 'float' ? `(-${x.c})` : wrap(t, `-(${x.c})`), t }; }
      if (k.v === '+') { this.next(); return this.unary(); }
      if (k.v === '~') { this.next(); const x = this.unary(); const t = this.p2(promote(x.t, 'int')); return { c: wrap(t, `~(${x.c})`), t }; }
      if (k.v === '++' || k.v === '--') { this.next(); return this.incdec(this.unary(), k.v, true, k.line); }
      if (k.v === '&' && this.peek(1).t === 'id' && GLOBAL_LIBS.includes(this.peek(1).v)) { this.next(); return this.primary(); }
      if (k.v === '*' || k.v === '&') throw CErr(k.line, 'Pointer (* ya &) abhi support nahi hai (sirf &Wire chalta hai)');
      if (k.v === '(' && this.peek(1).t === 'id' && (TYPEWORDS.has(this.peek(1).v) || this.enumTypes.has(this.peek(1).v))) {
        const save = this.p; this.next();
        const ty = this.parseType();
        if (ty && this.isOp(')')) { this.next(); const x = this.unary(); return { c: this.conv(x, ty), t: ty }; }
        this.p = save;
      }
    }
    return this.postfix();
  }
  postfix() {
    let x = this.primary();
    for (;;) {
      const k = this.peek();
      if (k.t !== 'op') break;
      if (k.v === '[') {
        if (!x.dims) throw CErr(k.line, 'Ye array nahi hai, [ ] nahi laga sakte');
        this.next(); const idx = this.expr(); this.expectOp(']');
        const ic = idx.t === 'float' ? `Math.trunc(${idx.c})` : idx.c;
        const rem = x.dims - 1;
        const raw = `${x.c}[${ic}]`, isObj = x.t.startsWith('S:') || x.t.startsWith('lib:');
        x = { c: (rem || isObj) ? raw : `(${raw}??${x.t === 'str' ? "''" : '0'})`, t: x.t, dims: rem, lv: rem ? null : { kind: 'idx', base: x.c, idx: ic, t: x.t } };
        continue;
      }
      if (k.v === '++' || k.v === '--') { this.next(); x = this.incdec(x, k.v, false, k.line); continue; }
      if (k.v === '.' && x.t.startsWith('S:')) {
        this.next(); const m = this.next(), st = this.structs[x.t.slice(2)], f = st.fields.find(q => q.n === m.v);
        if (!f) throw CErr(m.line, `struct ${x.t.slice(2)} mein "${m.v}" naam ka field nahi hai`);
        x = { c: `${x.c}.${m.v}`, t: f.t, dims: f.dims.length, lv: f.dims.length ? null : { kind: 'idx', base: x.c, idx: `'${m.v}'`, t: f.t } };
        continue;
      }
      if (k.v === '.' && x.t.startsWith('lib:')) {
        this.next(); const m = this.next(); this.expectOp('(');
        x = this.libCall(x, m, this.args(), k.line); continue;
      }
      if (k.v === '.' && x.t === 'str') {
        this.next(); const m = this.next(); this.expectOp('(');
        const args = this.args(); x = this.strMethod(x, m, args); continue;
      }
      break;
    }
    return x;
  }
  args() {
    const a = [];
    while (!this.isOp(')')) {
      a.push(this.assign());
      if (this.isOp(',')) this.next(); else break;
    }
    this.expectOp(')');
    return a;
  }
  libCall(x, m, a, line) {
    const lib = x.t.slice(4), tbl = LIB_M[lib], rt = tbl && tbl[m.v];
    if (!rt) throw CErr(m.line, `${lib}.${m.v}() abhi support nahi hai.` + dym(m.v, Object.keys(tbl || {})));
    const pr = m.v === 'print' || m.v === 'println';
    const args = a.map((z) => pr ? `B.fmt(${z.c},'${z.t}')` : z.c);
    if (pr && a.length > 1) args[0] = `B.fmt(${a[0].c},'${a[0].t}',${a[1].c})`, args.length = 1;
    return this.n({ c: `(yield* B.m(${x.c},'${m.v}'${args.length ? ',' + args.join(',') : ''}))`, t: rt });
  }
  strMethod(x, m, a) {
    const c = x.c;
    switch (m.v) {
      case 'length': return { c: `${c}.length`, t: 'int' };
      case 'toInt': return { c: `B.toInt(${c})`, t: 'long' };
      case 'toFloat': return { c: `B.toFloat(${c})`, t: 'float' };
      case 'charAt': return { c: `(${c}.charCodeAt(${a[0].c})||0)`, t: 'char' };
      case 'substring': return { c: `${c}.substring(${a.map(z => z.c).join(',')})`, t: 'str' };
      case 'indexOf': return { c: `${c}.indexOf(${this.conv(a[0], 'str')})`, t: 'int' };
      case 'equals': return { c: `((${c}===${this.conv(a[0], 'str')})?1:0)`, t: 'bool' };
      case 'toUpperCase': case 'toLowerCase': case 'trim':
        if (x.lv && x.lv.kind === 'var') return { c: `(${x.lv.js}=${c}.${m.v === 'trim' ? 'trim' : m.v}())`, t: 'void' };
        return { c: `${c}.${m.v}()`, t: 'str' };
    }
    throw CErr(m.line, `String ka "${m.v}()" abhi support nahi`);
  }
  primary() {
    const k = this.next();
    if (k.t === 'num') return this.n({ c: k.v < 0 ? `(${k.v})` : String(k.v), t: k.ty });
    if (k.t === 'str') return { c: JSON.stringify(k.v), t: 'str' };
    if (k.t === 'op' && k.v === '(') { const e = this.expr(); this.expectOp(')'); return { c: `(${e.c})`, t: e.t, dims: e.dims }; }
    if (k.t === 'id') {
      if (k.v === 'Serial') return this.serial(k);
      if (GLOBAL_LIBS.includes(k.v) && !this.lookup(k.v)) return { c: 'B.' + k.v, t: 'lib:' + k.v };
      if (k.v === 'sizeof') {
        this.expectOp('(');
        const save = this.p, ty = this.parseType();
        if (ty && this.isOp(')')) { this.next(); return { c: String(SIZEOF[ty] || 2), t: 'uint' }; }
        this.p = save; const e = this.expr(); this.expectOp(')');
        return { c: e.dims ? `(${e.c}.length*${SIZEOF[e.t] || 2})` : String(SIZEOF[e.t] || 2), t: 'uint' };
      }
      if (this.isOp('(')) { this.next(); return this.n(this.call(k, this.args())); }
      const s = this.lookup(k.v);
      if (s) return this.n({ c: s.js, t: s.t, dims: s.dims, lv: s.dims ? null : { kind: 'var', js: s.js, t: s.t } });
      if (this.consts[k.v]) return this.n({ c: this.consts[k.v][0], t: this.consts[k.v][1] });
      if (this.newSigs[k.v] || this.sigs[k.v] || (this.pass1 && this.fnNames.has(k.v))) return { c: 'f_' + k.v, t: 'fn' };
      { const names = [...this.scopes.flatMap(m => [...m.keys()]), ...this.gsym.keys(), ...Object.keys(this.consts), ...Object.keys(this.sigs)]; throw CErr(k.line, `"${k.v}" pehle declare nahi kiya (spelling check karo, ya type likhna bhool gaye).` + dym(k.v, names)); }
    }
    throw CErr(k.line, k.t === 'eof' ? 'Code adhoora lag raha hai' : `Yahan "${k.v}" ka matlab samajh nahi aaya`);
  }
  serial(k) {
    this.expectOp('.');
    const m = this.next(); this.expectOp('(');
    const a = this.args();
    const n = m.v;
    switch (n) {
      case 'begin': case 'setTimeout': case 'flush': case 'end': return { c: '0', t: 'void' };
      case 'print': case 'println': {
        const nl = n === 'println' ? 1 : 0;
        if (!a.length) return { c: `B.sprint('','str',undefined,${nl})`, t: 'void' };
        return { c: `B.sprint(${a[0].c},'${a[0].t}',${a[1] ? a[1].c : 'undefined'},${nl})`, t: 'void' };
      }
      case 'write': return { c: `B.sprint(${a[0].c},'char',undefined,0)`, t: 'void' };
      case 'printf': return { c: `B.printf(${a.map(z => z.t === 'char' ? `B.cc(${z.c})` : z.c).join(',')})`, t: 'void' };
      case 'available': return { c: 'B.sAvail()', t: 'int' };
      case 'read': return { c: 'B.sRead()', t: 'int' };
      case 'peek': return { c: 'B.sPeek()', t: 'int' };
      case 'parseInt': return { c: 'B.sParseInt()', t: 'long' };
      case 'parseFloat': return { c: 'B.sParseFloat()', t: 'float' };
      case 'readString': return { c: 'B.sReadStr(null)', t: 'str' };
      case 'readStringUntil': return { c: `B.sReadStr(${a[0].c})`, t: 'str' };
    }
    throw CErr(m.line, `Serial.${n}() abhi support nahi.` + dym(n, ['begin', 'print', 'println', 'printf', 'write', 'available', 'read', 'peek', 'parseInt', 'parseFloat', 'readString', 'readStringUntil', 'flush', 'end', 'setTimeout']));
  }
  call(k, a) {
    const n = k.v, line = k.line;
    const need = (c) => { if (a.length < c) throw CErr(line, `${n}() ko kam se kam ${c} value chahiye`); };
    const C = (i) => a[i].c;
    const user = this.newSigs[n] || this.sigs[n];
    if (!user && this.pass1 && this.fnNames.has(n)) return { c: '0', t: 'int' };
    if (user) {
      const ps = user.params;
      if (a.length !== ps.length && this.sigs[n]) throw CErr(line, `${n}() ko ${ps.length} value chahiye, aapne ${a.length} di`);
      const args = a.map((x, i) => (ps[i] && !ps[i].arr) ? this.conv(x, ps[i].t) : x.c);
      return { c: `(yield* f_${n}(${args.join(',')}))`, t: user.ret };
    }
    switch (n) {
      case 'pinMode': need(2); return { c: `B.pinMode(${C(0)},${C(1)})`, t: 'void' };
      case 'digitalWrite': need(2); return { c: `B.digitalWrite(${C(0)},${C(1)})`, t: 'void' };
      case 'digitalRead': need(1); return { c: `B.digitalRead(${C(0)})`, t: 'int' };
      case 'analogRead': need(1); return { c: `B.analogRead(${C(0)})`, t: 'int' };
      case 'analogWrite': need(2); return { c: `B.analogWrite(${C(0)},${C(1)})`, t: 'void' };
      case 'analogReference': case 'randomSeed': return { c: `B.seed(${a.length ? C(0) : 1})`, t: 'void' };
      case 'delay': need(1); return { c: `(yield* B.delay(${C(0)}))`, t: 'void' };
      case 'delayMicroseconds': need(1); return { c: `(yield* B.delayUs(${C(0)}))`, t: 'void' };
      case 'millis': return { c: 'B.millis()', t: 'ulong' };
      case 'micros': return { c: 'B.micros()', t: 'ulong' };
      case 'tone': need(2); return { c: `B.tone(${C(0)},${C(1)},${a[2] ? C(2) : 0})`, t: 'void' };
      case 'noTone': need(1); return { c: `B.tone(${C(0)},0,0)`, t: 'void' };
      case 'map': need(5); return { c: `B.map(${a.map(x => x.c).join(',')})`, t: 'long' };
      case 'constrain': { need(3); const t = promote(a[0].t, promote(a[1].t, a[2].t)); return { c: `Math.min(Math.max(${C(0)},${C(1)}),${C(2)})`, t }; }
      case 'min': case 'max': { need(2); const t = promote(a[0].t, a[1].t); return { c: `Math.${n}(${C(0)},${C(1)})`, t }; }
      case 'abs': need(1); return { c: `Math.abs(${C(0)})`, t: a[0].t === 'float' ? 'float' : promote(a[0].t, 'int') };
      case 'sq': need(1); return this.binop('*', a[0], a[0], line);
      case 'pow': need(2); return { c: `Math.pow(${C(0)},${C(1)})`, t: 'float' };
      case 'sqrt': case 'sin': case 'cos': case 'tan': case 'log': case 'exp': case 'floor': case 'ceil': case 'atan': case 'asin': case 'acos':
        need(1); return { c: `Math.${n}(${C(0)})`, t: 'float' };
      case 'log10': need(1); return { c: `Math.log10(${C(0)})`, t: 'float' };
      case 'round': need(1); return { c: `Math.round(${C(0)})`, t: 'long' };
      case 'random': need(1); return { c: a[1] ? `B.random(${C(0)},${C(1)})` : `B.random(0,${C(0)})`, t: 'long' };
      case 'bitRead': need(2); return { c: `((${C(0)}>>${C(1)})&1)`, t: 'int' };
      case 'lowByte': need(1); return { c: `((${C(0)})&255)`, t: 'byte' };
      case 'highByte': need(1); return { c: `(((${C(0)})>>8)&255)`, t: 'byte' };
      case 'F': need(1); return a[0];
      case 'String': need(1); return { c: `B.str(${C(0)},'${a[0].t}')`, t: 'str' };
      case 'attachInterrupt': need(3); if (a[1].t !== 'fn') throw CErr(line, 'attachInterrupt ka doosra argument function ka naam hona chahiye (jaise isr)'); return { c: `B.attachInterrupt(${C(0)},${C(1)},${C(2)})`, t: 'void' };
      case 'detachInterrupt': need(1); return { c: `B.detachInterrupt(${C(0)})`, t: 'void' };
      case 'digitalPinToInterrupt': need(1); return a[0];
      case 'noInterrupts': case 'interrupts': case 'yield': return { c: '0', t: 'void' };
      case 'analogReadResolution': need(1); return { c: `B.adcRes(${C(0)})`, t: 'void' };
      case 'analogWriteResolution': return { c: '0', t: 'void' };
      case 'ledcAttach': need(3); return { c: `B.ledcAttach(${C(0)},${C(1)},${C(2)})`, t: 'void' };
      case 'ledcSetup': need(3); return { c: `B.ledcSetup(${C(0)},${C(1)},${C(2)})`, t: 'void' };
      case 'ledcAttachPin': need(2); return { c: `B.ledcAttachPin(${C(0)},${C(1)})`, t: 'void' };
      case 'ledcWrite': need(2); return { c: `B.ledcWrite(${C(0)},${C(1)})`, t: 'void' };
      case 'ledcDetach': return { c: '0', t: 'void' };
      case 'analogReadMilliVolts': need(1); return { c: `Math.round(B.analogRead(${C(0)})/(B.adcMaxNow())*${this.board ? this.board.vcc * 1000 : 5000})`, t: 'long' };
      case 'pulseIn': need(2); return { c: `(yield* B.pulseIn(${C(0)},${C(1)}${a[2] ? ',' + C(2) : ''}))`, t: 'ulong' };
      case 'shiftOut': need(4); return { c: `(yield* B.shiftOut(${C(0)},${C(1)},${C(2)},${C(3)}))`, t: 'void' };
      case 'shiftIn': need(3); return { c: `(yield* B.shiftIn(${C(0)},${C(1)},${C(2)}))`, t: 'byte' };
      case 'isnan': need(1); return { c: `(Number.isNaN(${C(0)})?1:0)`, t: 'bool' };
      case 'bit': case '_BV': need(1); return { c: `(1<<(${C(0)}))`, t: 'int' };
      case 'bitSet': case 'bitClear': case 'bitWrite': {
        need(2); const lv = a[0].lv; if (!lv) throw CErr(line, `${n}() ka pehla argument variable hona chahiye`);
        const bitv = n === 'bitWrite' ? `(${C(2)})?1:0` : null, m = `(1<<(${C(1)}))`;
        const nv = n === 'bitSet' ? `(${a[0].c})|${m}` : n === 'bitClear' ? `(${a[0].c})&~${m}` : `((${bitv})?((${a[0].c})|${m}):((${a[0].c})&~${m}))`;
        const tgt = lv.kind === 'var' ? lv.js : `${lv.base}[${lv.idx}]`;
        return { c: `(${tgt}=${wrap(a[0].t === 'float' ? 'long' : a[0].t, nv)},0)`, t: 'void' };
      }
      case 'radians': need(1); return { c: `(${C(0)}*Math.PI/180)`, t: 'float' };
      case 'degrees': need(1); return { c: `(${C(0)}*180/Math.PI)`, t: 'float' };
      case 'atan2': need(2); return { c: `Math.atan2(${C(0)},${C(1)})`, t: 'float' };
      case 'fabs': need(1); return { c: `Math.abs(${C(0)})`, t: 'float' };
      case 'isDigit': need(1); return { c: `(/[0-9]/.test(String.fromCharCode(${C(0)}))?1:0)`, t: 'bool' };
      case 'isAlpha': need(1); return { c: `(/[A-Za-z]/.test(String.fromCharCode(${C(0)}))?1:0)`, t: 'bool' };
      case 'isAlphaNumeric': need(1); return { c: `(/[A-Za-z0-9]/.test(String.fromCharCode(${C(0)}))?1:0)`, t: 'bool' };
      case 'isUpperCase': need(1); return { c: `(/[A-Z]/.test(String.fromCharCode(${C(0)}))?1:0)`, t: 'bool' };
      case 'isLowerCase': need(1); return { c: `(/[a-z]/.test(String.fromCharCode(${C(0)}))?1:0)`, t: 'bool' };
      case 'isSpace': need(1); return { c: `(/\\s/.test(String.fromCharCode(${C(0)}))?1:0)`, t: 'bool' };
    }
    if (k.v === 'setup' || k.v === 'loop') throw CErr(line, `${n}() ko khud call mat karo`);
    throw CErr(line, `"${n}()" function nahi mila (naam galat hai, ya ye library abhi support nahi).` + dym(n, [...(Compiler.BUILTINS || []), ...Object.keys(this.sigs), ...Object.keys(this.newSigs || {})]));
  }
}

function compileSketch(src, board) {
  const raw = lex(src);
  for (const t of raw) if (t.t === 'pp') { const m = /^#\s*include\s*[<"]([^>"]+)[>"]/.exec(t.v); if (m && !SUPPORTED_INC.has(m[1])) throw CErr(t.line, `Library "${m[1]}" abhi support nahi hai. Abhi ye chalti hain: Servo, LiquidCrystal(+I2C), DHT, NewPing, EEPROM, MPU6050_light, Adafruit_SSD1306, VL53L0X, SD, ESP_I2S, USBCamera.`); }
  const toks = preprocess(raw);
  let c = new Compiler(toks, {}, board, true);
  c.parseProgram();
  const sigs = c.newSigs;
  c = new Compiler(toks, sigs, board, false);
  c.parseProgram();
  if (!sigs.setup) throw CErr(1, 'void setup() nahi mila');
  if (!sigs.loop) throw CErr(1, 'void loop() nahi mila');
  const code = `"use strict";return (function*(){
${c.tmps.length ? 'let ' + c.tmps.join(',') + ';' : ''}
${c.globals.join('\n')}
${c.funcs.join('\n')}
yield* f_setup();
for(;;){yield* f_loop();B.now+=10;if(B.now>=B.limit)yield 0;}
})();`;
  return { code, factory: new Function('B', code) };
}

Compiler.BUILTINS = [...Compiler.prototype.call.toString().matchAll(/case '(\w+)'/g)].map(m => m[1]).concat(['setup', 'loop']);
if (typeof module !== 'undefined') module.exports = { compileSketch };
