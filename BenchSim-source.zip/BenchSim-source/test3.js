const { Sim } = require('./sim.js');
let fails = 0;
const ok = (c, m) => { if (!c) { fails++; console.log('FAIL', m); } else console.log('ok  ', m); };
function mk(board, code, comps, wires) {
  const s = new Sim(); s.setBoard(board); s.setCircuit(comps, wires);
  const out = { t: '', w: [] }; s.onSerial = (x) => out.t += x; s.onWarn = (k, m) => out.w.push(k + ':' + m);
  const cr = s.compile(code); if (!cr.factory) { console.log('COMPILE', JSON.stringify(cr.errors || cr)); fails++; return { s, out }; }
  s.start(cr.factory); return { s, out };
}
const run = (r, sec) => { let sn; for (let i = 0; i < sec * 60; i++) { r.s.advance(1e6 / 60, 50); sn = r.s.snapshot(); } return sn; };
const S = 'esp32s3';
const i2c = (id, vcc) => [[`P:GPIO8`, `c${id}:SDA`], [`P:GPIO9`, `c${id}:SCL`], ['P:3V3', `c${id}:${vcc}`], ['P:GND1', `c${id}:GND`]];

// MPU6050
{
  const code = `#include <Wire.h>\n#include <MPU6050_light.h>\nMPU6050 mpu(Wire);\nvoid setup(){ Serial.begin(115200); Wire.begin(); byte st = mpu.begin(); Serial.println(st); mpu.calcOffsets(); }\nvoid loop(){ mpu.update(); Serial.println(mpu.getAngleX()); delay(100);}`;
  const r = mk(S, code, [{ id: 1, type: 'mpu6050', addr: 0x68, pitch: 30, roll: 0, spin: 0, temp: 25 }], i2c(1, 'VCC')); run(r, 3);
  const L = r.out.t.trim().split('\n'); ok(L[0].trim() === '0', 'MPU begin ok: ' + L[0]); ok(Math.abs(parseFloat(L[L.length - 1]) - 30) < 2, 'MPU angle ~30: ' + L[L.length - 1]);
}
// MPU wrong address
{
  const code = `#include <Wire.h>\n#include <MPU6050_light.h>\nMPU6050 mpu(Wire);\nvoid setup(){ Serial.begin(115200); Wire.begin(); Serial.println(mpu.begin()); }\nvoid loop(){ delay(100);}`;
  const r = mk(S, code, [{ id: 1, type: 'mpu6050', addr: 0x69 }], i2c(1, 'VCC')); run(r, 1);
  ok(r.out.t.trim() === '1' && r.out.w.some(w => /addr/.test(w)), 'MPU address mismatch detected');
}
// OLED
{
  const code = `#include <Wire.h>\n#include <Adafruit_GFX.h>\n#include <Adafruit_SSD1306.h>\nAdafruit_SSD1306 display(128, 64, &Wire, -1);\nvoid setup(){ Serial.begin(115200); if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)){ Serial.println("fail"); return; } display.clearDisplay(); display.setTextSize(2); display.setTextColor(WHITE); display.setCursor(0,0); display.println("Hello"); display.drawRect(0,30,50,20,WHITE); display.display(); Serial.println("ok"); }\nvoid loop(){ delay(100);}`;
  const r = mk(S, code, [{ id: 1, type: 'oled', addr: 0x3C }], i2c(1, 'VCC')); const sn = run(r, 1);
  ok(r.out.t.includes('ok'), 'OLED begin ok'); ok(sn[1] && sn[1].cmds && sn[1].cmds.length === 2 && sn[1].cmds[0].s === 'Hello', 'OLED shows text+rect');
}
// OLED powered from 5V on wrong SDA
{
  const code = `#include <Wire.h>\n#include <Adafruit_SSD1306.h>\nAdafruit_SSD1306 display(128, 64, &Wire, -1);\nvoid setup(){ Serial.begin(115200); Serial.println(display.begin(SSD1306_SWITCHCAPVCC, 0x3C)); }\nvoid loop(){ delay(100);}`;
  const w = i2c(1, 'VCC'); w[0] = ['P:GPIO4', 'c1:SDA'];
  const r = mk(S, code, [{ id: 1, type: 'oled', addr: 0x3C }], w); run(r, 1);
  ok(r.out.t.trim() === '0' && r.out.w.some(x => /SDA/.test(x)), 'OLED wrong SDA detected');
}
// VL53L0X
{
  const code = `#include <Wire.h>\n#include <VL53L0X.h>\nVL53L0X sensor;\nvoid setup(){ Serial.begin(115200); Wire.begin(); sensor.setTimeout(500); if(!sensor.init()){ Serial.println("fail"); return; } sensor.startContinuous(); }\nvoid loop(){ int d = sensor.readRangeContinuousMillimeters(); Serial.println(d); delay(100);}`;
  const r = mk(S, code, [{ id: 1, type: 'vl53', dist: 400 }], i2c(1, 'VIN')); run(r, 2);
  const L = r.out.t.trim().split('\n'); ok(Math.abs(parseInt(L[L.length - 1]) - 400) < 10, 'VL53 reading ~400: ' + L[L.length - 1]);
}
// SD card
{
  const code = `#include <SD.h>\n#include <SPI.h>\nvoid setup(){ Serial.begin(115200); if(!SD.begin(10)){ Serial.println("sdfail"); return; } File f = SD.open("/log.txt", FILE_WRITE); f.println("hello"); f.close(); File r = SD.open("/log.txt"); while(r.available()){ Serial.write(r.read()); } r.close(); }\nvoid loop(){ delay(100);}`;
  const w = [['P:GPIO12', 'c1:SCK'], ['P:GPIO13', 'c1:MISO'], ['P:GPIO11', 'c1:MOSI'], ['P:GPIO10', 'c1:CS'], ['P:5V', 'c1:VCC'], ['P:GND1', 'c1:GND']];
  const r = mk(S, code, [{ id: 1, type: 'sdcard' }], w); const sn = run(r, 1);
  ok(r.out.t.includes('hello'), 'SD write+read: ' + JSON.stringify(r.out.t)); ok(sn[1].files.length === 1, 'SD file listed');
}
// INMP441
{
  const code = `#include <ESP_I2S.h>\nI2SClass I2S;\nvoid setup(){ Serial.begin(115200); I2S.setPins(5,6,-1,7); if(!I2S.begin(I2S_MODE_STD, 16000, I2S_DATA_BIT_WIDTH_16BIT, I2S_SLOT_MODE_MONO)){ Serial.println("fail"); } }\nvoid loop(){ int mx=0; for(int i=0;i<256;i++){ int v = I2S.read(); if(abs(v)>mx) mx=abs(v);} Serial.println(mx); delay(50);}`;
  const w = [['P:GPIO5', 'c1:SCK'], ['P:GPIO6', 'c1:WS'], ['P:GPIO7', 'c1:SD'], ['P:3V3', 'c1:VDD'], ['P:GND1', 'c1:GND'], ['P:GND2', 'c1:LR']];
  const r = mk(S, code, [{ id: 1, type: 'inmp441', level: 0.5, freq: 440 }], w); run(r, 1);
  const L = r.out.t.trim().split('\n'); ok(parseInt(L[L.length - 1]) > 4000, 'mic amplitude: ' + L[L.length - 1]);
}
// MAX98357A + speaker
{
  const code = `#include <ESP_I2S.h>\nI2SClass I2S;\nvoid setup(){ I2S.setPins(5,6,7,-1); I2S.begin(I2S_MODE_STD, 16000, I2S_DATA_BIT_WIDTH_16BIT, I2S_SLOT_MODE_MONO); }\nvoid loop(){ for(int i=0;i<160;i++){ int16_t s = (i%40<20)? 8000 : -8000; I2S.write(s); } }`;
  const w = [['P:GPIO7', 'c1:DIN'], ['P:GPIO5', 'c1:BCLK'], ['P:GPIO6', 'c1:LRC'], ['P:5V', 'c1:VIN'], ['P:GND1', 'c1:GND'], ['c1:SPK+', 'c2:+'], ['c1:SPK-', 'c2:-']];
  const r = mk(S, code, [{ id: 1, type: 'max98357' }, { id: 2, type: 'speaker' }], w); const sn = run(r, 1);
  ok(sn[1].on && Math.abs(sn[1].freq - 400) < 60, 'amp plays ~400Hz: ' + sn[1].on + ' ' + (sn[1].freq || 0).toFixed(0));
}
// TB6612 + MT3608 + motor
{
  const code = `void setup(){ pinMode(4,OUTPUT); pinMode(5,OUTPUT); pinMode(6,OUTPUT); pinMode(7,OUTPUT); digitalWrite(4,HIGH); digitalWrite(5,HIGH); digitalWrite(6,LOW); digitalWrite(7,HIGH);}\nvoid loop(){ delay(100);}`;
  const w = [['P:GPIO4', 'c1:STBY'], ['P:GPIO5', 'c1:PWMA'], ['P:GPIO6', 'c1:AIN1'], ['P:GPIO7', 'c1:AIN2'], ['P:3V3', 'c1:VCC'], ['P:GND1', 'c1:GND'],
    ['c3:+', 'c4:IN+'], ['c3:-', 'c4:IN-'], ['c4:IN-', 'P:GND2'], ['c4:OUT+', 'c1:VM'], ['c4:OUT-', 'P:GND1'], ['c1:AO1', 'c2:M1'], ['c1:AO2', 'c2:M2']];
  const r = mk(S, code, [{ id: 1, type: 'tb6612' }, { id: 2, type: 'motor' }, { id: 3, type: 'batt', val: 3.7 }, { id: 4, type: 'mt3608', vout: 6 }], w); const sn = run(r, 1.5);
  ok(sn[4].on && sn[2].v < -4 && Math.abs(sn[2].v) < 6.1, 'boost->TB6612->motor reverse: v=' + sn[2].v.toFixed(2) + ' boost=' + sn[4].on);
}
// Radar + camera
{
  const code = `void setup(){ Serial.begin(115200); pinMode(4,INPUT);} void loop(){ Serial.println(digitalRead(4)); delay(100);}`;
  const r = mk(S, code, [{ id: 1, type: 'radar', motion: true }], [['P:5V', 'c1:VIN'], ['P:GND1', 'c1:GND'], ['P:GPIO4', 'c1:OUT']]); run(r, 1);
  ok(r.out.t.trim().endsWith('1'), 'radar motion -> HIGH');
  const code2 = `#include <USBCamera.h>\nUSBCamera cam;\nvoid setup(){ Serial.begin(115200); Serial.println(cam.begin()); }\nvoid loop(){ cam.capture(); Serial.println(cam.brightness()); delay(100);}`;
  const r2 = mk(S, code2, [{ id: 1, type: 'camera', objX: 0.5, light: 0.5, motion: false }], [['P:5V', 'c1:VBUS'], ['P:GND1', 'c1:GND'], ['P:GPIO19', 'c1:DM'], ['P:GPIO20', 'c1:DP']]); run(r2, 1);
  const L = r2.out.t.trim().split('\n'); ok(L[0].trim() === '1' && Math.abs(parseInt(L[L.length - 1]) - 128) < 3, 'camera brightness: ' + L.join(','));
}
// 32-bit int on S3
{
  const r = mk(S, `void setup(){ Serial.begin(115200); int x = 40000; x = x * 2; Serial.println(x); Serial.printf("v=%d %.2f\\n", 5, 3.14159); } void loop(){ delay(10);}`, [], []); run(r, 0.3);
  ok(r.out.t.includes('80000') && r.out.t.includes('v=5 3.14'), 'int32 + printf: ' + JSON.stringify(r.out.t));
}
console.log(fails ? fails + ' FAILED' : 'ALL PASSED'); process.exit(fails ? 1 : 0);
