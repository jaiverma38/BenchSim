// ===== UI: bench canvas, wiring, controls, code, serial =====
(function () {
  const $ = (id) => document.getElementById(id);
  const S = { comps: [], wires: [], nextId: 1, sel: null, pending: null, zoom: 1, counters: {}, board: 'uno', cat: 'basic' };
  const sim = new Sim();
  let running = false, speed = 1, lastTs = 0, serialBuf = '', serialText = '', soundOn = true;
  let audio = null, osc = null, gain = null, oblB = 0, drag = null;
  const warns = [];
  const svg = $('bench'), layerW = $('layerW'), layerC = $('layerC'), rubber = $('rubber');
  const WIRECOL = ['#2f80ed', '#27ae60', '#e2b20f', '#b45bd6', '#f2994a', '#19b5c9'];

  // ---------- geometry ----------
  function termPos(t) {
    if (t.startsWith('P:')) return boardTermPos(t);
    const m = /^c(\d+):(.+)$/.exec(t); if (!m) return [0, 0];
    const c = S.comps.find(x => x.id === +m[1]); if (!c) return [0, 0];
    const o = COMPS[c.type].terms[m[2]]; return o ? [c.x + o[0], c.y + o[1]] : [c.x, c.y];
  }
  function termExists(t) {
    if (t.startsWith('P:')) return !!CUR.pos[t];
    const m = /^c(\d+):(.+)$/.exec(t); const c = m && S.comps.find(x => x.id === +m[1]); return !!(c && COMPS[c.type].terms[m[2]]);
  }
  function svgPt(e) { const p = svg.createSVGPoint(); p.x = e.clientX; p.y = e.clientY; return p.matrixTransform(svg.getScreenCTM().inverse()); }
  function wireColor(w, i) {
    if (w[0] === 'P:5V' || w[1] === 'P:5V' || w[0] === 'P:3V3' || w[1] === 'P:3V3') return '#e5372b';
    if (w[0].startsWith('P:GND') || w[1].startsWith('P:GND')) return '#2b2f33';
    return WIRECOL[i % WIRECOL.length];
  }
  function wirePath(a, b) { const d1 = b[1] >= a[1] ? 38 : -38, d2 = a[1] > b[1] ? 38 : -38; return `M${a[0]} ${a[1]} C${a[0]} ${a[1] + d1} ${b[0]} ${b[1] + d2} ${b[0]} ${b[1]}`; }
  function viewH() { return Math.max(580, CUR.bottom + 330 - 60); }

  // ---------- render ----------
  function applyBoard(id, quiet) {
    S.board = id; sim.setBoard(id); setBoardLayout(id); { const bs = document.querySelector('.brand small'); if (bs) bs.textContent = BOARDS[id].name; }
    $('boardG').innerHTML = CUR.markup; svg.setAttribute('viewBox', `0 60 400 ${viewH()}`);
    svg.querySelector('#bg1').setAttribute('height', viewH()); svg.querySelector('#bg2').setAttribute('height', viewH());
    const before = S.wires.length; S.wires = S.wires.filter(w => termExists(w[0]) && termExists(w[1]));
    $('boardNote').textContent = BOARDS[id].note;
    if (!quiet && before !== S.wires.length) hint(`${before - S.wires.length} wire hata di gayi (ye pins is board par nahi hain).`);
  }
  function renderWires() {
    layerW.innerHTML = S.wires.map((w, i) => { const a = termPos(w[0]), b = termPos(w[1]), d = wirePath(a, b);
      return `<g class="wire${S.sel && S.sel.w === i ? ' sel' : ''}"><path d="${d}" class="wcase"/><path d="${d}" class="wcol" stroke="${wireColor(w, i)}"/><path d="${d}" class="whit" data-w="${i}"/></g>`; }).join('');
  }
  function renderComps() {
    layerC.innerHTML = S.comps.map(c => `<g class="comp${S.sel && S.sel.c === c.id ? ' sel' : ''}" data-c="${c.id}" data-type="${c.type}" transform="translate(${c.x},${c.y})">${compMarkup(c)}</g>`).join('');
  }
  function refreshComp(c) { const g = layerC.querySelector(`[data-c="${c.id}"]`); if (g) g.innerHTML = compMarkup(c); }
  function renderPending() {
    svg.querySelectorAll('.term.pend').forEach(n => n.classList.remove('pend'));
    if (S.pending) { const n = svg.querySelector(`[data-t="${S.pending}"]`); if (n) n.classList.add('pend'); }
  }
  function hint(msg) { $('hint').textContent = msg || 'Pin par tap karo, phir doosre pin par tap karo: wire ban jaayegi. Ya ek pin se doosre pin tak ungli ghumao.'; }
  function termLabel(t) { if (t.startsWith('P:')) return t.slice(2).replace(/GND\d/, 'GND'); const m = /^c(\d+):(.+)$/.exec(t); const c = S.comps.find(x => x.id === +m[1]); return (c ? c.label : '?') + '.' + m[2]; }
  function changed() { sim.setCircuit(S.comps, S.wires); renderWires(); renderComps(); renderPending(); renderInspector(); renderLive(); }

  // ---------- components ----------
  function addComp(type, o) {
    const d = COMPS[type], n = (S.counters[type] = (S.counters[type] || 0) + 1);
    const used = S.comps.map(c => c.x + ',' + c.y), base = CUR.bottom + 100;
    let pos = null;
    for (let r = 0; r < 12 && !pos; r++) for (const x of [90, 200, 310]) { const y = base + r * 110; if (!used.includes(x + ',' + y)) { pos = [x, y]; break; } }
    const c = Object.assign({ id: S.nextId++, type, x: pos[0], y: pos[1], label: (PREFIX[type] || type.toUpperCase()) + n }, JSON.parse(JSON.stringify(d.init || {})), o || {});
    S.comps.push(c); return c;
  }
  function removeComp(id) {
    S.comps = S.comps.filter(c => c.id !== id);
    S.wires = S.wires.filter(w => !w[0].startsWith(`c${id}:`) && !w[1].startsWith(`c${id}:`));
    S.sel = null; changed();
  }
  function addWire(a, b) {
    if (a === b) return;
    if (S.wires.some(w => (w[0] === a && w[1] === b) || (w[0] === b && w[1] === a))) { hint('Ye wire pehle se hai.'); return; }
    S.wires.push([a, b]); S.pending = null; hint(termLabel(a) + ' ↔ ' + termLabel(b) + ' jod diya.'); changed();
  }
  function clearAll() { S.comps = []; S.wires = []; S.sel = null; S.pending = null; S.counters = {}; S.nextId = 1; changed(); }
  function loadExample(ex) {
    if (ex.board !== S.board) { $('boardSel').value = ex.board || 'uno'; applyBoard(ex.board || 'uno', true); }
    const dy = CUR.bottom - 365; S.counters = {};
    S.comps = ex.comps.map(c => { S.counters[c.type] = (S.counters[c.type] || 0) + 1; return Object.assign({ label: (PREFIX[c.type] || c.type) + S.counters[c.type] }, JSON.parse(JSON.stringify(COMPS[c.type].init || {})), c, { y: c.y > 230 ? c.y + dy : c.y }); });
    S.nextId = Math.max(0, ...S.comps.map(c => c.id)) + 1;
    S.wires = ex.wires.map(w => w.slice()).filter(w => termExists(w[0]) && termExists(w[1])); S.sel = null; S.pending = null;
    $('code').value = ex.code; setStatusCode(''); changed();
  }

  // ---------- palette ----------
  function buildPalette() {
    $('catSel').innerHTML = CATS.map(([k, n]) => `<option value="${k}">${n}</option>`).join('');
    $('catSel').value = S.cat; renderPalette();
  }
  function renderPalette() {
    $('palette').innerHTML = Object.keys(COMPS).filter(t => COMPS[t].cat === S.cat).map(t => `<button class="btn" data-add="${t}">+ ${COMPS[t].name}</button>`).join('');
    $('palette').querySelectorAll('[data-add]').forEach(b => b.onclick = () => { const c = addComp(b.dataset.add); S.sel = { c: c.id }; changed(); hint(c.label + ' add hua. Isse khiskao, phir pin se pin wire jodo.'); });
  }

  // ---------- inspector + live controls ----------
  function renderInspector() {
    const box = $('inspector');
    if (!S.sel) { box.hidden = true; return; }
    box.hidden = false;
    if (S.sel.w !== undefined) {
      const w = S.wires[S.sel.w]; if (!w) { box.hidden = true; return; }
      box.innerHTML = `<div class="insp-t"><b>Wire</b><span>${termLabel(w[0])} ↔ ${termLabel(w[1])}</span></div><button class="btn danger" id="delSel">Wire hatao</button>`;
      $('delSel').onclick = () => { S.wires.splice(S.sel.w, 1); S.sel = null; changed(); };
      return;
    }
    const c = S.comps.find(x => x.id === S.sel.c); if (!c) { box.hidden = true; return; }
    const d = COMPS[c.type]; let ctl = '';
    (d.props || []).forEach((p, i) => {
      if (p.kind === 'sel') ctl += `<label class="fld">${p.label} <select data-p="${i}">${p.opts.map(o => `<option value="${o}" ${String(o) === String(c[p.k]) ? 'selected' : ''}>${p.fmt ? p.fmt(o) : o}</option>`).join('')}</select></label>`;
      else {
        const us = UNITS[p.units]; let best = us[0]; for (const u of us) if (c[p.k] >= u[1] * 0.999) best = u;
        ctl += `<label class="fld">${p.label} <select data-pre="${i}"><option value="">Preset</option>${p.presets.map(v => `<option value="${v}">${fmtU(v, p.units)}</option>`).join('')}</select></label>
        <span class="fld"><input type="number" step="any" min="0" data-n="${i}" value="${+(c[p.k] / best[1]).toPrecision(4)}" aria-label="${p.label}"><select data-u="${i}">${us.map(u => `<option value="${u[1]}" ${u === best ? 'selected' : ''}>${u[0]}</option>`).join('')}</select></span>`;
      }
    });
    box.innerHTML = `<div class="insp-t"><b>${c.label}</b><span>${d.name}</span></div><div class="insp-c">${ctl}<button class="btn danger" id="delSel">Hatao</button></div>`;
    const setVal = (p, v) => { c[p.k] = v; sim.touch(); const keep = S.sel; refreshComp(c); renderLive(); S.sel = keep; renderInspector(); };
    box.querySelectorAll('[data-p]').forEach(sel => sel.onchange = () => { const p = d.props[+sel.dataset.p]; setVal(p, typeof p.opts[0] === 'number' ? +sel.value : sel.value); });
    box.querySelectorAll('[data-pre]').forEach(sel => sel.onchange = () => { if (sel.value) setVal(d.props[+sel.dataset.pre], +sel.value); });
    const numCh = (i) => { const n = +box.querySelector(`[data-n="${i}"]`).value, u = +box.querySelector(`[data-u="${i}"]`).value; if (n >= 0) setVal(d.props[i], n * u); };
    box.querySelectorAll('[data-n]').forEach(inp => inp.onchange = () => numCh(inp.dataset.n));
    box.querySelectorAll('[data-u]').forEach(inp => inp.onchange = () => numCh(inp.dataset.u));
    $('delSel').onclick = () => removeComp(c.id);
  }
  function renderLive() {
    const items = S.comps.filter(c => { const d = COMPS[c.type]; return d.live || d.toggle || d.hold; });
    $('liveWrap').hidden = !items.length;
    let h = '';
    items.forEach(c => { const d = COMPS[c.type];
      (d.live || []).forEach((l, i) => { const v = c[l.k], txt = l.pct ? Math.round(v * 100) + '%' : (+v).toFixed(l.step < 1 ? 1 : 0) + (l.unit || '');
        h += `<div class="lc"><span class="lcn">${c.label}<br><span class="lcsub">${l.label}</span></span><input type="range" min="${l.min}" max="${l.max}" step="${l.step}" value="${v}" data-sl="${c.id}:${i}" aria-label="${c.label} ${l.label}"><output id="o${c.id}_${i}">${txt}</output></div>`; });
      if (d.toggle) h += `<div class="lc"><span class="lcn">${c.label}</span><button class="btn tg holdbtn ${c[d.toggle.k] ? 'on' : ''}" data-tg="${c.id}">${d.toggle.label}: ${c[d.toggle.k] ? 'ON' : 'OFF'}</button></div>`;
      if (d.hold) h += `<div class="lc"><span class="lcn">${c.label}</span><button class="holdbtn ${c[d.hold.k] ? 'on' : ''}" data-hold="${c.id}">${d.hold.label}</button></div>`;
    });
    const box = $('live'); box.innerHTML = h;
    box.querySelectorAll('[data-sl]').forEach(r => r.oninput = () => {
      const [id, i] = r.dataset.sl.split(':'), c = S.comps.find(x => x.id === +id), l = COMPS[c.type].live[+i];
      c[l.k] = +r.value; $('o' + id + '_' + i).textContent = l.pct ? Math.round(r.value * 100) + '%' : (+r.value).toFixed(l.step < 1 ? 1 : 0) + (l.unit || ''); refreshComp(c); sim.touch();
    });
    box.querySelectorAll('[data-tg]').forEach(b => b.onclick = () => { const c = S.comps.find(x => x.id === +b.dataset.tg), d = COMPS[c.type]; c[d.toggle.k] = !c[d.toggle.k]; refreshComp(c); sim.touch(); renderLive(); });
    box.querySelectorAll('[data-hold]').forEach(b => {
      const c = S.comps.find(x => x.id === +b.dataset.hold), k = COMPS[c.type].hold.k;
      const set = (v) => { c[k] = v; b.classList.toggle('on', v); refreshComp(c); sim.touch(); };
      b.onpointerdown = (e) => { e.preventDefault(); b.setPointerCapture(e.pointerId); set(true); };
      b.onpointerup = b.onpointercancel = () => set(false);
    });
  }

  // ---------- pointer interaction ----------
  svg.addEventListener('pointerdown', (e) => {
    const p = svgPt(e), tN = e.target.closest('[data-t]'), pr = e.target.closest('[data-press]');
    if (tN) { drag = { k: 'wire', from: tN.dataset.t, x0: e.clientX, y0: e.clientY, moved: false }; svg.setPointerCapture(e.pointerId); return; }
    if (pr) { const c = S.comps.find(x => x.id === +pr.dataset.press); c.pressed = true; refreshComp(c); sim.touch(); drag = { k: 'press', c }; svg.setPointerCapture(e.pointerId); return; }
    const cN = e.target.closest('[data-c]');
    if (cN) { const c = S.comps.find(x => x.id === +cN.dataset.c); drag = { k: 'comp', c, dx: p.x - c.x, dy: p.y - c.y, x0: e.clientX, y0: e.clientY, moved: false, node: cN }; svg.setPointerCapture(e.pointerId); return; }
    const wN = e.target.closest('[data-w]');
    if (wN) { S.sel = { w: +wN.dataset.w }; S.pending = null; renderWires(); renderPending(); renderInspector(); return; }
    S.sel = null; S.pending = null; hint(); renderWires(); renderComps(); renderPending(); renderInspector();
  });
  svg.addEventListener('pointermove', (e) => {
    if (!drag) return;
    if (drag.k === 'wire') {
      if (!drag.moved && Math.hypot(e.clientX - drag.x0, e.clientY - drag.y0) > 6) drag.moved = true;
      if (drag.moved) { const a = termPos(drag.from), p = svgPt(e); rubber.setAttribute('d', wirePath(a, [p.x, p.y])); rubber.style.display = ''; }
    } else if (drag.k === 'comp') {
      if (!drag.moved && Math.hypot(e.clientX - drag.x0, e.clientY - drag.y0) > 5) drag.moved = true;
      if (drag.moved) { const p = svgPt(e), c = drag.c; c.x = Math.round(Math.max(40, Math.min(360, p.x - drag.dx))); c.y = Math.round(Math.max(80, Math.min(60 + viewH() - 40, p.y - drag.dy))); drag.node.setAttribute('transform', `translate(${c.x},${c.y})`); renderWires(); }
    }
  });
  function endDrag(e) {
    if (!drag) return; const d = drag; drag = null; rubber.style.display = 'none';
    if (d.k === 'press') { d.c.pressed = false; refreshComp(d.c); sim.touch(); return; }
    if (d.k === 'wire') {
      const under = e.type === 'pointerup' ? document.elementFromPoint(e.clientX, e.clientY) : null, tN = under && under.closest && under.closest('[data-t]');
      if (d.moved) { if (tN && tN.dataset.t !== d.from) addWire(d.from, tN.dataset.t); else hint(); }
      else if (e.type === 'pointerup') {
        if (S.pending && S.pending !== d.from) addWire(S.pending, d.from);
        else if (S.pending === d.from) { S.pending = null; hint(); }
        else { S.pending = d.from; hint(termLabel(d.from) + ' chuna. Ab doosre pin par tap karo.'); }
        S.sel = null; renderPending(); renderInspector(); renderWires(); renderComps(); renderPending();
      }
    } else if (d.k === 'comp') {
      if (!d.moved && e.type === 'pointerup') { S.sel = { c: d.c.id }; S.pending = null; renderWires(); renderComps(); renderPending(); renderInspector(); }
    }
  }
  svg.addEventListener('pointerup', endDrag); svg.addEventListener('pointercancel', endDrag);

  // ---------- run loop ----------
  function initAudio() {
    if (audio) { if (audio.state === 'suspended') audio.resume(); return; }
    try { audio = new (window.AudioContext || window.webkitAudioContext)(); osc = audio.createOscillator(); gain = audio.createGain(); osc.type = 'square'; gain.gain.value = 0; osc.connect(gain); gain.connect(audio.destination); osc.start(); } catch (e) { audio = null; }
  }
  function setSound(on, f) {
    if (!audio || !gain) return; const want = on && soundOn;
    if (want) osc.frequency.setTargetAtTime(Math.max(50, Math.min(8000, f)), audio.currentTime, 0.005);
    gain.gain.setTargetAtTime(want ? 0.04 : 0, audio.currentTime, 0.01);
  }
  function updateLive(snap) {
    if (!snap) return; let sound = false, sf = 0;
    S.comps.forEach(c => {
      const g = layerC.querySelector(`[data-c="${c.id}"]`), s = snap[c.id], d = COMPS[c.type]; if (!g || !s) return;
      if (d.view) d.view(c, g, s);
      g.classList.toggle('burnt', !!s.burnt);
      if (s.on && s.freq) { sound = true; sf = s.freq; }
    });
    setSound(sound, sf);
    const bd = sim.board, p = sim.pins[bd.led];
    let target = p && p.mode === 1 && (p.level || p.duty) ? (p.duty !== null ? p.duty : 1) : 0;
    if (bd.ledLow) target = p && p.mode === 1 ? 1 - target : 0;
    oblB += (target - oblB) * 0.5; const ol = $('onboardL'); if (ol) ol.style.opacity = 0.25 + 0.75 * oblB;
  }
  function frame(ts) {
    if (!running) return;
    const dt = Math.min(100, ts - lastTs); lastTs = ts;
    sim.advance(dt * 1000 * speed, 10); updateLive(sim.snapshot()); flushSerial();
    $('time').textContent = sim.B ? (sim.B.now / 1e6).toFixed(1) + 's' : '';
    if (running) requestAnimationFrame(frame);
  }
  function setStatusCode(msg, bad) { const e = $('codeStatus'); e.textContent = msg; e.className = 'cstat' + (bad ? ' bad' : msg ? ' good' : ''); }
  function run() {
    initAudio(); clearWarns(); let prog;
    try { prog = sim.compile($('code').value); }
    catch (e) { if (!e.isC) throw e; addWarn('c', `Line ${e.line}: ${e.message}`, 'err', e.line); setStatusCode(`Line ${e.line}: ${e.message}`, true); return; }
    setStatusCode('Code theek hai. Upload ho gaya.'); serialText = ''; serialBuf = ''; $('serial').textContent = '';
    sim.setCircuit(S.comps, S.wires); sim.start(prog.factory); running = true; oblB = 0; lastTs = performance.now();
    setRunUI(true); requestAnimationFrame(frame);
  }
  function stop(why) {
    if (!running && !sim.running) return;
    running = false; sim.stop(); setSound(false, 0); setRunUI(false); renderComps(); renderWires(); renderPending();
    const ol = $('onboardL'); if (ol) ol.style.opacity = 0.25;
    if (why === 'short') setPill('Short circuit', 'bad'); else if (why === 'error') setPill('Error', 'bad');
  }
  function setRunUI(on) { $('run').hidden = on; $('stop').hidden = !on; setPill(on ? 'Chal raha hai' : 'Band', on ? 'live' : ''); if (!on) $('time').textContent = ''; }
  function setPill(t, k) { const p = $('pill'); p.textContent = t; p.className = 'pill ' + (k || ''); }
  sim.onStop = (why) => setTimeout(() => stop(why), 0);

  // ---------- serial + problems ----------
  sim.onSerial = (s) => { serialBuf += s; };
  function flushSerial() {
    if (!serialBuf) return; serialText += serialBuf; serialBuf = '';
    if (serialText.length > 6000) serialText = serialText.slice(-5000);
    const el = $('serial'), atEnd = el.scrollTop + el.clientHeight >= el.scrollHeight - 8; el.textContent = serialText; if (atEnd) el.scrollTop = el.scrollHeight;
  }
  function addWarn(key, msg, level, line) { warns.push({ key, msg, level, line }); renderWarns(); }
  sim.onWarn = (k, m, l) => addWarn(k, m, l);
  function clearWarns() { warns.length = 0; renderWarns(); }
  function renderWarns() {
    const ul = $('problems'); $('pcount').textContent = warns.length || '';
    ul.innerHTML = warns.length ? warns.slice(-12).map(w => `<li class="${w.level}" ${w.line ? `data-line="${w.line}"` : ''}><span class="dotw"></span><span>${w.msg}</span></li>`).join('') : '<li class="none">Abhi koi problem nahi.</li>';
    ul.querySelectorAll('[data-line]').forEach(li => li.onclick = () => gotoLine(+li.dataset.line));
  }
  function gotoLine(n) { const ta = $('code'), lines = ta.value.split('\n'); let off = 0; for (let i = 0; i < n - 1 && i < lines.length; i++) off += lines[i].length + 1; ta.focus(); ta.setSelectionRange(off, off + (lines[n - 1] || '').length); }

  // ---------- wiring up the page ----------
  $('run').onclick = run; $('stop').onclick = () => stop();
  $('speed').onchange = (e) => { speed = +e.target.value; };
  $('sound').onclick = (e) => { soundOn = !soundOn; e.currentTarget.setAttribute('aria-pressed', soundOn); e.currentTarget.textContent = soundOn ? 'Awaaz: on' : 'Awaaz: off'; if (!soundOn) setSound(false, 0); };
  $('catSel').onchange = (e) => { S.cat = e.target.value; renderPalette(); };
  $('boardSel').innerHTML = Object.keys(BOARDS).map(k => `<option value="${k}">${BOARDS[k].name}</option>`).join('');
  $('boardSel').onchange = (e) => { stop(); applyBoard(e.target.value); changed(); };
  $('clear').onclick = () => { if (S.comps.length && !$('clear').dataset.arm) { $('clear').dataset.arm = 1; $('clear').textContent = 'Pakka?'; setTimeout(() => { delete $('clear').dataset.arm; $('clear').textContent = 'Sab hatao'; }, 2500); return; } delete $('clear').dataset.arm; $('clear').textContent = 'Sab hatao'; clearAll(); };
  function setZoom(z) { S.zoom = Math.max(1, Math.min(2.6, z)); svg.style.width = (S.zoom * 100) + '%'; $('zlab').textContent = Math.round(S.zoom * 100) + '%'; }
  $('zin').onclick = () => setZoom(S.zoom + 0.4); $('zout').onclick = () => setZoom(S.zoom - 0.4);
  const exSel = $('examples'); EXAMPLES.forEach(ex => { const o = document.createElement('option'); o.value = ex.id; o.textContent = ex.name; exSel.appendChild(o); });
  $('loadEx').onclick = () => { stop(); clearWarns(); loadExample(EXAMPLES.find(e => e.id === exSel.value)); hint('Example load ho gaya. Ab ▶ Chalao dabao.'); };
  $('check').onclick = () => {
    clearWarns();
    sim.setCircuit(S.comps, S.wires); const lint = lintCircuit(sim, S.comps); lint.forEach(w => addWarn(w[0], w[1], w[2]));
    try { sim.compile($('code').value); setStatusCode(lint.length ? `Code theek hai, par circuit mein ${lint.length} problem mili (Problems dekho).` : 'Code aur circuit mein koi galti nahi mili.', !!lint.length); renderWarns(); }
    catch (e) { if (!e.isC) throw e; setStatusCode(`Line ${e.line}: ${e.message}`, true); addWarn('c', `Line ${e.line}: ${e.message}`, 'err', e.line); }
  };
  $('file').onchange = (e) => { const f = e.target.files[0]; if (!f) return; const r = new FileReader(); r.onload = () => { $('code').value = String(r.result); setStatusCode(f.name + ' load hua. ▶ Chalao dabao.'); }; r.readAsText(f); e.target.value = ''; };
  $('sclear').onclick = () => { serialText = ''; serialBuf = ''; $('serial').textContent = ''; };
  $('sform').onsubmit = (e) => { e.preventDefault(); const v = $('sin').value; if (running) sim.serialIn += v + '\n'; serialText += '> ' + v + '\n'; $('serial').textContent = serialText; $('sin').value = ''; };
  $('code').addEventListener('keydown', (e) => { if (e.key === 'Tab') { e.preventDefault(); const t = e.target, s = t.selectionStart; t.value = t.value.slice(0, s) + '  ' + t.value.slice(t.selectionEnd); t.selectionStart = t.selectionEnd = s + 2; } });

  buildPalette(); applyBoard('uno', true); setZoom(1); hint(); renderWarns();
  loadExample(EXAMPLES[0]); setRunUI(false);
})();
